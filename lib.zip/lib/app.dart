import 'package:flutter/material.dart';
import 'ui/home_screen.dart';
import 'ui/chat/chat_screen.dart';
import 'ui/flowchart/flowchart_editor.dart';

/// Main application widget
class AIFlowArchitectApp extends StatelessWidget {
  const AIFlowArchitectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Flow Architect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
        ),
      ),
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
      routes: {
        '/chat': (context) => const ChatScreen(),
        '/flowchart': (context) => const FlowchartEditorScreen(workflowId: 1),
      },
    );
  }
}
