/// Working memory for current workflow execution state
class WorkingMemory {
  final Map<String, dynamic> _state = {};
  final List<String> _executionLog = [];

  /// Set state value
  void setState(String key, dynamic value) {
    _state[key] = value;
    _log('SET $key = ${_truncate(value.toString())}');
  }

  /// Get state value
  dynamic getState(String key) {
    return _state[key];
  }

  /// Update state by merging
  void updateState(Map<String, dynamic> updates) {
    _state.addAll(updates);
    _log('UPDATE ${updates.keys.join(", ")}');
  }

  /// Remove state value
  void removeState(String key) {
    _state.remove(key);
    _log('REMOVE $key');
  }

  /// Check if key exists
  bool hasState(String key) {
    return _state.containsKey(key);
  }

  /// Get all state
  Map<String, dynamic> getAllState() {
    return Map.from(_state);
  }

  /// Clear state
  void clearState() {
    _state.clear();
    _log('CLEAR ALL STATE');
  }

  /// Add execution log entry
  void log(String message) {
    _log(message);
  }

  /// Get execution log
  List<String> getLog({int? limit}) {
    if (limit == null) return List.from(_executionLog);
    final startIndex = _executionLog.length > limit ? _executionLog.length - limit : 0;
    return _executionLog.sublist(startIndex);
  }

  /// Clear execution log
  void clearLog() {
    _executionLog.clear();
  }

  /// Clear everything
  void reset() {
    _state.clear();
    _executionLog.clear();
  }

  void _log(String message) {
    final timestamp = DateTime.now().toIso8601String();
    _executionLog.add('[$timestamp] $message');

    // Keep log size manageable
    if (_executionLog.length > 1000) {
      _executionLog.removeAt(0);
    }
  }

  String _truncate(String str, {int maxLength = 100}) {
    if (str.length <= maxLength) return str;
    return '${str.substring(0, maxLength)}...';
  }
}
