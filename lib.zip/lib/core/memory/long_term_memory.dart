import '../storage/isar_service.dart';
import '../storage/models/agent_memory.dart';

/// Long-term memory with semantic search using embeddings
class LongTermMemory {
  final IsarService _db = IsarService();

  /// Store memory with optional embedding
  Future<int> store({
    required String text,
    List<double>? embedding,
    String tag = 'general',
  }) async {
    final memory = AgentMemory.create(
      text: text,
      embedding: embedding,
      tag: tag,
    );

    return await _db.createMemory(memory);
  }

  /// Retrieve recent memories by tag
  Future<List<AgentMemory>> getRecent({
    String tag = 'general',
    int limit = 20,
  }) async {
    return await _db.getMemoriesByTag(tag, limit: limit);
  }

  /// Search memories by text (simple contains)
  Future<List<AgentMemory>> searchByText(String query, {int limit = 10}) async {
    final allMemories = await _db.getMemoriesByTag('general', limit: 100);
    final queryLower = query.toLowerCase();

    final matches = allMemories
        .where((m) => m.text.toLowerCase().contains(queryLower))
        .take(limit)
        .toList();

    return matches;
  }

  /// Search memories by semantic similarity (using embeddings)
  Future<List<AgentMemory>> searchBySimilarity({
    required List<double> queryEmbedding,
    int limit = 10,
    double threshold = 0.7,
  }) async {
    // Get all memories with embeddings - using getMemoriesByTag with large limit
    final allMemoriesRaw = await _db.getMemoriesByTag('general', limit: 10000);
    final allMemories = allMemoriesRaw.where((m) => m.embedding != null).toList();

    // Calculate cosine similarity
    final similarities = <MapEntry<AgentMemory, double>>[];
    for (final memory in allMemories) {
      if (memory.embedding == null) continue;

      final similarity = _cosineSimilarity(queryEmbedding, memory.embedding!);
      if (similarity >= threshold) {
        similarities.add(MapEntry(memory, similarity));
      }
    }

    // Sort by similarity descending
    similarities.sort((a, b) => b.value.compareTo(a.value));

    // Return top results
    return similarities.take(limit).map((e) => e.key).toList();
  }

  /// Store conversation turn
  Future<void> storeConversation({
    required String userMessage,
    required String assistantMessage,
    List<double>? userEmbedding,
    List<double>? assistantEmbedding,
  }) async {
    await store(
      text: 'User: $userMessage',
      embedding: userEmbedding,
      tag: 'conversation',
    );

    await store(
      text: 'Assistant: $assistantMessage',
      embedding: assistantEmbedding,
      tag: 'conversation',
    );
  }

  /// Get conversation history
  Future<List<AgentMemory>> getConversationHistory({int limit = 50}) async {
    return await getRecent(tag: 'conversation', limit: limit);
  }

  /// Calculate cosine similarity between two vectors
  double _cosineSimilarity(List<double> a, List<double> b) {
    if (a.length != b.length) return 0.0;

    var dotProduct = 0.0;
    var normA = 0.0;
    var normB = 0.0;

    for (var i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    normA = normA.sqrt();
    normB = normB.sqrt();

    if (normA == 0 || normB == 0) return 0.0;

    return dotProduct / (normA * normB);
  }
}

extension on double {
  double sqrt() => this < 0 ? 0 : this == 0 ? 0 : this.toDouble().abs().toDouble();
}
