import 'dart:collection';

/// Short-term memory for current conversation context
class ShortTermMemory {
  final int maxMessages;
  final Queue<MemoryEntry> _messages = Queue();

  ShortTermMemory({this.maxMessages = 50});

  /// Add message to memory
  void add(String role, String content, {Map<String, dynamic>? metadata}) {
    _messages.add(MemoryEntry(
      role: role,
      content: content,
      metadata: metadata ?? {},
      timestamp: DateTime.now(),
    ));

    // Remove oldest if over capacity
    while (_messages.length > maxMessages) {
      _messages.removeFirst();
    }
  }

  /// Get recent messages
  List<MemoryEntry> getRecent({int count = 10}) {
    final recentCount = count > _messages.length ? _messages.length : count;
    return _messages.toList().sublist(_messages.length - recentCount);
  }

  /// Get all messages
  List<MemoryEntry> getAll() {
    return _messages.toList();
  }

  /// Get conversation context as string
  String getContext() {
    return _messages
        .map((entry) => '${entry.role}: ${entry.content}')
        .join('\n');
  }

  /// Search messages by content
  List<MemoryEntry> search(String query) {
    return _messages
        .where((entry) => entry.content.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  /// Clear memory
  void clear() {
    _messages.clear();
  }

  /// Get memory size
  int get size => _messages.length;
}

/// Memory entry
class MemoryEntry {
  final String role;
  final String content;
  final Map<String, dynamic> metadata;
  final DateTime timestamp;

  MemoryEntry({
    required this.role,
    required this.content,
    required this.metadata,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() => {
        'role': role,
        'content': content,
        'metadata': metadata,
        'timestamp': timestamp.toIso8601String(),
      };
}
