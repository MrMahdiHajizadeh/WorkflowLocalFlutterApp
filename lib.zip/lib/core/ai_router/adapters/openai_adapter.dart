import 'package:http/http.dart' as http;
import 'dart:convert';
import '../executor.dart';
import '../models.dart';

/// OpenAI API adapter
class OpenAIAdapter implements ProviderAdapter {
  @override
  Future<http.Response> buildRequest(AIRequest request) async {
    final endpoint = _getEndpoint(request);
    final body = _buildBody(request);

    // Ensure base URL is properly formatted (remove trailing slash if present, then add endpoint)
    String baseUrl = request.baseUrl.trim();
    if (baseUrl.endsWith('/')) {
      baseUrl = baseUrl.substring(0, baseUrl.length - 1);
    }
    
    // Ensure endpoint starts with /
    String finalEndpoint = endpoint.startsWith('/') ? endpoint : '/$endpoint';
    
    final url = Uri.parse('$baseUrl$finalEndpoint');
    
    // Validate URL
    if (!url.hasScheme || (!url.scheme.startsWith('http'))) {
      throw Exception('Invalid base URL: ${request.baseUrl}. Must start with http:// or https://');
    }

    return await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${request.apiKey}',
      },
      body: jsonEncode(body),
    );
  }

  @override
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request) async {
    final endpoint = _getEndpoint(request);
    final body = _buildBody(request);
    body['stream'] = true;

    // Ensure base URL is properly formatted
    String baseUrl = request.baseUrl.trim();
    if (baseUrl.endsWith('/')) {
      baseUrl = baseUrl.substring(0, baseUrl.length - 1);
    }
    
    // Ensure endpoint starts with /
    String finalEndpoint = endpoint.startsWith('/') ? endpoint : '/$endpoint';
    
    final url = Uri.parse('$baseUrl$finalEndpoint');
    
    // Validate URL
    if (!url.hasScheme || (!url.scheme.startsWith('http'))) {
      throw Exception('Invalid base URL: ${request.baseUrl}. Must start with http:// or https://');
    }

    final streamRequest = http.StreamedRequest(
      'POST',
      url,
    );

    streamRequest.headers['Content-Type'] = 'application/json';
    streamRequest.headers['Authorization'] = 'Bearer ${request.apiKey}';
    streamRequest.sink.add(utf8.encode(jsonEncode(body)));
    await streamRequest.sink.close();

    return streamRequest;
  }

  String _getEndpoint(AIRequest request) {
    switch (request.modelType) {
      case 'llm':
        return '/v1/chat/completions';
      case 'image':
        return '/v1/images/generations';
      case 'audio':
        return '/v1/audio/speech';
      case 'embedding':
        return '/v1/embeddings';
      default:
        return '/v1/completions';
    }
  }

  Map<String, dynamic> _buildBody(AIRequest request) {
    switch (request.modelType) {
      case 'llm':
        // Build messages array
        List<Map<String, String>> messages = [];
        
        // Add system prompt if provided
        if (request.inputs['systemPrompt'] != null && 
            request.inputs['systemPrompt'].toString().isNotEmpty) {
          messages.add({
            'role': 'system',
            'content': request.inputs['systemPrompt'].toString(),
          });
        }
        
        // Add user messages
        if (request.inputs['messages'] != null && 
            request.inputs['messages'] is List) {
          messages.addAll((request.inputs['messages'] as List)
              .map((m) => Map<String, String>.from(m))
              .toList());
        } else {
          // Use prompt as user message
          final prompt = request.inputs['prompt'] ?? '';
          if (prompt.isNotEmpty) {
            messages.add({
              'role': 'user',
              'content': prompt.toString(),
            });
          }
        }
        
        // Validate that we have at least one message
        if (messages.isEmpty) {
          throw Exception('No prompt or messages provided for LLM request');
        }
        
        // Build request body with model name and messages
        final requestBody = <String, dynamic>{
          'model': request.modelId, // Use exact model name (e.g., 'gpt-4', 'gpt-3.5-turbo')
          'messages': messages,
        };
        
        // Merge parameters (temperature, max_tokens, top_p, etc.)
        requestBody.addAll(request.parameters);
        
        return requestBody;
      case 'image':
        final prompt = request.inputs['prompt'] ?? '';
        if (prompt.isEmpty) {
          throw Exception('Prompt is required for image generation');
        }
        
        return {
          'model': request.modelId,
          'prompt': prompt.toString(),
          'n': request.parameters['n'] ?? 1,
          'size': request.parameters['size'] ?? '1024x1024',
          ...request.parameters,
        };
      case 'embedding':
        return {
          'model': request.modelId,
          'input': request.inputs['text'] ?? '',
          ...request.parameters,
        };
      default:
        return {
          'model': request.modelId,
          ...request.inputs,
          ...request.parameters,
        };
    }
  }
}
