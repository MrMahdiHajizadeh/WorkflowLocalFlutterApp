import 'package:http/http.dart' as http;
import 'dart:convert';
import '../executor.dart';
import '../models.dart';

/// Custom API adapter for user-defined endpoints
class CustomAdapter implements ProviderAdapter {
  @override
  Future<http.Response> buildRequest(AIRequest request) async {
    // Build request body based on model type
    final body = _buildBody(request);

    // Validate and format base URL
    String baseUrl = request.baseUrl.trim();
    
    // Parse base URL to check its structure
    final uri = Uri.parse(baseUrl);
    
    // Check if baseUrl already contains a full endpoint path
    final path = uri.path.toLowerCase();
    final hasFullEndpoint = path.endsWith('/completions') || 
                           path.endsWith('/chat/completions') ||
                           path.endsWith('/generations') || 
                           path.endsWith('/images/generations') ||
                           path.endsWith('/speech') || 
                           path.endsWith('/audio/speech') ||
                           path.endsWith('/embeddings');
    
    Uri finalUrl;
    if (hasFullEndpoint) {
      // Base URL already contains full endpoint, use it as-is
      finalUrl = uri;
    } else {
      // Remove trailing slash if present
      if (baseUrl.endsWith('/')) {
        baseUrl = baseUrl.substring(0, baseUrl.length - 1);
      }
      
      // Get endpoint path (without /v1 prefix, as baseUrl may already include it)
      final endpoint = _getEndpoint(request);
      String finalEndpoint = endpoint.startsWith('/') ? endpoint : '/$endpoint';
      
      // Build final URL
      // Examples:
      // - https://api.metisai.ir/openai/v1 + /chat/completions = https://api.metisai.ir/openai/v1/chat/completions
      // - https://api.openai.com/v1 + /chat/completions = https://api.openai.com/v1/chat/completions
      finalUrl = Uri.parse('$baseUrl$finalEndpoint');
    }
    
    // Validate URL
    if (!finalUrl.hasScheme || (!finalUrl.scheme.startsWith('http'))) {
      throw Exception('Invalid base URL: ${request.baseUrl}. Must start with http:// or https://');
    }

    // Build headers with proper authorization
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${request.apiKey}',
    };

    return await http.post(
      finalUrl,
      headers: headers,
      body: jsonEncode(body),
    );
  }
  
  String _getEndpoint(AIRequest request) {
    // For custom APIs, return endpoint path without /v1 prefix
    // The baseUrl may already contain /v1 or /openai/v1
    // Examples:
    // - baseUrl: https://api.metisai.ir/openai/v1 -> endpoint: /chat/completions
    // - baseUrl: https://api.openai.com/v1 -> endpoint: /chat/completions
    switch (request.modelType) {
      case 'llm':
        return '/chat/completions';
      case 'image':
        return '/images/generations';
      case 'audio':
        return '/audio/speech';
      case 'embedding':
        return '/embeddings';
      default:
        return '/completions';
    }
  }
  
  Map<String, dynamic> _buildBody(AIRequest request) {
    switch (request.modelType) {
      case 'llm':
        // Build messages array similar to OpenAI format
        List<Map<String, String>> messages = [];
        
        // Add system prompt if provided
        if (request.inputs['systemPrompt'] != null && 
            request.inputs['systemPrompt'].toString().isNotEmpty) {
          messages.add({
            'role': 'system',
            'content': request.inputs['systemPrompt'].toString(),
          });
        }
        
        // Add user messages
        if (request.inputs['messages'] != null && 
            request.inputs['messages'] is List) {
          messages.addAll((request.inputs['messages'] as List)
              .map((m) => Map<String, String>.from(m))
              .toList());
        } else {
          // Use prompt as user message
          final prompt = request.inputs['prompt'] ?? '';
          if (prompt.isNotEmpty) {
            messages.add({
              'role': 'user',
              'content': prompt.toString(),
            });
          }
        }
        
        // Validate that we have at least one message
        if (messages.isEmpty) {
          throw Exception('No prompt or messages provided for LLM request');
        }
        
        // Build request body with model name and messages
        final requestBody = <String, dynamic>{
          'model': request.modelId, // Use exact model name from config
          'messages': messages,
        };
        
        // Merge parameters (temperature, max_tokens, etc.)
        requestBody.addAll(request.parameters);
        
        return requestBody;
      case 'image':
        final prompt = request.inputs['prompt'] ?? '';
        if (prompt.isEmpty) {
          throw Exception('Prompt is required for image generation');
        }
        
        return {
          'model': request.modelId,
          'prompt': prompt.toString(),
          'n': request.parameters['n'] ?? 1,
          'size': request.parameters['size'] ?? '1024x1024',
          ...request.parameters,
        };
      case 'embedding':
        return {
          'model': request.modelId,
          'input': request.inputs['text'] ?? '',
          ...request.parameters,
        };
      default:
        // For other types, use inputs and parameters as-is
        return {
          'model': request.modelId,
          ...request.inputs,
          ...request.parameters,
        };
    }
  }

  @override
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request) async {
    // Build request body based on model type
    final body = _buildBody(request);
    body['stream'] = true;

    // Validate and format base URL (same logic as buildRequest)
    String baseUrl = request.baseUrl.trim();
    final uri = Uri.parse(baseUrl);
    final path = uri.path.toLowerCase();
    final hasFullEndpoint = path.endsWith('/completions') || 
                           path.endsWith('/chat/completions') ||
                           path.endsWith('/generations') || 
                           path.endsWith('/images/generations') ||
                           path.endsWith('/speech') || 
                           path.endsWith('/audio/speech') ||
                           path.endsWith('/embeddings');
    
    Uri finalUrl;
    if (hasFullEndpoint) {
      finalUrl = uri;
    } else {
      if (baseUrl.endsWith('/')) {
        baseUrl = baseUrl.substring(0, baseUrl.length - 1);
      }
      final endpoint = _getEndpoint(request);
      String finalEndpoint = endpoint.startsWith('/') ? endpoint : '/$endpoint';
      finalUrl = Uri.parse('$baseUrl$finalEndpoint');
    }

    // Validate URL
    if (!finalUrl.hasScheme || (!finalUrl.scheme.startsWith('http'))) {
      throw Exception('Invalid base URL: ${request.baseUrl}. Must start with http:// or https://');
    }

    final streamRequest = http.StreamedRequest(
      'POST',
      finalUrl,
    );

    // Set headers
    streamRequest.headers['Content-Type'] = 'application/json';
    streamRequest.headers['Authorization'] = 'Bearer ${request.apiKey}';
    
    // Write body
    streamRequest.sink.add(utf8.encode(jsonEncode(body)));
    await streamRequest.sink.close();

    return streamRequest;
  }
}
