import 'package:http/http.dart' as http;
import 'dart:convert';
import '../executor.dart';
import '../models.dart';

/// Groq API adapter (similar to OpenAI but optimized for Groq)
class GroqAdapter implements ProviderAdapter {
  @override
  Future<http.Response> buildRequest(AIRequest request) async {
    final body = {
      'model': request.modelId,
      'messages': request.inputs['messages'] ?? [
        {'role': 'user', 'content': request.inputs['prompt'] ?? ''}
      ],
      ...request.parameters,
    };

    return await http.post(
      Uri.parse('${request.baseUrl}/openai/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${request.apiKey}',
      },
      body: jsonEncode(body),
    );
  }

  @override
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request) async {
    final body = {
      'model': request.modelId,
      'messages': request.inputs['messages'] ?? [
        {'role': 'user', 'content': request.inputs['prompt'] ?? ''}
      ],
      'stream': true,
      ...request.parameters,
    };

    final streamRequest = http.StreamedRequest(
      'POST',
      Uri.parse('${request.baseUrl}/openai/v1/chat/completions'),
    );

    streamRequest.headers['Content-Type'] = 'application/json';
    streamRequest.headers['Authorization'] = 'Bearer ${request.apiKey}';
    streamRequest.sink.add(utf8.encode(jsonEncode(body)));
    await streamRequest.sink.close();

    return streamRequest;
  }
}
