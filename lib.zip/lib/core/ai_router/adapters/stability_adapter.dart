import 'package:http/http.dart' as http;
import 'dart:convert';
import '../executor.dart';
import '../models.dart';

/// Stability AI adapter for image generation
class StabilityAdapter implements ProviderAdapter {
  @override
  Future<http.Response> buildRequest(AIRequest request) async {
    final engineId = request.modelId;
    final body = {
      'text_prompts': [
        {'text': request.inputs['prompt'] ?? '', 'weight': 1.0}
      ],
      'cfg_scale': request.parameters['cfg_scale'] ?? 7.0,
      'height': request.parameters['height'] ?? 1024,
      'width': request.parameters['width'] ?? 1024,
      'samples': request.parameters['samples'] ?? 1,
      'steps': request.parameters['steps'] ?? 30,
      ...request.parameters,
    };

    return await http.post(
      Uri.parse('${request.baseUrl}/v1/generation/$engineId/text-to-image'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${request.apiKey}',
        'Accept': 'application/json',
      },
      body: jsonEncode(body),
    );
  }

  @override
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request) async {
    // Stability AI doesn't support streaming for images
    throw UnsupportedError('Stability AI does not support streaming');
  }
}
