import 'package:http/http.dart' as http;
import 'dart:convert';
import '../executor.dart';
import '../models.dart';

/// Replicate API adapter for various models
class ReplicateAdapter implements ProviderAdapter {
  @override
  Future<http.Response> buildRequest(AIRequest request) async {
    // Start prediction
    final body = {
      'version': request.modelId,
      'input': request.inputs,
    };

    final startResponse = await http.post(
      Uri.parse('${request.baseUrl}/v1/predictions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Token ${request.apiKey}',
      },
      body: jsonEncode(body),
    );

    if (startResponse.statusCode != 201) {
      return startResponse;
    }

    final startData = jsonDecode(startResponse.body) as Map<String, dynamic>;
    final predictionId = startData['id'];

    // Poll for completion
    while (true) {
      await Future.delayed(const Duration(seconds: 2));

      final statusResponse = await http.get(
        Uri.parse('${request.baseUrl}/v1/predictions/$predictionId'),
        headers: {
          'Authorization': 'Token ${request.apiKey}',
        },
      );

      final statusData = jsonDecode(statusResponse.body) as Map<String, dynamic>;
      final status = statusData['status'];

      if (status == 'succeeded') {
        return statusResponse;
      } else if (status == 'failed' || status == 'canceled') {
        throw Exception('Prediction failed: ${statusData['error']}');
      }
    }
  }

  @override
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request) async {
    throw UnsupportedError('Replicate does not support streaming');
  }
}
