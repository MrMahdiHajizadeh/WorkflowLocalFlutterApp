import 'dart:async';
import 'dart:convert';

/// Handles Server-Sent Events streaming from AI providers
class StreamHandler {
  /// Parse SSE stream and emit standardized chunks
  static Stream<String> handleSSEStream(
    Stream<List<int>> byteStream,
    String provider,
  ) async* {
    final textStream = byteStream.transform(utf8.decoder).transform(const LineSplitter());

    await for (final line in textStream) {
      if (line.isEmpty || line.startsWith(':')) continue;

      if (line.startsWith('data: ')) {
        final data = line.substring(6);

        // Check for end marker
        if (data.trim() == '[DONE]') break;

        try {
          final json = jsonDecode(data);
          final chunk = extractChunk(json, provider);
          if (chunk != null && chunk.isNotEmpty) {
            yield chunk;
          }
        } catch (e) {
          // Skip invalid JSON
          continue;
        }
      }
    }
  }

  /// Extract text chunk from streaming response based on provider
  static String? extractChunk(Map<String, dynamic> json, String provider) {
    switch (provider) {
      case 'openai':
      case 'groq':
        return json['choices']?[0]?['delta']?['content'];
      case 'custom':
        return json['content'] ?? json['text'] ?? json['chunk'];
      default:
        return json['text'] ?? json['content'];
    }
  }

  /// Convert text stream to event stream
  static Stream<Map<String, dynamic>> toEventStream(Stream<String> textStream) async* {
    await for (final chunk in textStream) {
      yield {
        'type': 'chunk',
        'data': chunk,
      };
    }
    yield {
      'type': 'done',
      'data': null,
    };
  }
}
