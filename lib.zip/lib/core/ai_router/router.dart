import 'models.dart';
import 'executor.dart';
import 'adapters/openai_adapter.dart';
import 'adapters/groq_adapter.dart';
import 'adapters/stability_adapter.dart';
import 'adapters/replicate_adapter.dart';
import 'adapters/custom_adapter.dart';

/// Main AI Router for handling requests across multiple providers
class AIRouter {
  static final AIRouter _instance = AIRouter._internal();
  factory AIRouter() => _instance;
  AIRouter._internal();

  /// Send a non-streaming request
  Future<AIResponse> send(AIRequest request) async {
    return await Executor.execute(request);
  }

  /// Send a streaming request
  Stream<String> stream(AIRequest request) {
    return Executor.executeStream(request);
  }

  /// Test connection to a provider
  Future<bool> testConnection(AIRequest request) async {
    try {
      await send(request);
      return true;
    } catch (e) {
      return false;
    }
  }
}
