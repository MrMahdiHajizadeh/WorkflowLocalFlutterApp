/// AI Request model for standardized API calls
class AIRequest {
  final String modelId;
  final String provider; // "openai" | "groq" | "stability" | "replicate" | "custom"
  final String baseUrl;
  final String apiKey;
  final String modelType; // "llm" | "image" | "audio" | "embedding"
  final Map<String, dynamic> inputs;
  final Map<String, dynamic> parameters;
  final bool streaming;

  AIRequest({
    required this.modelId,
    required this.provider,
    required this.baseUrl,
    required this.apiKey,
    required this.modelType,
    required this.inputs,
    required this.parameters,
    this.streaming = false,
  });

  Map<String, dynamic> toJson() => {
        'modelId': modelId,
        'provider': provider,
        'baseUrl': baseUrl,
        'modelType': modelType,
        'inputs': inputs,
        'parameters': parameters,
        'streaming': streaming,
      };
}

/// AI Response model for standardized responses
class AIResponse {
  final Map<String, dynamic> data;
  final Map<String, dynamic> raw;
  final String provider;
  final String modelType;

  AIResponse({
    required this.data,
    required this.raw,
    required this.provider,
    required this.modelType,
  });

  /// LLM response
  String? get text => data['text'] as String?;

  /// Image response
  String? get imagePath => data['image_path'] as String?;
  String? get thumbnail => data['thumbnail'] as String?;

  /// Audio response
  String? get audioPath => data['audio_path'] as String?;

  /// Embedding response
  List<double>? get embedding {
    final emb = data['embedding'];
    if (emb is List) {
      return emb.cast<double>();
    }
    return null;
  }
}
