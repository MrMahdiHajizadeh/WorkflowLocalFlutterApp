/// Normalizes outputs from different providers into standard format
class Normalizer {
  /// Normalize LLM response
  static Map<String, dynamic> normalizeLLM(Map<String, dynamic> response, String provider) {
    switch (provider) {
      case 'openai':
      case 'groq':
        // OpenAI and Groq use the same format
        final choices = response['choices'] as List?;
        if (choices == null || choices.isEmpty) {
          throw Exception('No choices in API response. Response: ${response.toString().substring(0, 200)}');
        }
        final firstChoice = choices[0] as Map<String, dynamic>?;
        if (firstChoice == null) {
          throw Exception('Invalid choice format in API response');
        }
        final message = firstChoice['message'] as Map<String, dynamic>?;
        if (message == null) {
          throw Exception('No message in choice. Response: ${firstChoice.toString()}');
        }
        final content = message['content'] as String?;
        if (content == null || content.isEmpty) {
          throw Exception('Empty content in message. Message: ${message.toString()}');
        }
        return {
          'text': content,
          'raw': response,
        };
      case 'custom':
        // Try OpenAI-compatible format first (choices array)
        if (response.containsKey('choices') && response['choices'] is List) {
          final choices = response['choices'] as List;
          if (choices.isNotEmpty) {
            final firstChoice = choices[0] as Map<String, dynamic>?;
            if (firstChoice != null) {
              final message = firstChoice['message'] as Map<String, dynamic>?;
              if (message != null) {
                final content = message['content'] as String?;
                if (content != null && content.isNotEmpty) {
                  return {
                    'text': content,
                    'raw': response,
                  };
                }
              }
            }
          }
        }
        // Fallback to other formats
        final text = response['text'] ?? 
                     response['content'] ?? 
                     response['output'] ?? 
                     response['message'] ?? '';
        if (text.isEmpty) {
          throw Exception('No text/content/output/message in custom API response. Response: ${response.toString().substring(0, 200)}');
        }
        return {
          'text': text.toString(),
          'raw': response,
        };
      default:
        final text = response['text'] ?? response['content'] ?? response['output'] ?? '';
        if (text.isEmpty) {
          throw Exception('No text/content/output in API response. Response: ${response.toString().substring(0, 200)}');
        }
        return {
          'text': text.toString(),
          'raw': response,
        };
    }
  }

  /// Normalize image generation response
  static Map<String, dynamic> normalizeImage(Map<String, dynamic> response, String provider) {
    switch (provider) {
      case 'openai':
        final data = response['data'] as List?;
        if (data == null || data.isEmpty) {
          throw Exception('No data in OpenAI image response. Response: ${response.toString().substring(0, 200)}');
        }
        final firstImage = data[0] as Map<String, dynamic>?;
        if (firstImage == null) {
          throw Exception('Invalid image data format in OpenAI response');
        }
        final imageUrl = firstImage['url'] as String?;
        if (imageUrl == null || imageUrl.isEmpty) {
          throw Exception('No URL in OpenAI image response. Image data: ${firstImage.toString()}');
        }
        return {
          'image_path': imageUrl,
          'thumbnail': imageUrl,
          'raw': response,
        };
      case 'stability':
        final artifacts = response['artifacts'] as List?;
        if (artifacts == null || artifacts.isEmpty) {
          throw Exception('No artifacts in Stability AI response. Response: ${response.toString().substring(0, 200)}');
        }
        final firstArtifact = artifacts[0] as Map<String, dynamic>?;
        if (firstArtifact == null) {
          throw Exception('Invalid artifact format in Stability AI response');
        }
        final base64 = firstArtifact['base64'] as String?;
        if (base64 == null || base64.isEmpty) {
          throw Exception('No base64 in Stability AI artifact. Artifact: ${firstArtifact.toString()}');
        }
        return {
          'image_path': 'data:image/png;base64,$base64',
          'thumbnail': 'data:image/png;base64,$base64',
          'raw': response,
        };
      case 'replicate':
        final output = response['output'];
        if (output == null) {
          throw Exception('No output in Replicate response. Response: ${response.toString().substring(0, 200)}');
        }
        final imagePath = output is List 
            ? (output.isNotEmpty ? output.first.toString() : '')
            : output.toString();
        if (imagePath.isEmpty) {
          throw Exception('Empty image path in Replicate output. Output: $output');
        }
        return {
          'image_path': imagePath,
          'thumbnail': imagePath,
          'raw': response,
        };
      default:
        final imagePath = response['image_path'] ?? response['url'] ?? response['image_url'] ?? '';
        if (imagePath.isEmpty) {
          throw Exception('No image_path/url/image_url in custom API response. Response: ${response.toString().substring(0, 200)}');
        }
        return {
          'image_path': imagePath.toString(),
          'thumbnail': (response['thumbnail'] ?? response['url'] ?? imagePath).toString(),
          'raw': response,
        };
    }
  }

  /// Normalize audio generation response
  static Map<String, dynamic> normalizeAudio(Map<String, dynamic> response, String provider) {
    switch (provider) {
      case 'openai':
        return {
          'audio_path': response['url'] ?? '',
          'raw': response,
        };
      case 'replicate':
        final output = response['output'];
        final audioPath = output is List ? output.first : output;
        return {
          'audio_path': audioPath ?? '',
          'raw': response,
        };
      default:
        return {
          'audio_path': response['audio_path'] ?? response['url'] ?? '',
          'raw': response,
        };
    }
  }

  /// Normalize embedding response
  static Map<String, dynamic> normalizeEmbedding(Map<String, dynamic> response, String provider) {
    switch (provider) {
      case 'openai':
        return {
          'embedding': response['data']?[0]?['embedding'] ?? [],
          'raw': response,
        };
      default:
        return {
          'embedding': response['embedding'] ?? response['data'] ?? [],
          'raw': response,
        };
    }
  }

  /// Dispatch to appropriate normalizer based on model type
  static Map<String, dynamic> normalize(
    Map<String, dynamic> response,
    String provider,
    String modelType,
  ) {
    switch (modelType) {
      case 'llm':
        return normalizeLLM(response, provider);
      case 'image':
        return normalizeImage(response, provider);
      case 'audio':
        return normalizeAudio(response, provider);
      case 'embedding':
        return normalizeEmbedding(response, provider);
      default:
        return {'raw': response};
    }
  }
}
