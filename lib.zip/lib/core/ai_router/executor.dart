import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'models.dart';
import 'normalizer.dart';
import 'stream_handler.dart';
import 'adapters/openai_adapter.dart';
import 'adapters/groq_adapter.dart';
import 'adapters/stability_adapter.dart';
import 'adapters/replicate_adapter.dart';
import 'adapters/custom_adapter.dart';

/// Executes API calls with retry logic and error handling
class Executor {
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);
  static const Duration timeout = Duration(seconds: 60);

  /// Execute a non-streaming request
  static Future<AIResponse> execute(AIRequest request) async {
    Exception? lastError;

    for (var attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final response = await _makeRequest(request).timeout(timeout);

        if (response.statusCode == 200 || response.statusCode == 201) {
          // Validate response body is not empty
          if (response.body.isEmpty) {
            throw Exception('Empty response body from API');
          }

          // Parse JSON response
          Map<String, dynamic> responseData;
          try {
            responseData = jsonDecode(response.body) as Map<String, dynamic>;
          } catch (e) {
            throw Exception('Invalid JSON response: ${response.body.substring(0, response.body.length > 200 ? 200 : response.body.length)}');
          }

          // Check for error in response
          if (responseData.containsKey('error')) {
            final error = responseData['error'];
            final errorMessage = error is Map 
                ? (error['message'] ?? error['type'] ?? 'Unknown error')
                : error.toString();
            throw Exception('API returned error: $errorMessage');
          }

          // Normalize response
          final normalizedData = Normalizer.normalize(
            responseData,
            request.provider,
            request.modelType,
          );

          // Validate normalized data has required fields
          if (request.modelType == 'llm' && normalizedData['text'] == null) {
            throw Exception('Response missing text field. Raw response: ${response.body.substring(0, 200)}');
          }
          if (request.modelType == 'image' && normalizedData['image_path'] == null) {
            throw Exception('Response missing image_path field. Raw response: ${response.body.substring(0, 200)}');
          }

          return AIResponse(
            data: normalizedData,
            raw: responseData,
            provider: request.provider,
            modelType: request.modelType,
          );
        } else if (response.statusCode == 401) {
          // Unauthorized - don't retry
          throw Exception('Unauthorized: Invalid API key. Status: ${response.statusCode}, Body: ${response.body}');
        } else if (response.statusCode == 404) {
          // Not found - don't retry
          throw Exception('Not Found: API endpoint not found. Status: ${response.statusCode}, URL: ${request.baseUrl}');
        } else if (response.statusCode >= 500) {
          // Server error - retry
          lastError = Exception('Server error: ${response.statusCode}, Body: ${response.body}');
          await Future.delayed(retryDelay);
          continue;
        } else {
          // Other client errors - don't retry
          final errorBody = response.body.length > 500 
              ? '${response.body.substring(0, 500)}...' 
              : response.body;
          throw Exception('API error ${response.statusCode}: $errorBody');
        }
      } on TimeoutException {
        lastError = Exception('Request timeout');
        await Future.delayed(retryDelay);
        continue;
      } catch (e) {
        lastError = Exception('Request failed: $e');
        break;
      }
    }

    throw lastError ?? Exception('Unknown error');
  }

  /// Execute a streaming request
  static Stream<String> executeStream(AIRequest request) async* {
    final httpRequest = await _buildStreamRequest(request);

    final response = await httpRequest.send().timeout(timeout);

    if (response.statusCode == 200) {
      yield* StreamHandler.handleSSEStream(response.stream, request.provider);
    } else {
      final body = await response.stream.bytesToString();
      throw Exception('Streaming error ${response.statusCode}: $body');
    }
  }

  /// Build HTTP request
  static Future<http.Response> _makeRequest(AIRequest request) async {
    final adapter = _getAdapter(request.provider);
    return await adapter.buildRequest(request);
  }

  /// Build streaming HTTP request
  static Future<http.StreamedRequest> _buildStreamRequest(AIRequest request) async {
    final adapter = _getAdapter(request.provider);
    return await adapter.buildStreamRequest(request);
  }

  /// Get adapter for provider
  static ProviderAdapter _getAdapter(String provider) {
    switch (provider) {
      case 'openai':
        return OpenAIAdapter();
      case 'groq':
        return GroqAdapter();
      case 'stability':
        return StabilityAdapter();
      case 'replicate':
        return ReplicateAdapter();
      case 'custom':
        return CustomAdapter();
      default:
        throw Exception('Unknown provider: $provider');
    }
  }
}

/// Base adapter interface
abstract class ProviderAdapter {
  Future<http.Response> buildRequest(AIRequest request);
  Future<http.StreamedRequest> buildStreamRequest(AIRequest request);
}
