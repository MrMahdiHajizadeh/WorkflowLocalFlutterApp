import '../storage/models/workflow_node.dart';
import '../storage/models/workflow_edge.dart';
import '../../ui/flowchart/node_types.dart';

/// Validates data flow and port connections in workflows
class DataValidator {
  /// Validate that an edge connection is valid
  static ValidationResult validateEdge(
    WorkflowEdge edge,
    WorkflowNode fromNode,
    WorkflowNode toNode,
    NodeType fromNodeType,
    NodeType toNodeType,
  ) {
    final errors = <String>[];
    final warnings = <String>[];

    // Get ports from edge (use label as fallback)
    final fromPort = edge.fromPort ?? edge.label ?? 'output';
    final toPort = edge.toPort ?? edge.label ?? fromPort;

    // Validate output port exists in fromNode
    if (!fromNodeType.outputPorts.contains(fromPort) && fromPort != 'output') {
      errors.add(
        'Output port "$fromPort" does not exist in ${fromNodeType.name}. '
        'Available ports: ${fromNodeType.outputPorts.join(", ")}',
      );
    }

    // Validate input port exists in toNode
    if (!toNodeType.inputPorts.contains(toPort) && toPort != 'input') {
      errors.add(
        'Input port "$toPort" does not exist in ${toNodeType.name}. '
        'Available ports: ${toNodeType.inputPorts.join(", ")}',
      );
    }

    // Check for logic node port matching
    if (fromNodeType.id == 'if' || fromNodeType.id == 'switch') {
      // Logic nodes output to specific ports (true/false or case names)
      if (!fromNodeType.outputPorts.contains(fromPort)) {
        warnings.add(
          'Logic node ${fromNodeType.name} may output to port "$fromPort" at runtime. '
          'Make sure this port exists.',
        );
      }
    }

    // Check for required input ports
    if (toNodeType.inputPorts.isNotEmpty && toPort == 'input') {
      warnings.add(
        'Node ${toNodeType.name} has specific input ports: ${toNodeType.inputPorts.join(", ")}. '
        'Consider using a specific port instead of generic "input".',
      );
    }

    return ValidationResult(
      isValid: errors.isEmpty,
      errors: errors,
      warnings: warnings,
    );
  }

  /// Validate node configuration
  static ValidationResult validateNodeConfig(
    WorkflowNode node,
    NodeType nodeType,
    Map<String, dynamic> config,
  ) {
    final errors = <String>[];
    final warnings = <String>[];

    // Validate required fields based on node type
    switch (nodeType.id) {
      case 'llm':
        if (config['modelId'] == null) {
          errors.add('LLM node requires a model to be selected');
        }
        if (config['prompt'] == null || (config['prompt'] as String).isEmpty) {
          errors.add('LLM node requires a prompt');
        }
        if (config['maxTokens'] == null) {
          warnings.add('LLM node should specify maxTokens');
        }
        break;

      case 'image_generation':
        if (config['modelId'] == null) {
          errors.add('Image Generation node requires a model to be selected');
        }
        if (config['promptMapping'] == null || (config['promptMapping'] as String).isEmpty) {
          errors.add('Image Generation node requires a prompt mapping');
        }
        break;

      case 'if':
        if (config['leftValue'] == null || (config['leftValue'] as String).isEmpty) {
          errors.add('If node requires a left value');
        }
        if (config['rightValue'] == null || (config['rightValue'] as String).isEmpty) {
          errors.add('If node requires a right value');
        }
        if (config['operator'] == null) {
          errors.add('If node requires an operator');
        }
        break;

      case 'switch':
        if (config['value'] == null || (config['value'] as String).isEmpty) {
          errors.add('Switch node requires a value to match');
        }
        if (config['cases'] == null || (config['cases'] as Map).isEmpty) {
          errors.add('Switch node requires at least one case');
        }
        break;

      case 'compare':
        // Compare node can get values from input ports ('a', 'b') or config ('valueA', 'valueB')
        final hasValueA = config['valueA'] != null && (config['valueA'] as String).isNotEmpty;
        final hasValueB = config['valueB'] != null && (config['valueB'] as String).isNotEmpty;
        if (!hasValueA && !hasValueB) {
          warnings.add('Compare node should have Value A and Value B (can be from input ports or config)');
        } else if (!hasValueA) {
          warnings.add('Compare node should have Value A (can be from input port "a" or config)');
        } else if (!hasValueB) {
          warnings.add('Compare node should have Value B (can be from input port "b" or config)');
        }
        if (config['operator'] == null) {
          errors.add('Compare node requires an operator');
        }
        break;
    }

    // Validate variable references in config
    _validateVariableReferences(config, errors, warnings);

    return ValidationResult(
      isValid: errors.isEmpty,
      errors: errors,
      warnings: warnings,
    );
  }

  /// Validate variable references in configuration
  static void _validateVariableReferences(
    Map<String, dynamic> config,
    List<String> errors,
    List<String> warnings,
  ) {
    final regex = RegExp(r'\{\{([^}]+)\}\}');
    
    for (final entry in config.entries) {
      if (entry.value is String) {
        final matches = regex.allMatches(entry.value as String);
        for (final match in matches) {
          final varPath = match.group(1)?.trim() ?? '';
          
          // Validate variable path format
          if (varPath.isEmpty) {
            warnings.add('Empty variable reference found in ${entry.key}');
            continue;
          }

          // Check for node references
          if (varPath.startsWith('node_')) {
            final parts = varPath.split('.');
            if (parts.length < 2) {
              warnings.add(
                'Node reference "$varPath" should include output port (e.g., node_1.output)',
              );
            }
          } else if (varPath == 'input') {
            // 'input' is valid
          } else if (varPath.startsWith('var.')) {
            // Variable reference is valid
          } else {
            warnings.add('Unknown variable reference format: "$varPath"');
          }
        }
      }
    }
  }

  /// Validate workflow data flow
  static ValidationResult validateWorkflowDataFlow(
    List<WorkflowNode> nodes,
    List<WorkflowEdge> edges,
    Map<int, NodeType> nodeTypes,
  ) {
    final errors = <String>[];
    final warnings = <String>[];

    // Check for nodes without inputs that require them
    for (final node in nodes) {
      final nodeType = nodeTypes[node.id];
      if (nodeType == null) continue;

      final incomingEdges = edges.where((e) => e.toNodeId == node.id).toList();
      
      // Check if node requires inputs but has none
      if (nodeType.inputPorts.isNotEmpty && incomingEdges.isEmpty) {
        if (nodeType.id != 'user_input' && nodeType.id != 'variable') {
          warnings.add(
            'Node "${node.name}" (${nodeType.name}) has no input connections but requires inputs: ${nodeType.inputPorts.join(", ")}',
          );
        }
      }

      // Check for nodes without outputs
      final outgoingEdges = edges.where((e) => e.fromNodeId == node.id).toList();
      if (nodeType.outputPorts.isNotEmpty && outgoingEdges.isEmpty) {
        if (nodeType.id != 'output') {
          warnings.add(
            'Node "${node.name}" (${nodeType.name}) has no output connections. '
            'Output ports available: ${nodeType.outputPorts.join(", ")}',
          );
        }
      }
    }

    // Validate all edges
    for (final edge in edges) {
      final fromNode = nodes.firstWhere(
        (n) => n.id == edge.fromNodeId,
        orElse: () => throw Exception('From node ${edge.fromNodeId} not found'),
      );
      final toNode = nodes.firstWhere(
        (n) => n.id == edge.toNodeId,
        orElse: () => throw Exception('To node ${edge.toNodeId} not found'),
      );

      final fromNodeType = nodeTypes[fromNode.id];
      final toNodeType = nodeTypes[toNode.id];

      if (fromNodeType != null && toNodeType != null) {
        final edgeValidation = validateEdge(
          edge,
          fromNode,
          toNode,
          fromNodeType,
          toNodeType,
        );
        errors.addAll(edgeValidation.errors);
        warnings.addAll(edgeValidation.warnings);
      }
    }

    return ValidationResult(
      isValid: errors.isEmpty,
      errors: errors,
      warnings: warnings,
    );
  }

  /// Validate that workflow has a complete path from input to output
  static ValidationResult validateWorkflowCompleteness(
    List<WorkflowNode> nodes,
    List<WorkflowEdge> edges,
    Map<int, NodeType> nodeTypes,
  ) {
    final errors = <String>[];
    final warnings = <String>[];

    if (nodes.isEmpty) {
      errors.add('Workflow has no nodes');
      return ValidationResult(isValid: false, errors: errors, warnings: warnings);
    }

    // Find input nodes (nodes with no incoming edges or user_input nodes)
    final inputNodes = nodes.where((node) {
      final incomingEdges = edges.where((e) => e.toNodeId == node.id).toList();
      final nodeType = nodeTypes[node.id];
      return incomingEdges.isEmpty || nodeType?.id == 'user_input';
    }).toList();

    // Find output nodes
    final outputNodes = nodes.where((node) {
      final nodeType = nodeTypes[node.id];
      return nodeType?.id == 'output';
    }).toList();

    // Check if workflow has at least one input node
    if (inputNodes.isEmpty) {
      errors.add('Workflow has no input nodes. Add a User Input node or connect nodes properly.');
    }

    // Check if workflow has at least one output node
    if (outputNodes.isEmpty) {
      warnings.add('Workflow has no output nodes. Results will be shown in the final output.');
    }

    // Check if all nodes are reachable from input nodes
    final reachableNodes = <int>{};
    final queue = <int>[];

    // Start from input nodes
    for (final inputNode in inputNodes) {
      queue.add(inputNode.id);
      reachableNodes.add(inputNode.id);
    }

    // BFS to find all reachable nodes
    while (queue.isNotEmpty) {
      final currentNodeId = queue.removeAt(0);
      final outgoingEdges = edges.where((e) => e.fromNodeId == currentNodeId).toList();
      
      for (final edge in outgoingEdges) {
        if (!reachableNodes.contains(edge.toNodeId)) {
          reachableNodes.add(edge.toNodeId);
          queue.add(edge.toNodeId);
        }
      }
    }

    // Check for unreachable nodes
    final unreachableNodes = nodes.where((node) => !reachableNodes.contains(node.id)).toList();
    if (unreachableNodes.isNotEmpty) {
      errors.add(
        'Some nodes are not reachable from input nodes: ${unreachableNodes.map((n) => n.name).join(", ")}',
      );
    }

    // Check if output nodes are reachable
    final reachableOutputNodes = outputNodes.where((node) => reachableNodes.contains(node.id)).toList();
    if (outputNodes.isNotEmpty && reachableOutputNodes.isEmpty) {
      errors.add('Output nodes are not reachable from input nodes. Check your connections.');
    }

    // Check for isolated nodes (nodes with no connections at all)
    final isolatedNodes = nodes.where((node) {
      final hasIncoming = edges.any((e) => e.toNodeId == node.id);
      final hasOutgoing = edges.any((e) => e.fromNodeId == node.id);
      final nodeType = nodeTypes[node.id];
      // User input and output nodes can be isolated
      return !hasIncoming && !hasOutgoing && 
             nodeType?.id != 'user_input' && 
             nodeType?.id != 'output' &&
             nodeType?.id != 'variable';
    }).toList();

    if (isolatedNodes.isNotEmpty) {
      errors.add(
        'Isolated nodes (not connected): ${isolatedNodes.map((n) => n.name).join(", ")}',
      );
    }

    // Check for cycles (this will be caught by DAGParser, but we can warn here)
    // This is a basic check - DAGParser will do a more thorough check

    return ValidationResult(
      isValid: errors.isEmpty,
      errors: errors,
      warnings: warnings,
    );
  }
}

/// Result of a validation check
class ValidationResult {
  final bool isValid;
  final List<String> errors;
  final List<String> warnings;

  ValidationResult({
    required this.isValid,
    required this.errors,
    required this.warnings,
  });

  String get summary {
    if (isValid && warnings.isEmpty) {
      return 'Validation passed';
    }
    final parts = <String>[];
    if (!isValid) {
      parts.add('${errors.length} error(s)');
    }
    if (warnings.isNotEmpty) {
      parts.add('${warnings.length} warning(s)');
    }
    return parts.join(', ');
  }
}

