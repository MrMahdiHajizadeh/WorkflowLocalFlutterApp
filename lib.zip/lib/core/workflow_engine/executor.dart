import 'dart:convert';
import '../storage/isar_service.dart';
import '../storage/models/workflow.dart';
import '../storage/models/workflow_node.dart';
import '../storage/models/workflow_edge.dart';
import '../storage/models/workflow_run.dart';
import '../storage/models/node_result.dart';
import 'dag_parser.dart';
import 'node_handler.dart';
import 'node_handlers/llm_node.dart';
import 'node_handlers/image_node.dart';
import 'node_handlers/audio_node.dart';
import 'node_handlers/embedding_node.dart';
import 'node_handlers/logic_node.dart';
import 'node_handlers/switch_node.dart';
import 'node_handlers/compare_node.dart';
import 'node_handlers/math_node.dart';
import 'node_handlers/http_node.dart';
import 'node_handlers/parallel_node.dart';
import 'node_handlers/loop_node.dart';
import 'node_handlers/delay_node.dart';
import 'node_handlers/variable_node.dart';
import 'node_handlers/merge_node.dart';
import 'node_handlers/json_parse_node.dart';
import 'node_handlers/json_build_node.dart';
import 'node_handlers/user_input_node.dart';
import 'node_handlers/output_node.dart';
import 'node_handlers/notification_node.dart';

/// Result of a workflow execution
class WorkflowRunResult {
  final int runId;
  final bool success;
  final String? error;
  final Map<String, dynamic> finalOutput;
  final int durationMs;

  WorkflowRunResult({
    required this.runId,
    required this.success,
    this.error,
    required this.finalOutput,
    required this.durationMs,
  });
}

/// Main workflow executor
class WorkflowExecutor {
  final IsarService _db = IsarService();

  /// Execute a workflow
  Future<WorkflowRunResult> run(int workflowId) async {
    final startTime = DateTime.now();

    // Create run record
    final workflowRun = WorkflowRun.create(workflowId: workflowId);
    final runId = await _db.createRun(workflowRun);

    try {
      // Load workflow data
      final Workflow? workflow = await _db.getWorkflow(workflowId);
      final nodes = await _db.getNodesByWorkflow(workflowId);
      final edges = await _db.getEdgesByWorkflow(workflowId);

      if (nodes.isEmpty) {
        throw Exception('Workflow has no nodes');
      }

      // Execute workflow
      final memory = WorkflowRuntimeMemory();

      // Check if workflow has a saved execution order (linear sequential)
      final executionOrder = workflow?.getExecutionOrder();
      if (executionOrder != null && executionOrder.isNotEmpty) {
        // Use saved linear execution order (sequential: node1 -> node2 -> node3)
        final nodeMap = {for (var node in nodes) node.id: node};
        for (final nodeId in executionOrder) {
          final node = nodeMap[nodeId];
          if (node != null) {
            await _executeNode(node, memory, runId, edges);
          }
        }
      } else {
        // Fallback to DAG-based execution (topological sort)
        // Parse DAG
        final dag = DAGParser.parse(nodes, edges);

        // Check for cycles
        if (DAGParser.hasCycle(dag)) {
          throw Exception('Workflow contains cycles');
        }

        // Get parallel execution levels
        final levels = DAGParser.getParallelLevels(dag);

        // Execute nodes sequentially level by level to ensure proper data flow
        for (final level in levels) {
          // Execute nodes sequentially within each level to ensure data consistency
          // This ensures that data flows correctly between connected nodes
          for (final nodeId in level) {
            final dagNode = dag[nodeId]!;
            await _executeNode(dagNode.node, memory, runId, edges);
          }
        }
      }

      // Mark run as complete
      workflowRun.complete();
      await _db.updateRun(workflowRun);

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      return WorkflowRunResult(
        runId: runId,
        success: true,
        finalOutput: memory.toJson(),
        durationMs: duration,
      );
    } catch (e) {
      // Mark run as failed
      workflowRun.fail(e.toString());
      await _db.updateRun(workflowRun);

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      return WorkflowRunResult(
        runId: runId,
        success: false,
        error: e.toString(),
        finalOutput: {},
        durationMs: duration,
      );
    }
  }

  /// Execute a single node
  Future<void> _executeNode(
    WorkflowNode node,
    WorkflowRuntimeMemory memory,
    int runId,
    List<WorkflowEdge> edges,
  ) async {
    final startTime = DateTime.now();

    try {
      final config = jsonDecode(node.configJson) as Map<String, dynamic>;
      final handler = _getHandler(node.type);

      // Validate node configuration before execution
      if (!handler.validate(config)) {
        throw Exception('Node ${node.name} configuration is invalid');
      }

      // Get input from connected nodes via edges
      final input = _resolveInputFromEdges(node, edges, memory, config);

      // Validate required inputs are present
      _validateNodeInputs(node, input, config);

      // Execute node
      final output = await handler.execute(
        input: input,
        config: config,
        memory: memory,
      );

      // Validate output structure
      _validateNodeOutput(node, output);

      // Store result in memory with node ID as key
      memory.setNodeResult(node.id.toInt(), output);

      // Save to database
      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      final nodeResult = NodeResult.create(
        runId: runId,
        nodeId: node.id,
        outputJson: jsonEncode(output.data),
        error: output.error,
        durationMs: duration,
      );

      await _db.createNodeResult(nodeResult);

      if (!output.success) {
        throw Exception('Node ${node.name} failed: ${output.error}');
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Validate that node has required inputs
  void _validateNodeInputs(
    WorkflowNode node,
    Map<String, dynamic> input,
    Map<String, dynamic> config,
  ) {
    // For nodes that require specific inputs, check they are present
    switch (node.type) {
      case 'llm':
        // LLM can work with prompt from config or input
        if (config['prompt'] == null && input.isEmpty) {
          throw Exception('LLM node ${node.name} requires either a prompt in config or input data');
        }
        break;
      case 'image_generation':
        // Image generation needs prompt
        if (config['promptMapping'] == null && input.isEmpty) {
          throw Exception('Image Generation node ${node.name} requires a prompt mapping or input data');
        }
        break;
      case 'if':
        // If node can work with config values, but warn if both are missing
        if (config['leftValue'] == null && input.isEmpty) {
          throw Exception('If node ${node.name} requires values to compare');
        }
        break;
      case 'compare':
        // Compare node can get values from input ports ('a', 'b') or config ('valueA', 'valueB')
        final hasValueA = config['valueA'] != null && (config['valueA'] as String).isNotEmpty;
        final hasValueB = config['valueB'] != null && (config['valueB'] as String).isNotEmpty;
        final hasInputA = input.containsKey('a');
        final hasInputB = input.containsKey('b');
        if (!hasValueA && !hasInputA && !hasValueB && !hasInputB && input.isEmpty) {
          throw Exception('Compare node ${node.name} requires values to compare (from input ports a/b or config valueA/valueB)');
        }
        break;
    }
  }

  /// Validate node output structure
  void _validateNodeOutput(WorkflowNode node, NodeOutput output) {
    if (!output.success) {
      return; // Errors are handled separately
    }

    // Ensure output has at least an 'output' key for backward compatibility
    if (!output.data.containsKey('output') && output.data.isNotEmpty) {
      // Add 'output' key with first value for backward compatibility
      final firstKey = output.data.keys.first;
      output.data['output'] = output.data[firstKey];
    }

    // Validate specific node outputs
    switch (node.type) {
      case 'if':
        // If node should have 'true' or 'false' port
        if (!output.data.containsKey('true') && !output.data.containsKey('false')) {
          throw Exception('If node ${node.name} output must contain "true" or "false" port');
        }
        if (!output.data.containsKey('path')) {
          throw Exception('If node ${node.name} output must contain "path" field');
        }
        break;
      case 'switch':
        // Switch node should have a 'path' field
        if (!output.data.containsKey('path')) {
          throw Exception('Switch node ${node.name} output must contain "path" field');
        }
        break;
    }
  }

  /// Resolve input from connected nodes via edges
  Map<String, dynamic> _resolveInputFromEdges(
    WorkflowNode node,
    List<WorkflowEdge> edges,
    WorkflowRuntimeMemory memory,
    Map<String, dynamic> config,
  ) {
    final input = <String, dynamic>{};

    // Get edges that connect TO this node
    final incomingEdges = edges.where((e) => e.toNodeId == node.id).toList();

    // For each incoming edge, get data from source node
    for (final edge in incomingEdges) {
      final sourceNodeResult = memory.getNodeResult(edge.fromNodeId);
      if (sourceNodeResult == null) {
        throw Exception(
          'Source node ${edge.fromNodeId} has no result. '
          'Make sure nodes are executed in the correct order.',
        );
      }

      if (!sourceNodeResult.success) {
        throw Exception(
          'Source node ${edge.fromNodeId} failed: ${sourceNodeResult.error}',
        );
      }

      // Get output port from edge (fromPort) and input port (toPort)
      // Priority: fromPort/toPort > label > default
      final outputPort = edge.fromPort ?? edge.label ?? 'output';
      final inputPort = edge.toPort ?? edge.label ?? outputPort;
      
      // For logic nodes (if, switch), check if there's a 'path' field to determine which port to use
      String actualOutputPort = outputPort;
      if (sourceNodeResult.data.containsKey('path')) {
        // Logic nodes output a 'path' field indicating which port was used (e.g., 'true', 'false', 'case1')
        final path = sourceNodeResult.data['path'] as String?;
        if (path != null) {
          // Use the path as the output port (this overrides the edge's fromPort for logic nodes)
          actualOutputPort = path;
        }
      }
      
      // Get data from the output port
      dynamic portData;
      if (sourceNodeResult.data.containsKey(actualOutputPort)) {
        // Direct port match
        portData = sourceNodeResult.data[actualOutputPort];
      } else if (sourceNodeResult.data.containsKey('output')) {
        // Fallback to 'output' key
        portData = sourceNodeResult.data['output'];
      } else if (sourceNodeResult.data.isNotEmpty) {
        // If port not found, use first available value (for backward compatibility)
        portData = sourceNodeResult.data.values.first;
      } else {
        throw Exception(
          'Source node ${edge.fromNodeId} has no output data available. '
          'Expected port: $actualOutputPort. Available ports: ${sourceNodeResult.data.keys.join(", ")}',
        );
      }

      // Store in input with proper port mapping
      // The inputPort determines which key in the input map the data will be stored
      if (portData != null) {
        input[inputPort] = portData;
      }
    }

    // Also check config for static values or variable references
    final inputConfig = config['input'] as Map<String, dynamic>?;
    if (inputConfig != null) {
      for (final entry in inputConfig.entries) {
        if (!input.containsKey(entry.key)) {
          var value = entry.value;

          // Replace variables like {{node_123.output}}
          if (value is String && value.startsWith('{{') && value.endsWith('}}')) {
            final varPath = value.substring(2, value.length - 2);
            value = _resolveVariable(varPath, memory);
          }

          input[entry.key] = value;
        }
      }
    }

    return input;
  }

  /// Resolve a variable path like "node_123.output.text"
  dynamic _resolveVariable(String path, WorkflowRuntimeMemory memory) {
    final parts = path.split('.');

    if (parts[0].startsWith('node_')) {
      final nodeId = int.tryParse(parts[0].substring(5));
      if (nodeId != null) {
        final result = memory.getNodeResult(nodeId);
        if (result != null) {
          var value = result.data;
          // Navigate through the path (result.data is always Map<String, dynamic>)
          for (var i = 1; i < parts.length; i++) {
            final nextValue = value[parts[i]];
            if (nextValue == null) return null;
            value = nextValue;
          }
          return value;
        }
      }
    } else if (parts[0] == 'var') {
      return memory.getVariable(parts.sublist(1).join('.'));
    }

    return null;
  }

  /// Get handler for node type
  NodeHandler _getHandler(String type) {
    switch (type) {
      // AI Nodes
      case 'llm':
        return LLMNode();
      case 'image':
        return ImageNode();
      case 'audio':
        return AudioNode();
      case 'embedding':
        return EmbeddingNode();
      
      // Logic Nodes
      case 'logic':
        return LogicNode();
      case 'switch':
        return SwitchNode();
      case 'compare':
        return CompareNode();
      case 'math':
        return MathNode();
      
      // Utility Nodes
      case 'http':
        return HTTPNode();
      case 'parallel':
        return ParallelNode();
      case 'loop':
        return LoopNode();
      case 'delay':
        return DelayNode();
      
      // Data Nodes
      case 'variable':
        return VariableNode();
      case 'merge':
        return MergeNode();
      case 'json_parse':
        return JsonParseNode();
      case 'json_build':
        return JsonBuildNode();
      
      // Interaction Nodes
      case 'user_input':
        return UserInputNode();
      case 'output':
        return OutputNode();
      case 'notification':
        return NotificationNode();
      
      default:
        throw Exception('Unknown node type: $type');
    }
  }
}
