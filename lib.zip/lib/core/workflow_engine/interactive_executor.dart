import 'dart:convert';
import '../storage/isar_service.dart';
import '../storage/models/workflow.dart';
import '../storage/models/workflow_node.dart';
import '../storage/models/workflow_edge.dart';
import '../storage/models/workflow_run.dart';
import '../storage/models/node_result.dart';
import 'dag_parser.dart';
import 'node_handler.dart';
import 'node_handlers/llm_node.dart';
import 'node_handlers/image_node.dart';
import 'node_handlers/audio_node.dart';
import 'node_handlers/embedding_node.dart';
import 'node_handlers/logic_node.dart';
import 'node_handlers/switch_node.dart';
import 'node_handlers/compare_node.dart';
import 'node_handlers/math_node.dart';
import 'node_handlers/http_node.dart';
import 'node_handlers/parallel_node.dart';
import 'node_handlers/loop_node.dart';
import 'node_handlers/delay_node.dart';
import 'node_handlers/variable_node.dart';
import 'node_handlers/merge_node.dart';
import 'node_handlers/json_parse_node.dart';
import 'node_handlers/json_build_node.dart';
import 'node_handlers/user_input_node.dart';
import 'node_handlers/output_node.dart';
import 'node_handlers/notification_node.dart';
import 'executor.dart'; // For WorkflowRunResult

/// Callback for getting user input
typedef UserInputCallback = Future<dynamic> Function(
  String prompt,
  String inputType,
  bool required,
  dynamic defaultValue,
);

/// Callback for showing output
typedef OutputCallback = Future<void> Function(Map<String, dynamic> output);

/// Interactive executor that pauses for user input and shows output
class InteractiveWorkflowExecutor {
  final IsarService _db = IsarService();
  final UserInputCallback? onUserInput;
  final OutputCallback? onOutput;

  InteractiveWorkflowExecutor({
    this.onUserInput,
    this.onOutput,
  });

  /// Execute workflow interactively
  Future<WorkflowRunResult> run(
    int workflowId, {
    UserInputCallback? userInputCallback,
    OutputCallback? outputCallback,
  }) async {
    final startTime = DateTime.now();
    final userInput = userInputCallback ?? onUserInput;
    final output = outputCallback ?? onOutput;

    // Create run record
    final workflowRun = WorkflowRun.create(workflowId: workflowId);
    final runId = await _db.createRun(workflowRun);

    try {
      // Load workflow data
      final Workflow? workflow = await _db.getWorkflow(workflowId);
      final nodes = await _db.getNodesByWorkflow(workflowId);
      final edges = await _db.getEdgesByWorkflow(workflowId);

      if (nodes.isEmpty) {
        throw Exception('Workflow has no nodes');
      }

      // Execute workflow interactively
      final memory = WorkflowRuntimeMemory();

      // Check if workflow has a saved execution order (linear sequential)
      final executionOrder = workflow?.getExecutionOrder();
      if (executionOrder != null && executionOrder.isNotEmpty) {
        // Use saved linear execution order (sequential: node1 -> node2 -> node3)
        final nodeMap = {for (var node in nodes) node.id: node};
        for (final nodeId in executionOrder) {
          final node = nodeMap[nodeId];
          if (node != null) {
            await _executeNodeInteractive(
              node,
              memory,
              runId,
              edges,
              userInput,
              output,
            );
          }
        }
      } else {
        // Fallback to DAG-based execution (topological sort)
        // Parse DAG
        final dag = DAGParser.parse(nodes, edges);

        // Check for cycles
        if (DAGParser.hasCycle(dag)) {
          throw Exception('Workflow contains cycles');
        }

        // Get parallel execution levels
        final levels = DAGParser.getParallelLevels(dag);

        // Execute nodes sequentially level by level to ensure proper data flow
        for (final level in levels) {
          // Execute nodes sequentially within each level to ensure data consistency
          // This is important for proper data flow between connected nodes
          for (final nodeId in level) {
            final dagNode = dag[nodeId]!;
            await _executeNodeInteractive(
              dagNode.node,
              memory,
              runId,
              edges,
              userInput,
              output,
            );
          }
        }
      }

      // Mark run as complete
      workflowRun.complete();
      await _db.updateRun(workflowRun);

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      return WorkflowRunResult(
        runId: runId,
        success: true,
        finalOutput: memory.toJson(),
        durationMs: duration,
      );
    } catch (e) {
      // Mark run as failed
      workflowRun.fail(e.toString());
      await _db.updateRun(workflowRun);

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      return WorkflowRunResult(
        runId: runId,
        success: false,
        error: e.toString(),
        finalOutput: {},
        durationMs: duration,
      );
    }
  }

  /// Execute a single node interactively
  Future<void> _executeNodeInteractive(
    WorkflowNode node,
    WorkflowRuntimeMemory memory,
    int runId,
    List<WorkflowEdge> edges,
    UserInputCallback? userInputCallback,
    OutputCallback? outputCallback,
  ) async {
    final startTime = DateTime.now();

    try {
      final config = jsonDecode(node.configJson) as Map<String, dynamic>;
      
      // Handle User Input Node
      if (node.type == 'user_input') {
        if (userInputCallback == null) {
          throw Exception('User input callback is required for user_input nodes');
        }

        final prompt = config['prompt'] as String? ?? 'Enter input:';
        final inputType = config['inputType'] as String? ?? 'text';
        final required = config['required'] as bool? ?? false;
        final defaultValue = config['defaultValue'];

        // Get user input
        final userValue = await userInputCallback(prompt, inputType, required, defaultValue);

        if (required && userValue == null) {
          throw Exception('User input is required but not provided');
        }

        // Create output
        final output = NodeOutput.success({
          'value': userValue,
          'input': userValue, // For compatibility
          'output': userValue,
          'prompt': prompt,
          'type': inputType,
        });

        // Store result
        memory.setNodeResult(node.id.toInt(), output);

        // Save to database
        final endTime = DateTime.now();
        final duration = endTime.difference(startTime).inMilliseconds;

        final nodeResult = NodeResult.create(
          runId: runId,
          nodeId: node.id,
          outputJson: jsonEncode(output.data),
          error: output.error,
          durationMs: duration,
        );

        await _db.createNodeResult(nodeResult);
        return;
      }

      // Handle Output Node
      if (node.type == 'output') {
        // Get input from connected nodes
        final input = _resolveInputFromEdges(node, edges, memory, config);
        final outputData = input['data'] ?? input['output'] ?? input;

        // Show output
        if (outputCallback != null) {
          final outputMap = outputData is Map<String, dynamic> 
              ? outputData 
              : (outputData is Map 
                  ? Map<String, dynamic>.from(outputData) 
                  : {'output': outputData});
          await outputCallback(outputMap);
        }

        // Create output
        final output = NodeOutput.success({
          'output': outputData,
          'displayType': config['displayType'] ?? 'text',
        });

        // Store result
        memory.setNodeResult(node.id.toInt(), output);

        // Save to database
        final endTime = DateTime.now();
        final duration = endTime.difference(startTime).inMilliseconds;

        final nodeResult = NodeResult.create(
          runId: runId,
          nodeId: node.id,
          outputJson: jsonEncode(output.data),
          error: output.error,
          durationMs: duration,
        );

        await _db.createNodeResult(nodeResult);
        return;
      }

      // For other nodes, use regular executor logic
      final handler = _getHandler(node.type);
      
      // Validate node configuration
      if (!handler.validate(config)) {
        throw Exception('Node ${node.name} configuration is invalid');
      }

      // Get input from connected nodes via edges
      final input = _resolveInputFromEdges(node, edges, memory, config);

      // Execute node
      final output = await handler.execute(
        input: input,
        config: config,
        memory: memory,
      );

      // Store result in memory
      memory.setNodeResult(node.id.toInt(), output);

      // Save to database
      final endTime = DateTime.now();
      final duration = endTime.difference(startTime).inMilliseconds;

      final nodeResult = NodeResult.create(
        runId: runId,
        nodeId: node.id,
        outputJson: jsonEncode(output.data),
        error: output.error,
        durationMs: duration,
      );

      await _db.createNodeResult(nodeResult);

      if (!output.success) {
        throw Exception('Node ${node.name} failed: ${output.error}');
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Resolve input from connected nodes via edges
  Map<String, dynamic> _resolveInputFromEdges(
    WorkflowNode node,
    List<WorkflowEdge> edges,
    WorkflowRuntimeMemory memory,
    Map<String, dynamic> config,
  ) {
    final input = <String, dynamic>{};

    // Get edges that connect TO this node
    final incomingEdges = edges.where((e) => e.toNodeId == node.id).toList();

    // For each incoming edge, get data from source node
    for (final edge in incomingEdges) {
      final sourceNodeResult = memory.getNodeResult(edge.fromNodeId);
      if (sourceNodeResult == null) {
        throw Exception(
          'Source node ${edge.fromNodeId} has no result. '
          'Make sure nodes are executed in the correct order.',
        );
      }

      if (!sourceNodeResult.success) {
        throw Exception(
          'Source node ${edge.fromNodeId} failed: ${sourceNodeResult.error}',
        );
      }

      // Get output port from edge (fromPort) and input port (toPort)
      // Priority: fromPort/toPort > label > default
      final outputPort = edge.fromPort ?? edge.label ?? 'output';
      final inputPort = edge.toPort ?? edge.label ?? outputPort;
      
      // For logic nodes (if, switch), check if there's a 'path' field to determine which port to use
      String actualOutputPort = outputPort;
      if (sourceNodeResult.data.containsKey('path')) {
        // Logic nodes output a 'path' field indicating which port was used (e.g., 'true', 'false', 'case1')
        final path = sourceNodeResult.data['path'] as String?;
        if (path != null) {
          // Use the path as the output port (this overrides the edge's fromPort for logic nodes)
          actualOutputPort = path;
        }
      }
      
      // Get data from the output port
      dynamic portData;
      if (sourceNodeResult.data.containsKey(actualOutputPort)) {
        // Direct port match
        portData = sourceNodeResult.data[actualOutputPort];
      } else if (sourceNodeResult.data.containsKey('output')) {
        // Fallback to 'output' key
        portData = sourceNodeResult.data['output'];
      } else if (sourceNodeResult.data.isNotEmpty) {
        // If port not found, use first available value (for backward compatibility)
        portData = sourceNodeResult.data.values.first;
      } else {
        throw Exception(
          'Source node ${edge.fromNodeId} has no output data available. '
          'Expected port: $actualOutputPort. Available ports: ${sourceNodeResult.data.keys.join(", ")}',
        );
      }

      // Store in input with proper port mapping
      // The inputPort determines which key in the input map the data will be stored
      if (portData != null) {
        input[inputPort] = portData;
      }
    }

    return input;
  }

  /// Get handler for node type
  NodeHandler _getHandler(String type) {
    switch (type) {
      // AI Nodes
      case 'llm':
        return LLMNode();
      case 'image':
      case 'image_generation':
        return ImageNode();
      case 'audio':
        return AudioNode();
      case 'embedding':
        return EmbeddingNode();
      
      // Logic Nodes
      case 'logic':
      case 'if':
        return LogicNode();
      case 'switch':
        return SwitchNode();
      case 'compare':
        return CompareNode();
      case 'math':
        return MathNode();
      
      // Utility Nodes
      case 'http':
        return HTTPNode();
      case 'parallel':
        return ParallelNode();
      case 'loop':
        return LoopNode();
      case 'delay':
        return DelayNode();
      
      // Data Nodes
      case 'variable':
        return VariableNode();
      case 'merge':
        return MergeNode();
      case 'json_parse':
        return JsonParseNode();
      case 'json_build':
        return JsonBuildNode();
      
      // Interaction Nodes
      case 'user_input':
        return UserInputNode();
      case 'output':
        return OutputNode();
      case 'notification':
        return NotificationNode();
      
      default:
        throw Exception('Unknown node type: $type');
    }
  }
}
