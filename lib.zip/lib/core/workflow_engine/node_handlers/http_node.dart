import '../node_handler.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

/// HTTP Request Node
class HTTPNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final url = config['url'] as String? ?? input['url'] as String?;
      if (url == null) {
        return NodeOutput.failure('URL not specified');
      }

      final method = (config['method'] as String? ?? 'GET').toUpperCase();
      final headers = config['headers'] as Map<String, dynamic>? ?? {};
      final body = config['body'] ?? input['body'];

      http.Response response;

      switch (method) {
        case 'GET':
          response = await http.get(
            Uri.parse(url),
            headers: headers.cast<String, String>(),
          );
          break;
        case 'POST':
          response = await http.post(
            Uri.parse(url),
            headers: headers.cast<String, String>(),
            body: body is Map ? jsonEncode(body) : body,
          );
          break;
        case 'PUT':
          response = await http.put(
            Uri.parse(url),
            headers: headers.cast<String, String>(),
            body: body is Map ? jsonEncode(body) : body,
          );
          break;
        case 'DELETE':
          response = await http.delete(
            Uri.parse(url),
            headers: headers.cast<String, String>(),
          );
          break;
        default:
          return NodeOutput.failure('Unsupported HTTP method: $method');
      }

      // Try to parse JSON response
      dynamic responseData;
      try {
        responseData = jsonDecode(response.body);
      } catch (e) {
        responseData = response.body;
      }

      return NodeOutput.success({
        'status': response.statusCode,
        'data': responseData,
        'headers': response.headers,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('url') || config.containsKey('method');
  }
}
