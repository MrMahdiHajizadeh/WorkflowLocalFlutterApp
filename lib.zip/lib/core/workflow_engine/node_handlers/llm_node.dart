import '../node_handler.dart';
import '../../ai_router/router.dart';
import '../../ai_router/models.dart';
import '../../storage/isar_service.dart';
import '../../security/encryption.dart';

/// LLM Node Handler for text generation
class LLMNode extends NodeHandler {
  final AIRouter _router = AIRouter();
  final IsarService _db = IsarService();
  final EncryptionService _encryption = EncryptionService();

  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      // Get model configuration
      final modelId = config['modelId'] as int?;
      if (modelId == null) {
        return NodeOutput.failure('Model ID not specified');
      }

      final model = await _db.getModel(modelId);
      if (model == null) {
        return NodeOutput.failure('Model not found');
      }

      // Decrypt API key
      String decryptedApiKey;
      try {
        decryptedApiKey = _encryption.decryptText(model.apiKeyEncrypted);
      } catch (e) {
        return NodeOutput.failure('Failed to decrypt API key: $e');
      }

      // Validate base URL
      if (model.baseUrl.isEmpty) {
        return NodeOutput.failure('Base URL is not configured for this model');
      }

      // Resolve prompt - can use {{variable}} syntax or inputMapping
      String prompt = '';
      
      // First, try to get prompt from inputMapping (if configured)
      final inputMapping = config['inputMapping'] as String?;
      if (inputMapping != null && inputMapping.trim().isNotEmpty) {
        if (inputMapping.contains('{{')) {
          // Resolve variables in inputMapping
          prompt = _resolveVariables(inputMapping, input, memory);
        } else {
          // Direct mapping - use inputMapping as key to get value from input
          prompt = input[inputMapping]?.toString() ?? '';
        }
      }
      
      // If no prompt from inputMapping, try config prompt
      if (prompt.trim().isEmpty) {
        final configPrompt = config['prompt'] as String?;
        if (configPrompt != null && configPrompt.trim().isNotEmpty) {
          prompt = configPrompt.trim();
          if (prompt.contains('{{')) {
            // Replace variables in prompt
            prompt = _resolveVariables(prompt, input, memory);
          }
        }
      }
      
      // If still no prompt, try to get from input ports (connected nodes)
      if (prompt.trim().isEmpty) {
        // Try input['input'] first (from connected node output port 'input')
        // Then try input['prompt'] (if someone connected to 'prompt' port)
        prompt = (input['input'] ?? input['prompt'] ?? '').toString().trim();
      }

      // Validate prompt is not empty
      if (prompt.trim().isEmpty) {
        return NodeOutput.failure('Prompt is required but not provided. Please configure prompt in node settings or provide input data from a connected node.');
      }

      // Build parameters from config
      final parameters = <String, dynamic>{
        if (config.containsKey('temperature')) 'temperature': config['temperature'],
        if (config.containsKey('maxTokens')) 'max_tokens': config['maxTokens'],
        if (config.containsKey('topP')) 'top_p': config['topP'],
        if (config.containsKey('frequencyPenalty')) 'frequency_penalty': config['frequencyPenalty'],
        if (config.containsKey('presencePenalty')) 'presence_penalty': config['presencePenalty'],
        ...?config['parameters'] as Map<String, dynamic>?,
      };

      // Build request with decrypted API key
      final request = AIRequest(
        modelId: model.name,
        provider: model.provider,
        baseUrl: model.baseUrl,
        apiKey: decryptedApiKey, // Decrypted API key
        modelType: 'llm',
        inputs: {
          'prompt': prompt,
          'systemPrompt': config['systemPrompt'],
          'messages': input['messages'] ?? config['messages'],
        },
        parameters: parameters,
        streaming: config['streaming'] ?? false,
      );

      // Execute request
      AIResponse response;
      try {
        response = await _router.send(request);
      } catch (e) {
        // Provide more detailed error messages
        String errorMessage = 'Failed to connect to ${model.provider} API';
        if (e.toString().contains('401') || e.toString().contains('Unauthorized')) {
          errorMessage = 'Invalid API key. Please check your API key in model settings.';
        } else if (e.toString().contains('404') || e.toString().contains('Not Found')) {
          errorMessage = 'API endpoint not found. Please check the base URL: ${model.baseUrl}';
        } else if (e.toString().contains('timeout')) {
          errorMessage = 'Request timeout. The server may be slow or unreachable.';
        } else if (e.toString().contains('Failed host lookup')) {
          errorMessage = 'Cannot reach server. Please check the base URL: ${model.baseUrl}';
        } else {
          errorMessage = 'API Error: $e';
        }
        return NodeOutput.failure(errorMessage);
      }

      // Validate response
      if (response.text == null || response.text!.isEmpty) {
        // Try to get error from raw response
        final errorMsg = response.raw['error']?['message'] ?? 
                        response.raw['error']?['type'] ?? 
                        'Empty response from ${model.provider} API';
        return NodeOutput.failure('$errorMsg. Raw response: ${response.raw.toString().substring(0, 200)}');
      }

      // Return output with consistent structure
      return NodeOutput.success({
        'text': response.text,
        'raw': response.raw,
        // Main output port
        'output': response.text,
        // Additional data
        'metadata': {
          'model': model.name,
          'provider': model.provider,
          'baseUrl': model.baseUrl,
          'tokens': response.raw['usage']?['total_tokens'],
          'model_used': response.raw['model'],
          'finish_reason': response.raw['choices']?[0]?['finish_reason'],
        },
      });
    } catch (e) {
      return NodeOutput.failure('Unexpected error: $e');
    }
  }

  /// Resolve variables in prompt string (e.g., {{input}}, {{node_1.output}})
  String _resolveVariables(String prompt, Map<String, dynamic> input, WorkflowRuntimeMemory memory) {
    String result = prompt;
    
    // Replace {{input}} with actual input value
    if (result.contains('{{input}}')) {
      final inputValue = input['input'] ?? input.values.firstOrNull ?? '';
      result = result.replaceAll('{{input}}', inputValue.toString());
    }
    
    // Replace other variables like {{node_1.output}}
    final regex = RegExp(r'\{\{([^}]+)\}\}');
    result = result.replaceAllMapped(regex, (match) {
      final varPath = match.group(1) ?? '';
      
      // Check if it's a node reference
      if (varPath.startsWith('node_')) {
        final parts = varPath.split('.');
        final nodeIdStr = parts[0].substring(5); // Remove 'node_' prefix
        final nodeId = int.tryParse(nodeIdStr);
        if (nodeId != null) {
          final nodeResult = memory.getNodeResult(nodeId);
          if (nodeResult != null && nodeResult.success) {
            dynamic value = nodeResult.data;
            for (var i = 1; i < parts.length; i++) {
              if (value is Map) {
                value = value[parts[i]];
                if (value == null) return '';
              } else {
                return '';
              }
            }
            return value.toString();
          }
        }
      }
      
      // Check input map
      if (input.containsKey(varPath)) {
        return input[varPath].toString();
      }
      
      // Check memory variables
      final memValue = memory.getVariable(varPath);
      if (memValue != null) {
        return memValue.toString();
      }
      
      // Return original if not found
      final original = match.group(0);
      return original ?? '';
    });
    
    return result;
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('modelId') && 
           (config.containsKey('prompt') || config.containsKey('inputMapping'));
  }
}
