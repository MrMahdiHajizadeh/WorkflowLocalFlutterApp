import '../node_handler.dart';
import '../../ai_router/router.dart';
import '../../ai_router/models.dart';
import '../../storage/isar_service.dart';
import '../../security/encryption.dart';

/// Image Generation Node Handler
class ImageNode extends NodeHandler {
  final AIRouter _router = AIRouter();
  final IsarService _db = IsarService();
  final EncryptionService _encryption = EncryptionService();

  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final modelId = config['modelId'] as int?;
      if (modelId == null) {
        return NodeOutput.failure('Model ID not specified');
      }

      final model = await _db.getModel(modelId);
      if (model == null) {
        return NodeOutput.failure('Model not found');
      }

      // Decrypt API key
      String decryptedApiKey;
      try {
        decryptedApiKey = _encryption.decryptText(model.apiKeyEncrypted);
      } catch (e) {
        return NodeOutput.failure('Failed to decrypt API key: $e');
      }

      // Validate base URL
      if (model.baseUrl.isEmpty) {
        return NodeOutput.failure('Base URL is not configured for this model');
      }

      // Resolve prompt from input - can use {{variable}} syntax
      String prompt = '';
      
      // First, try to get prompt from input mapping
      final promptMapping = config['promptMapping'] ?? '{{input}}';
      if (promptMapping.contains('{{')) {
        prompt = _resolveVariables(promptMapping, input, memory);
      } else {
        // Direct mapping
        prompt = input[promptMapping] ?? input['prompt'] ?? input['input'] ?? '';
      }
      
      // Fallback to config prompt if input is empty
      if (prompt.isEmpty) {
        prompt = config['prompt'] ?? '';
      }
      
      if (prompt.isEmpty) {
        return NodeOutput.failure('Prompt is required but not provided');
      }

      // Build parameters from config
      final parameters = <String, dynamic>{
        if (config.containsKey('size')) 'size': config['size'],
        if (config.containsKey('quality')) 'quality': config['quality'],
        if (config.containsKey('style')) 'style': config['style'],
        ...?config['parameters'] as Map<String, dynamic>?,
      };

      // Build request with decrypted API key
      final request = AIRequest(
        modelId: model.name,
        provider: model.provider,
        baseUrl: model.baseUrl,
        apiKey: decryptedApiKey, // Decrypted API key
        modelType: 'image',
        inputs: {
          'prompt': prompt,
        },
        parameters: parameters,
      );

      // Execute request
      AIResponse response;
      try {
        response = await _router.send(request);
      } catch (e) {
        // Provide more detailed error messages
        String errorMessage = 'Failed to connect to ${model.provider} API';
        if (e.toString().contains('401') || e.toString().contains('Unauthorized')) {
          errorMessage = 'Invalid API key. Please check your API key in model settings.';
        } else if (e.toString().contains('404') || e.toString().contains('Not Found')) {
          errorMessage = 'API endpoint not found. Please check the base URL: ${model.baseUrl}';
        } else if (e.toString().contains('timeout')) {
          errorMessage = 'Request timeout. The server may be slow or unreachable.';
        } else if (e.toString().contains('Failed host lookup')) {
          errorMessage = 'Cannot reach server. Please check the base URL: ${model.baseUrl}';
        } else {
          errorMessage = 'API Error: $e';
        }
        return NodeOutput.failure(errorMessage);
      }

      // Validate response
      if (response.imagePath == null || response.imagePath!.isEmpty) {
        // Try to get error from raw response
        final errorMsg = response.raw['error']?['message'] ?? 
                        response.raw['error']?['type'] ?? 
                        'Empty response from ${model.provider} API. No image generated.';
        return NodeOutput.failure('$errorMsg. Raw response: ${response.raw.toString().substring(0, 200)}');
      }

      // Return output with consistent structure
      // Include all output ports: image_url, image_data, and output (for compatibility)
      final outputData = {
        'image_url': response.imagePath,
        'image_data': response.raw,
        'image_path': response.imagePath,
        'thumbnail': response.thumbnail ?? response.imagePath,
        'raw': response.raw,
        'prompt': prompt, // Include the resolved prompt in output
        // Main output port - include full image data object for output node
        'output': {
          'image_url': response.imagePath,
          'image_path': response.imagePath,
          'image_data': response.raw,
          'thumbnail': response.thumbnail ?? response.imagePath,
          'prompt': prompt,
        },
        // Additional metadata
        'metadata': {
          'model': model.name,
          'provider': model.provider,
          'baseUrl': model.baseUrl,
          'prompt': prompt,
          'size': config['size'],
          'quality': config['quality'],
          'style': config['style'],
        },
      };
      
      return NodeOutput.success(outputData);
    } catch (e) {
      return NodeOutput.failure('Unexpected error: $e');
    }
  }

  /// Resolve variables in prompt string (e.g., {{input}}, {{node_1.output}})
  String _resolveVariables(String promptMapping, Map<String, dynamic> input, WorkflowRuntimeMemory memory) {
    String result = promptMapping;
    
    // Replace {{input}} with actual input value
    if (result.contains('{{input}}')) {
      final inputValue = input['input'] ?? input.values.firstOrNull ?? '';
      result = result.replaceAll('{{input}}', inputValue.toString());
    }
    
    // Replace other variables like {{node_1.output}}
    final regex = RegExp(r'\{\{([^}]+)\}\}');
    result = result.replaceAllMapped(regex, (match) {
      final varPath = match.group(1) ?? '';
      
      // Check if it's a node reference
      if (varPath.startsWith('node_')) {
        final parts = varPath.split('.');
        final nodeIdStr = parts[0].substring(5); // Remove 'node_' prefix
        final nodeId = int.tryParse(nodeIdStr);
        if (nodeId != null) {
          final nodeResult = memory.getNodeResult(nodeId);
          if (nodeResult != null && nodeResult.success) {
            dynamic value = nodeResult.data;
            for (var i = 1; i < parts.length; i++) {
              if (value is Map) {
                value = value[parts[i]];
                if (value == null) return '';
              } else {
                return '';
              }
            }
            return value.toString();
          }
        }
      }
      
      // Check input map
      if (input.containsKey(varPath)) {
        return input[varPath].toString();
      }
      
      // Check memory variables
      final memValue = memory.getVariable(varPath);
      if (memValue != null) {
        return memValue.toString();
      }
      
      // Return original if not found
      final original = match.group(0);
      return original ?? '';
    });
    
    return result;
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('modelId');
  }
}
