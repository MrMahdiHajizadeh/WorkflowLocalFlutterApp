import '../node_handler.dart';

/// Logic Node (If/Else conditional)
class LogicNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      // Check if condition is provided via input port
      dynamic conditionValue;
      if (input.containsKey('condition')) {
        // If condition is provided via input port, use it directly
        conditionValue = input['condition'];
        // For boolean condition, evaluate directly
        if (conditionValue is bool) {
          final path = conditionValue ? 'true' : 'false';
          final outputData = <String, dynamic>{
            'result': conditionValue,
            'path': path,
            'condition': conditionValue,
            path: conditionValue,
            'output': conditionValue,
          };
          return NodeOutput.success(outputData);
        }
        // If condition is a value, we need to compare it
        // Use leftValue as the condition value
        final leftValue = conditionValue;
        final rightValueStr = config['rightValue'] as String? ?? '';
        final rightValue = _resolveValue(rightValueStr, input, memory);
        final operator = config['operator'] as String? ?? '==';
        
        if (rightValue == null) {
          return NodeOutput.failure('Right value is missing');
        }
        
        final result = _evaluateCondition(leftValue, operator, rightValue);
        final path = result ? 'true' : 'false';
        
        final outputData = <String, dynamic>{
          'result': result,
          'path': path,
          'leftValue': leftValue,
          'rightValue': rightValue,
          'operator': operator,
          path: leftValue,
          'output': leftValue,
        };
        
        return NodeOutput.success(outputData);
      }
      
      // Otherwise, use config values (leftValue and rightValue)
      // Resolve left value
      final leftValueStr = config['leftValue'] as String? ?? '';
      final leftValue = _resolveValue(leftValueStr, input, memory);
      
      // Resolve right value
      final rightValueStr = config['rightValue'] as String? ?? '';
      final rightValue = _resolveValue(rightValueStr, input, memory);
      
      final operator = config['operator'] as String? ?? '==';

      if (leftValue == null || rightValue == null) {
        return NodeOutput.failure('Left or right value is missing');
      }

      final result = _evaluateCondition(leftValue, operator, rightValue);
      final path = result ? 'true' : 'false';

      // Return output with data in the appropriate port
      // For If node: 'true' or 'false' port contains the data
      final outputData = <String, dynamic>{
        'result': result,
        'path': path,
        'leftValue': leftValue,
        'rightValue': rightValue,
        'operator': operator,
        // Put output data in the correct port (true/false)
        path: leftValue, // Pass through the input data to the selected port
        // Also include in 'output' for backward compatibility
        'output': leftValue,
      };

      return NodeOutput.success(outputData);
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  /// Resolve a value from string (can be {{variable}} or static value)
  dynamic _resolveValue(String valueStr, Map<String, dynamic> input, WorkflowRuntimeMemory memory) {
    if (valueStr.trim().isEmpty) {
      return null;
    }
    
    // Check if it's a variable reference
    if (valueStr.contains('{{') && valueStr.contains('}}')) {
      final regex = RegExp(r'\{\{([^}]+)\}\}');
      final match = regex.firstMatch(valueStr);
      if (match != null) {
        final varPath = match.group(1) ?? '';
        
        // Check if it's a node reference
        if (varPath.startsWith('node_')) {
          final parts = varPath.split('.');
          final nodeIdStr = parts[0].substring(5);
          final nodeId = int.tryParse(nodeIdStr);
          if (nodeId != null) {
            final nodeResult = memory.getNodeResult(nodeId);
            if (nodeResult != null && nodeResult.success) {
              dynamic value = nodeResult.data;
              for (var i = 1; i < parts.length; i++) {
                if (value is Map) {
                  value = value[parts[i]];
                  if (value == null) return null;
                } else {
                  return null;
                }
              }
              return value;
            }
          }
        }
        
        // Check input map
        if (input.containsKey(varPath)) {
          return input[varPath];
        }
        
        // Check memory variables
        final memValue = memory.getVariable(varPath);
        if (memValue != null) {
          return memValue;
        }
        
        // If variable not found, try to get from input with key 'input'
        if (varPath == 'input') {
          return input['input'] ?? input.values.firstOrNull;
        }
      }
    }
    
    // Try to parse as number
    final numValue = num.tryParse(valueStr);
    if (numValue != null) {
      return numValue;
    }
    
    // Return as string
    return valueStr;
  }

  bool _evaluateCondition(dynamic left, String operator, dynamic right) {
    switch (operator) {
      case '==':
        return left == right;
      case '!=':
        return left != right;
      case '>':
        return (left as num) > (right as num);
      case '<':
        return (left as num) < (right as num);
      case '>=':
        return (left as num) >= (right as num);
      case '<=':
        return (left as num) <= (right as num);
      case 'contains':
        return left.toString().contains(right.toString());
      case 'startsWith':
        return left.toString().startsWith(right.toString());
      case 'endsWith':
        return left.toString().endsWith(right.toString());
      default:
        return false;
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    // If node can work with either:
    // 1. Input port 'condition' providing a boolean or value (validated at runtime)
    // 2. Config 'leftValue' and 'rightValue' for comparison
    // So we only validate that operator exists if leftValue/rightValue are provided
    if (config.containsKey('leftValue') && config.containsKey('rightValue')) {
      return config.containsKey('operator');
    }
    // If no leftValue/rightValue, assume condition will come from input port
    return true;
  }
}
