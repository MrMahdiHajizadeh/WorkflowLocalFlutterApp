import '../node_handler.dart';

/// Output Node (displays final output)
class OutputNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    // Output node input port is 'data', but also accept 'output' for backward compatibility
    final outputData = input['data'] ?? input['output'] ?? input;

    return NodeOutput.success({
      'output': outputData,
      'displayType': config['displayType'] ?? 'text',
    });
  }
}
