import 'dart:math' as math;
import '../node_handler.dart';

/// Math Node (mathematical operations)
class MathNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final operation = config['operation'] as String?;
      if (operation == null) {
        return NodeOutput.failure('Operation not specified');
      }

      final result = _performOperation(operation, input, config);

      return NodeOutput.success({
        'result': result,
        'operation': operation,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  dynamic _performOperation(String operation, Map<String, dynamic> input, Map<String, dynamic> config) {
    final a = (input['a'] ?? config['a'] ?? 0).toDouble();
    final b = (input['b'] ?? config['b'] ?? 0).toDouble();

    switch (operation) {
      case 'add':
        return a + b;
      case 'subtract':
        return a - b;
      case 'multiply':
        return a * b;
      case 'divide':
        return b != 0 ? a / b : double.nan;
      case 'modulo':
        return a % b;
      case 'power':
        return math.pow(a, b);
      case 'sqrt':
        return math.sqrt(a);
      case 'abs':
        return a.abs();
      case 'round':
        return a.round();
      case 'floor':
        return a.floor();
      case 'ceil':
        return a.ceil();
      case 'min':
        return math.min(a, b);
      case 'max':
        return math.max(a, b);
      case 'random':
        return math.Random().nextDouble() * (b - a) + a;
      default:
        throw Exception('Unknown operation: $operation');
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('operation');
  }
}
