import 'dart:convert';
import '../node_handler.dart';

/// JSON Build Node (builds JSON string from object)
class JsonBuildNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final data = input['data'] ?? config['data'] ?? input;
      final pretty = config['pretty'] as bool? ?? false;

      String jsonString;
      if (pretty) {
        const encoder = JsonEncoder.withIndent('  ');
        jsonString = encoder.convert(data);
      } else {
        jsonString = jsonEncode(data);
      }

      return NodeOutput.success({
        'json': jsonString,
        'length': jsonString.length,
      });
    } catch (e) {
      return NodeOutput.failure('JSON build error: ${e.toString()}');
    }
  }
}
