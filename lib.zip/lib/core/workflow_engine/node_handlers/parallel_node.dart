import '../node_handler.dart';

/// Parallel Node (executes multiple branches in parallel)
class ParallelNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    // This is a structural node - actual parallelization is handled by executor
    return NodeOutput.success({
      'status': 'parallel_container',
      'input': input,
    });
  }
}
