import '../node_handler.dart';

/// Merge Node (combines multiple inputs into one output)
class MergeNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final strategy = config['strategy'] as String? ?? 'object';

      switch (strategy) {
        case 'object':
          // Merge all inputs into a single object
          return NodeOutput.success({
            'merged': {...input},
          });

        case 'array':
          // Combine all input values into an array
          final array = input.values.toList();
          return NodeOutput.success({
            'merged': array,
          });

        case 'concat':
          // Concatenate string values
          final concatenated = input.values.map((v) => v.toString()).join('');
          return NodeOutput.success({
            'merged': concatenated,
          });

        case 'sum':
          // Sum numeric values
          var sum = 0.0;
          for (final value in input.values) {
            if (value is num) {
              sum += value;
            }
          }
          return NodeOutput.success({
            'merged': sum,
          });

        default:
          return NodeOutput.failure('Unknown merge strategy: $strategy');
      }
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }
}
