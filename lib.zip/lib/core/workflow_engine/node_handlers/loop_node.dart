import '../node_handler.dart';

/// Loop Node (iterates over a list with safety counter)
class LoopNode extends NodeHandler {
  static const int maxIterations = 1000; // Safety limit

  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final items = input['items'] as List? ?? config['items'] as List? ?? [];
      final counter = memory.getVariable('loop_counter_${config['id']}') as int? ?? 0;

      if (counter >= maxIterations) {
        return NodeOutput.failure('Loop iteration limit exceeded');
      }

      if (counter >= items.length) {
        return NodeOutput.success({
          'done': true,
          'results': memory.getVariable('loop_results_${config['id']}') ?? [],
        });
      }

      final currentItem = items[counter];
      memory.setVariable('loop_counter_${config['id']}', counter + 1);

      return NodeOutput.success({
        'done': false,
        'currentItem': currentItem,
        'index': counter,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }
}
