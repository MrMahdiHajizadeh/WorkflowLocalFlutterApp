import '../node_handler.dart';

/// Compare Node (compare two values)
class CompareNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      // Resolve value A - check input ports first, then config
      dynamic valueA;
      if (input.containsKey('a')) {
        valueA = input['a'];
      } else {
        final valueAStr = config['valueA'] as String? ?? '';
        valueA = _resolveValue(valueAStr, input, memory);
      }
      
      // Resolve value B - check input ports first, then config
      dynamic valueB;
      if (input.containsKey('b')) {
        valueB = input['b'];
      } else {
        final valueBStr = config['valueB'] as String? ?? '';
        valueB = _resolveValue(valueBStr, input, memory);
      }
      
      final operator = config['operator'] as String? ?? '==';

      if (valueA == null || valueB == null) {
        return NodeOutput.failure('Value A or Value B is missing');
      }

      final result = _compare(valueA, valueB, operator);

      return NodeOutput.success({
        'result': result,
        'valueA': valueA,
        'valueB': valueB,
        'operator': operator,
        // Also include in 'output' for backward compatibility
        'output': result,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  /// Resolve a value from string (can be {{variable}} or static value)
  dynamic _resolveValue(String valueStr, Map<String, dynamic> input, WorkflowRuntimeMemory memory) {
    if (valueStr.trim().isEmpty) {
      return null;
    }
    
    // Check if it's a variable reference
    if (valueStr.contains('{{') && valueStr.contains('}}')) {
      final regex = RegExp(r'\{\{([^}]+)\}\}');
      final match = regex.firstMatch(valueStr);
      if (match != null) {
        final varPath = match.group(1) ?? '';
        
        // Check if it's a node reference
        if (varPath.startsWith('node_')) {
          final parts = varPath.split('.');
          final nodeIdStr = parts[0].substring(5);
          final nodeId = int.tryParse(nodeIdStr);
          if (nodeId != null) {
            final nodeResult = memory.getNodeResult(nodeId);
            if (nodeResult != null && nodeResult.success) {
              dynamic value = nodeResult.data;
              for (var i = 1; i < parts.length; i++) {
                if (value is Map) {
                  value = value[parts[i]];
                  if (value == null) return null;
                } else {
                  return null;
                }
              }
              return value;
            }
          }
        }
        
        // Check input map
        if (input.containsKey(varPath)) {
          return input[varPath];
        }
        
        // Check memory variables
        final memValue = memory.getVariable(varPath);
        if (memValue != null) {
          return memValue;
        }
        
        // If variable not found, try to get from input with key 'input'
        if (varPath == 'input') {
          return input['input'] ?? input.values.firstOrNull;
        }
      }
    }
    
    // Try to parse as number
    final numValue = num.tryParse(valueStr);
    if (numValue != null) {
      return numValue;
    }
    
    // Return as string
    return valueStr;
  }

  bool _compare(dynamic v1, dynamic v2, String operator) {
    switch (operator) {
      case '==':
        return v1 == v2;
      case '!=':
        return v1 != v2;
      case '>':
        return (v1 as num) > (v2 as num);
      case '<':
        return (v1 as num) < (v2 as num);
      case '>=':
        return (v1 as num) >= (v2 as num);
      case '<=':
        return (v1 as num) <= (v2 as num);
      case 'contains':
        return v1.toString().contains(v2.toString());
      case 'startsWith':
        return v1.toString().startsWith(v2.toString());
      case 'endsWith':
        return v1.toString().endsWith(v2.toString());
      case 'in':
        if (v2 is List) return v2.contains(v1);
        return false;
      default:
        return false;
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('operator');
  }
}
