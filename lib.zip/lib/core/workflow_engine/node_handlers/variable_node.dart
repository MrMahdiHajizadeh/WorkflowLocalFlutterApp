import '../node_handler.dart';

/// Variable Node (stores and retrieves variables)
class VariableNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final operation = config['operation'] as String? ?? 'set';
      final variableName = config['variableName'] as String?;

      if (variableName == null) {
        return NodeOutput.failure('Variable name not specified');
      }

      switch (operation) {
        case 'set':
          final value = input['value'] ?? config['value'];
          memory.setVariable(variableName, value);
          return NodeOutput.success({
            'operation': 'set',
            'variable': variableName,
            'value': value,
          });

        case 'get':
          final value = memory.getVariable(variableName);
          return NodeOutput.success({
            'operation': 'get',
            'variable': variableName,
            'value': value,
          });

        default:
          return NodeOutput.failure('Unknown operation: $operation');
      }
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('variableName');
  }
}
