import '../node_handler.dart';

/// User Input Node (prompts user for input during workflow execution)
class UserInputNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final prompt = config['prompt'] as String? ?? 'Enter input:';
      final inputType = config['inputType'] as String? ?? 'text';
      final required = config['required'] as bool? ?? false;

      // Store prompt for UI to display
      // In a real implementation, this would pause execution and wait for user input
      // For now, we'll use a placeholder or default value
      
      final defaultValue = config['defaultValue'];
      final userValue = input['userInput'] ?? defaultValue;

      if (required && userValue == null) {
        return NodeOutput.failure('User input is required but not provided');
      }

      return NodeOutput.success({
        'value': userValue,
        'prompt': prompt,
        'type': inputType,
        'status': 'waiting_for_input',
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('prompt');
  }
}
