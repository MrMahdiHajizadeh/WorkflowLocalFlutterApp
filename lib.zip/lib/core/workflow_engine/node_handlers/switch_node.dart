import '../node_handler.dart';

/// Switch Node (multi-branch switch statement)
class SwitchNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      // Resolve input value
      final valueStr = config['value'] as String? ?? '{{input}}';
      final value = _resolveValue(valueStr, input, memory);
      
      if (value == null) {
        return NodeOutput.failure('Input value is missing');
      }

      final cases = config['cases'] as Map<String, dynamic>? ?? {};
      final defaultCase = config['default'];

      // Find matching case
      final valueString = value.toString();
      String matchedPath = 'default';
      dynamic outputData = defaultCase;
      
      for (final entry in cases.entries) {
        if (entry.key == valueString) {
          matchedPath = entry.key;
          outputData = entry.value;
          break;
        }
      }

      // Return output with data in the appropriate port
      final result = <String, dynamic>{
        'matched': matchedPath,
        'path': matchedPath,
        'value': value,
        // Put output data in the correct port
        matchedPath: outputData,
        // Also include in 'output' for backward compatibility
        'output': outputData,
      };

      return NodeOutput.success(result);
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  /// Resolve a value from string (can be {{variable}} or static value)
  dynamic _resolveValue(String valueStr, Map<String, dynamic> input, WorkflowRuntimeMemory memory) {
    if (valueStr.trim().isEmpty) {
      return input['value'] ?? input['input'] ?? input.values.firstOrNull;
    }
    
    // Check if it's a variable reference
    if (valueStr.contains('{{') && valueStr.contains('}}')) {
      final regex = RegExp(r'\{\{([^}]+)\}\}');
      final match = regex.firstMatch(valueStr);
      if (match != null) {
        final varPath = match.group(1) ?? '';
        
        // Check if it's a node reference
        if (varPath.startsWith('node_')) {
          final parts = varPath.split('.');
          final nodeIdStr = parts[0].substring(5);
          final nodeId = int.tryParse(nodeIdStr);
          if (nodeId != null) {
            final nodeResult = memory.getNodeResult(nodeId);
            if (nodeResult != null && nodeResult.success) {
              dynamic value = nodeResult.data;
              for (var i = 1; i < parts.length; i++) {
                if (value is Map) {
                  value = value[parts[i]];
                  if (value == null) return null;
                } else {
                  return null;
                }
              }
              return value;
            }
          }
        }
        
        // Check input map
        if (input.containsKey(varPath)) {
          return input[varPath];
        }
        
        // Check memory variables
        final memValue = memory.getVariable(varPath);
        if (memValue != null) {
          return memValue;
        }
        
        // If variable not found, try to get from input with key 'input'
        if (varPath == 'input') {
          return input['input'] ?? input.values.firstOrNull;
        }
      }
    }
    
    // Try to parse as number
    final numValue = num.tryParse(valueStr);
    if (numValue != null) {
      return numValue;
    }
    
    // Return as string
    return valueStr;
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('cases');
  }
}
