import '../node_handler.dart';

/// Delay Node (pauses execution for specified duration)
class DelayNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final milliseconds = input['milliseconds'] as int? ?? 
                          config['milliseconds'] as int? ?? 
                          1000;

      final startTime = DateTime.now();
      await Future.delayed(Duration(milliseconds: milliseconds));
      final endTime = DateTime.now();

      return NodeOutput.success({
        'delayed_ms': milliseconds,
        'actual_ms': endTime.difference(startTime).inMilliseconds,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }
}
