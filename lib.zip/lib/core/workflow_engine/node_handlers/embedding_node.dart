import '../node_handler.dart';
import '../../ai_router/router.dart';
import '../../ai_router/models.dart';
import '../../storage/isar_service.dart';

/// Embedding Node Handler
class EmbeddingNode extends NodeHandler {
  final AIRouter _router = AIRouter();
  final IsarService _db = IsarService();

  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final modelId = config['modelId'] as int?;
      if (modelId == null) {
        return NodeOutput.failure('Model ID not specified');
      }

      final model = await _db.getModel(modelId);
      if (model == null) {
        return NodeOutput.failure('Model not found');
      }

      final request = AIRequest(
        modelId: model.name,
        provider: model.provider,
        baseUrl: model.baseUrl,
        apiKey: model.apiKeyEncrypted,
        modelType: 'embedding',
        inputs: {
          'text': input['text'] ?? config['text'] ?? '',
        },
        parameters: config['parameters'] ?? {},
      );

      final response = await _router.send(request);

      return NodeOutput.success({
        'embedding': response.embedding,
        'raw': response.raw,
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('modelId');
  }
}
