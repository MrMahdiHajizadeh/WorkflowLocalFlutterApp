import 'dart:convert';
import '../node_handler.dart';

/// JSON Parse Node (parses JSON string to object)
class JsonParseNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final jsonString = input['json'] as String? ?? config['json'] as String?;
      
      if (jsonString == null) {
        return NodeOutput.failure('JSON string not provided');
      }

      final parsed = jsonDecode(jsonString);

      return NodeOutput.success({
        'parsed': parsed,
        'type': parsed is List ? 'array' : 'object',
      });
    } catch (e) {
      return NodeOutput.failure('JSON parse error: ${e.toString()}');
    }
  }

  @override
  bool validate(Map<String, dynamic> config) {
    return config.containsKey('json') || config.containsKey('input');
  }
}
