import '../node_handler.dart';

/// Notification Node (sends notifications to user)
class NotificationNode extends NodeHandler {
  @override
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  }) async {
    try {
      final title = config['title'] as String? ?? input['title'] as String? ?? 'Notification';
      final message = config['message'] as String? ?? input['message'] as String? ?? '';
      final type = config['type'] as String? ?? 'info'; // info, success, warning, error
      final duration = config['duration'] as int? ?? 3000; // milliseconds

      // In a real implementation, this would trigger platform notification
      // For now, we'll just return the notification details
      
      return NodeOutput.success({
        'title': title,
        'message': message,
        'type': type,
        'duration': duration,
        'status': 'sent',
        'timestamp': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      return NodeOutput.failure(e.toString());
    }
  }
}
