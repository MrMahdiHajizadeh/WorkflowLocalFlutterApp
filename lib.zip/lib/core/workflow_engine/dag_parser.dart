import '../storage/models/workflow_node.dart';
import '../storage/models/workflow_edge.dart';

/// Represents a node in the DAG with dependencies
class DAGNode {
  final WorkflowNode node;
  final List<int> dependencies; // Node IDs this depends on
  final List<int> dependents; // Node IDs that depend on this

  DAGNode({
    required this.node,
    this.dependencies = const [],
    this.dependents = const [],
  });
}

/// Parses workflow into a DAG and provides execution order
class DAGParser {
  /// Parse workflow nodes and edges into DAG
  static Map<int, DAGNode> parse(
    List<WorkflowNode> nodes,
    List<WorkflowEdge> edges,
  ) {
    final dagNodes = <int, DAGNode>{};

    // Initialize DAG nodes
    for (final node in nodes) {
      dagNodes[node.id] = DAGNode(
        node: node,
        dependencies: [],
        dependents: [],
      );
    }

    // Build dependency graph
    for (final edge in edges) {
      final fromNode = dagNodes[edge.fromNodeId];
      final toNode = dagNodes[edge.toNodeId];

      if (fromNode == null || toNode == null) continue;

      // toNode depends on fromNode
      dagNodes[edge.toNodeId] = DAGNode(
        node: toNode.node,
        dependencies: [...toNode.dependencies, edge.fromNodeId],
        dependents: toNode.dependents,
      );

      // fromNode has toNode as dependent
      dagNodes[edge.fromNodeId] = DAGNode(
        node: fromNode.node,
        dependencies: fromNode.dependencies,
        dependents: [...fromNode.dependents, edge.toNodeId],
      );
    }

    return dagNodes;
  }

  /// Get topological sort for execution order
  static List<int> getExecutionOrder(Map<int, DAGNode> dag) {
    final order = <int>[];
    final visited = <int>{};
    final temp = <int>{};

    void visit(int nodeId) {
      if (temp.contains(nodeId)) {
        throw Exception('Cycle detected in workflow');
      }
      if (visited.contains(nodeId)) return;

      temp.add(nodeId);

      final node = dag[nodeId];
      if (node != null) {
        for (final depId in node.dependencies) {
          visit(depId);
        }
      }

      temp.remove(nodeId);
      visited.add(nodeId);
      order.add(nodeId);
    }

    for (final nodeId in dag.keys) {
      if (!visited.contains(nodeId)) {
        visit(nodeId);
      }
    }

    return order;
  }

  /// Get nodes that can be executed in parallel at each level
  static List<List<int>> getParallelLevels(Map<int, DAGNode> dag) {
    final levels = <List<int>>[];
    final processed = <int>{};

    while (processed.length < dag.length) {
      final currentLevel = <int>[];

      for (final entry in dag.entries) {
        if (processed.contains(entry.key)) continue;

        // Check if all dependencies are processed
        final allDepsProcessed = entry.value.dependencies.every(
          (depId) => processed.contains(depId),
        );

        if (allDepsProcessed) {
          currentLevel.add(entry.key);
        }
      }

      if (currentLevel.isEmpty) {
        throw Exception('Cycle detected or orphaned nodes');
      }

      levels.add(currentLevel);
      processed.addAll(currentLevel);
    }

    return levels;
  }

  /// Detect cycles in the DAG
  static bool hasCycle(Map<int, DAGNode> dag) {
    try {
      getExecutionOrder(dag);
      return false;
    } catch (e) {
      return true;
    }
  }
}
