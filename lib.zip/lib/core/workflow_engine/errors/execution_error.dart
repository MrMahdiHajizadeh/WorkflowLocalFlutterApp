/// Base exception for execution errors
class ExecutionError implements Exception {
  final String message;
  final int? nodeId;
  final Object? originalError;

  ExecutionError(this.message, {this.nodeId, this.originalError});

  @override
  String toString() {
    if (nodeId != null) {
      return 'ExecutionError in node $nodeId: $message';
    }
    return 'ExecutionError: $message';
  }
}
