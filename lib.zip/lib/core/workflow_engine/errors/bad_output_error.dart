/// Base exception for bad output errors
class BadOutputError implements Exception {
  final String message;
  final String? expectedFormat;
  final String? actualFormat;

  BadOutputError(this.message, {this.expectedFormat, this.actualFormat});

  @override
  String toString() {
    if (expectedFormat != null && actualFormat != null) {
      return 'BadOutputError: $message (Expected: $expectedFormat, Got: $actualFormat)';
    }
    return 'BadOutputError: $message';
  }
}
