/// Base exception for network errors
class NetworkError implements Exception {
  final String message;
  final int? statusCode;
  final String? url;

  NetworkError(this.message, {this.statusCode, this.url});

  @override
  String toString() {
    if (statusCode != null && url != null) {
      return 'NetworkError [$statusCode] at $url: $message';
    }
    return 'NetworkError: $message';
  }
}
