/// Base exception for validation errors
class ValidationError implements Exception {
  final String message;
  final String? field;

  ValidationError(this.message, {this.field});

  @override
  String toString() {
    if (field != null) {
      return 'ValidationError in $field: $message';
    }
    return 'ValidationError: $message';
  }
}
