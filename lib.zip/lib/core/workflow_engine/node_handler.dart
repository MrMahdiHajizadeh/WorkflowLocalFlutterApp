/// Base class for all node execution handlers
abstract class NodeHandler {
  /// Execute the node with given input, config, and runtime memory
  Future<NodeOutput> execute({
    required Map<String, dynamic> input,
    required Map<String, dynamic> config,
    required WorkflowRuntimeMemory memory,
  });

  /// Validate node configuration
  bool validate(Map<String, dynamic> config) => true;
}

/// Output from a node execution
class NodeOutput {
  final Map<String, dynamic> data;
  final String? error;
  final bool success;

  NodeOutput.success(this.data)
      : error = null,
        success = true;

  NodeOutput.failure(String errorMessage)
      : data = {},
        error = errorMessage,
        success = false;
}

/// Runtime memory for workflow execution
class WorkflowRuntimeMemory {
  final Map<int, NodeOutput> nodeResults = {};
  final Map<String, dynamic> variables = {};

  void setNodeResult(int nodeId, NodeOutput output) {
    nodeResults[nodeId] = output;
  }

  NodeOutput? getNodeResult(int nodeId) {
    return nodeResults[nodeId];
  }

  void setVariable(String key, dynamic value) {
    variables[key] = value;
  }

  dynamic getVariable(String key) {
    return variables[key];
  }

  Map<String, dynamic> toJson() => {
        'nodeResults': nodeResults.map((k, v) => MapEntry(k.toString(), v.data)),
        'variables': variables,
      };
}
