import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as encrypt;

/// Service for AES-256 encryption and decryption
class EncryptionService {
  static final EncryptionService _instance = EncryptionService._internal();
  factory EncryptionService() => _instance;
  EncryptionService._internal();

  late encrypt.Key _key;
  late encrypt.IV _iv;
  late encrypt.Encrypter _encrypter;

  /// Initialize encryption with a device-specific key
  /// In production, derive this from device ID + secure random
  void initialize(String deviceId) {
    // Generate key from device ID (in production, use more secure key derivation)
    final keyBytes = sha256.convert(utf8.encode(deviceId + 'ai_flow_secret_salt')).bytes;
    _key = encrypt.Key(Uint8List.fromList(keyBytes));

    // Generate IV (initialization vector)
    final ivBytes = sha256.convert(utf8.encode('ai_flow_iv_salt' + deviceId)).bytes.sublist(0, 16);
    _iv = encrypt.IV(Uint8List.fromList(ivBytes));

    _encrypter = encrypt.Encrypter(encrypt.AES(_key, mode: encrypt.AESMode.cbc));
  }

  /// Encrypt plain text using AES-256
  String encryptText(String plainText) {
    try {
      final encrypted = _encrypter.encrypt(plainText, iv: _iv);
      return encrypted.base64;
    } catch (e) {
      throw Exception('Encryption failed: $e');
    }
  }

  /// Decrypt cipher text using AES-256
  String decryptText(String cipherText) {
    try {
      final encrypted = encrypt.Encrypted.fromBase64(cipherText);
      return _encrypter.decrypt(encrypted, iv: _iv);
    } catch (e) {
      throw Exception('Decryption failed: $e');
    }
  }

  /// Generate hash for cache key
  String generateHash(String input) {
    return sha256.convert(utf8.encode(input)).toString();
  }
}
