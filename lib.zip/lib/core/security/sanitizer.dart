/// Sanitizer for removing sensitive data from logs and errors
class Sanitizer {
  static final Sanitizer _instance = Sanitizer._internal();
  factory Sanitizer() => _instance;
  Sanitizer._internal();

  final List<String> _sensitivePatterns = [
    r'api[_-]?key',
    r'token',
    r'password',
    r'secret',
    r'authorization',
    r'bearer',
  ];

  /// Sanitize a string by removing sensitive information
  String sanitize(String input) {
    String sanitized = input;

    // Replace API keys and tokens
    final regexes = _sensitivePatterns.map(
      (pattern) => RegExp(
        '$pattern\\s*[:=]\\s*["\']?([^"\'\\s,}]+)',
        caseSensitive: false,
      ),
    );

    for (final regex in regexes) {
      sanitized = sanitized.replaceAllMapped(regex, (match) {
        return '${match.group(0)?.split(RegExp(r'[:=]')).first}=***REDACTED***';
      });
    }

    return sanitized;
  }

  /// Sanitize a map by removing sensitive keys
  Map<String, dynamic> sanitizeMap(Map<String, dynamic> data) {
    final sanitized = <String, dynamic>{};

    for (final entry in data.entries) {
      final key = entry.key.toLowerCase();
      final isSensitive = _sensitivePatterns.any(
        (pattern) => RegExp(pattern, caseSensitive: false).hasMatch(key),
      );

      if (isSensitive) {
        sanitized[entry.key] = '***REDACTED***';
      } else if (entry.value is Map) {
        sanitized[entry.key] = sanitizeMap(entry.value as Map<String, dynamic>);
      } else if (entry.value is List) {
        sanitized[entry.key] = _sanitizeList(entry.value as List);
      } else {
        sanitized[entry.key] = entry.value;
      }
    }

    return sanitized;
  }

  List<dynamic> _sanitizeList(List<dynamic> list) {
    return list.map((item) {
      if (item is Map) {
        return sanitizeMap(item as Map<String, dynamic>);
      } else if (item is List) {
        return _sanitizeList(item);
      }
      return item;
    }).toList();
  }

  /// Sanitize error message
  String sanitizeError(Object error) {
    return sanitize(error.toString());
  }
}
