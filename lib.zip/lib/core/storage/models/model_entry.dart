import 'package:isar/isar.dart';

part 'model_entry.g.dart';

/// Represents an AI model configuration
@collection
class ModelEntry {
  Id id = Isar.autoIncrement;

  @Index()
  late String name;

  late String provider; // "openai" | "groq" | "stability" | "replicate" | "custom"

  late String modelType; // "llm" | "image" | "audio" | "embedding"

  late String baseUrl;

  /// Encrypted API key
  late String apiKeyEncrypted;

  /// Default parameters for this model (e.g., temperature, max_tokens)
  late String defaultParamsJson; // Store as JSON string

  late DateTime createdAt;

  ModelEntry();

  ModelEntry.create({
    required this.name,
    required this.provider,
    required this.modelType,
    required this.baseUrl,
    required this.apiKeyEncrypted,
    required this.defaultParamsJson,
  }) : createdAt = DateTime.now();
}
