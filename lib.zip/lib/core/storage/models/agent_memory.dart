import 'package:isar/isar.dart';

part 'agent_memory.g.dart';

/// Represents agent memory for chat context
@collection
class AgentMemory {
  Id id = Isar.autoIncrement;

  late String text;

  /// Embedding vector for semantic search (stored as List<double>)
  List<double>? embedding;

  @Index()
  late String tag; // "conversation" | "workflow" | "knowledge"

  late DateTime createdAt;

  AgentMemory();

  AgentMemory.create({
    required this.text,
    this.embedding,
    required this.tag,
  }) : createdAt = DateTime.now();
}
