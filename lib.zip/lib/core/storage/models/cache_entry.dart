import 'package:isar/isar.dart';

part 'cache_entry.g.dart';

/// Represents a cached API response
@collection
class CacheEntry {
  Id id = Isar.autoIncrement;

  @Index(unique: true)
  late String hash;

  /// Cached output data as JSON string
  late String outputJson;

  late DateTime createdAt;

  late DateTime expiry;

  CacheEntry();

  CacheEntry.create({
    required this.hash,
    required this.outputJson,
    required Duration ttl,
  })  : createdAt = DateTime.now(),
        expiry = DateTime.now().add(ttl);

  bool get isExpired => DateTime.now().isAfter(expiry);
}
