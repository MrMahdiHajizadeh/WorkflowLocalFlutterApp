import 'package:isar/isar.dart';

part 'workflow_node.g.dart';

/// Represents a node in a workflow
@collection
class WorkflowNode {
  Id id = Isar.autoIncrement;

  @Index()
  late int workflowId;

  late String type; // "llm" | "image" | "logic" | "http" | etc.

  late String name;

  late double positionX;

  late double positionY;

  /// Node configuration as JSON string
  late String configJson;

  WorkflowNode();

  WorkflowNode.create({
    required this.workflowId,
    required this.type,
    required this.name,
    required this.positionX,
    required this.positionY,
    required this.configJson,
  });
}
