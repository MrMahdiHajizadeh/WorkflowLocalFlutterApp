import 'dart:convert';
import 'package:isar/isar.dart';

part 'workflow.g.dart';

/// Represents a workflow definition
@collection
class Workflow {
  Id id = Isar.autoIncrement;

  @Index()
  late String name;

  late String description;

  late DateTime createdAt;

  late DateTime updatedAt;

  /// Execution order as JSON array of node IDs (e.g., [1, 2, 3])
  /// Stored as JSON string: "[1,2,3]"
  String? executionOrderJson;

  Workflow();

  Workflow.create({
    required this.name,
    required this.description,
    this.executionOrderJson,
  })  : createdAt = DateTime.now(),
        updatedAt = DateTime.now();

  void touch() {
    updatedAt = DateTime.now();
  }

  /// Get execution order as list of node IDs
  List<int> getExecutionOrder() {
    if (executionOrderJson == null || executionOrderJson!.isEmpty) {
      return [];
    }
    try {
      final List<dynamic> order = const JsonDecoder().convert(executionOrderJson!);
      return order.map((e) => e as int).toList();
    } catch (e) {
      return [];
    }
  }

  /// Set execution order from list of node IDs
  void setExecutionOrder(List<int> order) {
    executionOrderJson = const JsonEncoder().convert(order);
  }
}
