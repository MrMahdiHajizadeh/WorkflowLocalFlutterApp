// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'workflow_edge.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetWorkflowEdgeCollection on Isar {
  IsarCollection<WorkflowEdge> get workflowEdges => this.collection();
}

const WorkflowEdgeSchema = CollectionSchema(
  name: r'WorkflowEdge',
  id: -4622868265478458888,
  properties: {
    r'fromNodeId': PropertySchema(
      id: 0,
      name: r'fromNodeId',
      type: IsarType.long,
    ),
    r'fromPort': PropertySchema(
      id: 1,
      name: r'fromPort',
      type: IsarType.string,
    ),
    r'label': PropertySchema(
      id: 2,
      name: r'label',
      type: IsarType.string,
    ),
    r'toNodeId': PropertySchema(
      id: 3,
      name: r'toNodeId',
      type: IsarType.long,
    ),
    r'toPort': PropertySchema(
      id: 4,
      name: r'toPort',
      type: IsarType.string,
    ),
    r'workflowId': PropertySchema(
      id: 5,
      name: r'workflowId',
      type: IsarType.long,
    )
  },
  estimateSize: _workflowEdgeEstimateSize,
  serialize: _workflowEdgeSerialize,
  deserialize: _workflowEdgeDeserialize,
  deserializeProp: _workflowEdgeDeserializeProp,
  idName: r'id',
  indexes: {
    r'workflowId': IndexSchema(
      id: 823524358593137506,
      name: r'workflowId',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'workflowId',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _workflowEdgeGetId,
  getLinks: _workflowEdgeGetLinks,
  attach: _workflowEdgeAttach,
  version: '3.1.0+1',
);

int _workflowEdgeEstimateSize(
  WorkflowEdge object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.fromPort;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.label;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  {
    final value = object.toPort;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  return bytesCount;
}

void _workflowEdgeSerialize(
  WorkflowEdge object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.fromNodeId);
  writer.writeString(offsets[1], object.fromPort);
  writer.writeString(offsets[2], object.label);
  writer.writeLong(offsets[3], object.toNodeId);
  writer.writeString(offsets[4], object.toPort);
  writer.writeLong(offsets[5], object.workflowId);
}

WorkflowEdge _workflowEdgeDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = WorkflowEdge();
  object.fromNodeId = reader.readLong(offsets[0]);
  object.fromPort = reader.readStringOrNull(offsets[1]);
  object.id = id;
  object.label = reader.readStringOrNull(offsets[2]);
  object.toNodeId = reader.readLong(offsets[3]);
  object.toPort = reader.readStringOrNull(offsets[4]);
  object.workflowId = reader.readLong(offsets[5]);
  return object;
}

P _workflowEdgeDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    case 1:
      return (reader.readStringOrNull(offset)) as P;
    case 2:
      return (reader.readStringOrNull(offset)) as P;
    case 3:
      return (reader.readLong(offset)) as P;
    case 4:
      return (reader.readStringOrNull(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _workflowEdgeGetId(WorkflowEdge object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _workflowEdgeGetLinks(WorkflowEdge object) {
  return [];
}

void _workflowEdgeAttach(
    IsarCollection<dynamic> col, Id id, WorkflowEdge object) {
  object.id = id;
}

extension WorkflowEdgeQueryWhereSort
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QWhere> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhere> anyWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'workflowId'),
      );
    });
  }
}

extension WorkflowEdgeQueryWhere
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QWhereClause> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> idGreaterThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> workflowIdEqualTo(
      int workflowId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'workflowId',
        value: [workflowId],
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause>
      workflowIdNotEqualTo(int workflowId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [],
              upper: [workflowId],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [workflowId],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [workflowId],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [],
              upper: [workflowId],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause>
      workflowIdGreaterThan(
    int workflowId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [workflowId],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause>
      workflowIdLessThan(
    int workflowId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [],
        upper: [workflowId],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterWhereClause> workflowIdBetween(
    int lowerWorkflowId,
    int upperWorkflowId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [lowerWorkflowId],
        includeLower: includeLower,
        upper: [upperWorkflowId],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension WorkflowEdgeQueryFilter
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QFilterCondition> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromNodeIdEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fromNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromNodeIdGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fromNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromNodeIdLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fromNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromNodeIdBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fromNodeId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'fromPort',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'fromPort',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'fromPort',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'fromPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'fromPort',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'fromPort',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      fromPortIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'fromPort',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'label',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'label',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'label',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'label',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> labelMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'label',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'label',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      labelIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'label',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toNodeIdEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'toNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toNodeIdGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'toNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toNodeIdLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'toNodeId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toNodeIdBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'toNodeId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'toPort',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'toPort',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> toPortEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> toPortBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'toPort',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'toPort',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition> toPortMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'toPort',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'toPort',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      toPortIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'toPort',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      workflowIdEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      workflowIdGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      workflowIdLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterFilterCondition>
      workflowIdBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'workflowId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension WorkflowEdgeQueryObject
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QFilterCondition> {}

extension WorkflowEdgeQueryLinks
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QFilterCondition> {}

extension WorkflowEdgeQuerySortBy
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QSortBy> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByFromNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromNodeId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy>
      sortByFromNodeIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromNodeId', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByFromPort() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromPort', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByFromPortDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromPort', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByLabel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByLabelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByToNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toNodeId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByToNodeIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toNodeId', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByToPort() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toPort', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByToPortDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toPort', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> sortByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy>
      sortByWorkflowIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.desc);
    });
  }
}

extension WorkflowEdgeQuerySortThenBy
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QSortThenBy> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByFromNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromNodeId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy>
      thenByFromNodeIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromNodeId', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByFromPort() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromPort', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByFromPortDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'fromPort', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByLabel() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByLabelDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'label', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByToNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toNodeId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByToNodeIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toNodeId', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByToPort() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toPort', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByToPortDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'toPort', Sort.desc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy> thenByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QAfterSortBy>
      thenByWorkflowIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.desc);
    });
  }
}

extension WorkflowEdgeQueryWhereDistinct
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> {
  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByFromNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fromNodeId');
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByFromPort(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'fromPort', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByLabel(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'label', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByToNodeId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'toNodeId');
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByToPort(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'toPort', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowEdge, WorkflowEdge, QDistinct> distinctByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'workflowId');
    });
  }
}

extension WorkflowEdgeQueryProperty
    on QueryBuilder<WorkflowEdge, WorkflowEdge, QQueryProperty> {
  QueryBuilder<WorkflowEdge, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<WorkflowEdge, int, QQueryOperations> fromNodeIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fromNodeId');
    });
  }

  QueryBuilder<WorkflowEdge, String?, QQueryOperations> fromPortProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'fromPort');
    });
  }

  QueryBuilder<WorkflowEdge, String?, QQueryOperations> labelProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'label');
    });
  }

  QueryBuilder<WorkflowEdge, int, QQueryOperations> toNodeIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'toNodeId');
    });
  }

  QueryBuilder<WorkflowEdge, String?, QQueryOperations> toPortProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'toPort');
    });
  }

  QueryBuilder<WorkflowEdge, int, QQueryOperations> workflowIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'workflowId');
    });
  }
}
