// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'workflow_node.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetWorkflowNodeCollection on Isar {
  IsarCollection<WorkflowNode> get workflowNodes => this.collection();
}

const WorkflowNodeSchema = CollectionSchema(
  name: r'WorkflowNode',
  id: -3310070952340240090,
  properties: {
    r'configJson': PropertySchema(
      id: 0,
      name: r'configJson',
      type: IsarType.string,
    ),
    r'name': PropertySchema(
      id: 1,
      name: r'name',
      type: IsarType.string,
    ),
    r'positionX': PropertySchema(
      id: 2,
      name: r'positionX',
      type: IsarType.double,
    ),
    r'positionY': PropertySchema(
      id: 3,
      name: r'positionY',
      type: IsarType.double,
    ),
    r'type': PropertySchema(
      id: 4,
      name: r'type',
      type: IsarType.string,
    ),
    r'workflowId': PropertySchema(
      id: 5,
      name: r'workflowId',
      type: IsarType.long,
    )
  },
  estimateSize: _workflowNodeEstimateSize,
  serialize: _workflowNodeSerialize,
  deserialize: _workflowNodeDeserialize,
  deserializeProp: _workflowNodeDeserializeProp,
  idName: r'id',
  indexes: {
    r'workflowId': IndexSchema(
      id: 823524358593137506,
      name: r'workflowId',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'workflowId',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _workflowNodeGetId,
  getLinks: _workflowNodeGetLinks,
  attach: _workflowNodeAttach,
  version: '3.1.0+1',
);

int _workflowNodeEstimateSize(
  WorkflowNode object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.configJson.length * 3;
  bytesCount += 3 + object.name.length * 3;
  bytesCount += 3 + object.type.length * 3;
  return bytesCount;
}

void _workflowNodeSerialize(
  WorkflowNode object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeString(offsets[0], object.configJson);
  writer.writeString(offsets[1], object.name);
  writer.writeDouble(offsets[2], object.positionX);
  writer.writeDouble(offsets[3], object.positionY);
  writer.writeString(offsets[4], object.type);
  writer.writeLong(offsets[5], object.workflowId);
}

WorkflowNode _workflowNodeDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = WorkflowNode();
  object.configJson = reader.readString(offsets[0]);
  object.id = id;
  object.name = reader.readString(offsets[1]);
  object.positionX = reader.readDouble(offsets[2]);
  object.positionY = reader.readDouble(offsets[3]);
  object.type = reader.readString(offsets[4]);
  object.workflowId = reader.readLong(offsets[5]);
  return object;
}

P _workflowNodeDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readString(offset)) as P;
    case 1:
      return (reader.readString(offset)) as P;
    case 2:
      return (reader.readDouble(offset)) as P;
    case 3:
      return (reader.readDouble(offset)) as P;
    case 4:
      return (reader.readString(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _workflowNodeGetId(WorkflowNode object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _workflowNodeGetLinks(WorkflowNode object) {
  return [];
}

void _workflowNodeAttach(
    IsarCollection<dynamic> col, Id id, WorkflowNode object) {
  object.id = id;
}

extension WorkflowNodeQueryWhereSort
    on QueryBuilder<WorkflowNode, WorkflowNode, QWhere> {
  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhere> anyWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'workflowId'),
      );
    });
  }
}

extension WorkflowNodeQueryWhere
    on QueryBuilder<WorkflowNode, WorkflowNode, QWhereClause> {
  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> idGreaterThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> workflowIdEqualTo(
      int workflowId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'workflowId',
        value: [workflowId],
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause>
      workflowIdNotEqualTo(int workflowId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [],
              upper: [workflowId],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [workflowId],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [workflowId],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'workflowId',
              lower: [],
              upper: [workflowId],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause>
      workflowIdGreaterThan(
    int workflowId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [workflowId],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause>
      workflowIdLessThan(
    int workflowId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [],
        upper: [workflowId],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterWhereClause> workflowIdBetween(
    int lowerWorkflowId,
    int upperWorkflowId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'workflowId',
        lower: [lowerWorkflowId],
        includeLower: includeLower,
        upper: [upperWorkflowId],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension WorkflowNodeQueryFilter
    on QueryBuilder<WorkflowNode, WorkflowNode, QFilterCondition> {
  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'configJson',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'configJson',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'configJson',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'configJson',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      configJsonIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'configJson',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      nameGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'name',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      nameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'name',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> nameMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'name',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      nameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'name',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      nameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'name',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionXEqualTo(
    double value, {
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'positionX',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionXGreaterThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'positionX',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionXLessThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'positionX',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionXBetween(
    double lower,
    double upper, {
    bool includeLower = true,
    bool includeUpper = true,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'positionX',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionYEqualTo(
    double value, {
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'positionY',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionYGreaterThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'positionY',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionYLessThan(
    double value, {
    bool include = false,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'positionY',
        value: value,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      positionYBetween(
    double lower,
    double upper, {
    bool includeLower = true,
    bool includeUpper = true,
    double epsilon = Query.epsilon,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'positionY',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        epsilon: epsilon,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      typeGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'type',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      typeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition> typeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'type',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      typeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      typeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'type',
        value: '',
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      workflowIdEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      workflowIdGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      workflowIdLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'workflowId',
        value: value,
      ));
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterFilterCondition>
      workflowIdBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'workflowId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension WorkflowNodeQueryObject
    on QueryBuilder<WorkflowNode, WorkflowNode, QFilterCondition> {}

extension WorkflowNodeQueryLinks
    on QueryBuilder<WorkflowNode, WorkflowNode, QFilterCondition> {}

extension WorkflowNodeQuerySortBy
    on QueryBuilder<WorkflowNode, WorkflowNode, QSortBy> {
  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByConfigJson() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'configJson', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy>
      sortByConfigJsonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'configJson', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByPositionX() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionX', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByPositionXDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionX', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByPositionY() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionY', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByPositionYDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionY', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> sortByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy>
      sortByWorkflowIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.desc);
    });
  }
}

extension WorkflowNodeQuerySortThenBy
    on QueryBuilder<WorkflowNode, WorkflowNode, QSortThenBy> {
  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByConfigJson() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'configJson', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy>
      thenByConfigJsonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'configJson', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'name', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByPositionX() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionX', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByPositionXDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionX', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByPositionY() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionY', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByPositionYDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'positionY', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy> thenByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.asc);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QAfterSortBy>
      thenByWorkflowIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'workflowId', Sort.desc);
    });
  }
}

extension WorkflowNodeQueryWhereDistinct
    on QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> {
  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByConfigJson(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'configJson', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByName(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'name', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByPositionX() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'positionX');
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByPositionY() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'positionY');
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'type', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<WorkflowNode, WorkflowNode, QDistinct> distinctByWorkflowId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'workflowId');
    });
  }
}

extension WorkflowNodeQueryProperty
    on QueryBuilder<WorkflowNode, WorkflowNode, QQueryProperty> {
  QueryBuilder<WorkflowNode, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<WorkflowNode, String, QQueryOperations> configJsonProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'configJson');
    });
  }

  QueryBuilder<WorkflowNode, String, QQueryOperations> nameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'name');
    });
  }

  QueryBuilder<WorkflowNode, double, QQueryOperations> positionXProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'positionX');
    });
  }

  QueryBuilder<WorkflowNode, double, QQueryOperations> positionYProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'positionY');
    });
  }

  QueryBuilder<WorkflowNode, String, QQueryOperations> typeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'type');
    });
  }

  QueryBuilder<WorkflowNode, int, QQueryOperations> workflowIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'workflowId');
    });
  }
}
