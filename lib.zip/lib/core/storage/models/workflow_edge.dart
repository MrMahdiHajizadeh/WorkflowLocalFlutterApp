import 'package:isar/isar.dart';

part 'workflow_edge.g.dart';

/// Represents a connection between two nodes
@collection
class WorkflowEdge {
  Id id = Isar.autoIncrement;

  @Index()
  late int workflowId;

  late int fromNodeId;

  late int toNodeId;

  String? label;
  
  String? fromPort; // Output port name from source node
  String? toPort;   // Input port name to target node

  WorkflowEdge();

  WorkflowEdge.create({
    required this.workflowId,
    required this.fromNodeId,
    required this.toNodeId,
    this.label,
    this.fromPort,
    this.toPort,
  });
}
