import 'package:isar/isar.dart';

part 'node_result.g.dart';

/// Represents the result of a node execution
@collection
class NodeResult {
  Id id = Isar.autoIncrement;

  @Index()
  late int runId;

  late int nodeId;

  /// Output data as JSON string
  late String outputJson;

  String? error;

  late int durationMs;

  late DateTime createdAt;

  NodeResult();

  NodeResult.create({
    required this.runId,
    required this.nodeId,
    required this.outputJson,
    this.error,
    required this.durationMs,
  }) : createdAt = DateTime.now();
}
