import 'package:isar/isar.dart';

part 'workflow_run.g.dart';

/// Represents a workflow execution
@collection
class WorkflowRun {
  Id id = Isar.autoIncrement;

  @Index()
  late int workflowId;

  late DateTime startTime;

  DateTime? endTime;

  late String status; // "running" | "success" | "error" | "cancelled"

  String? errorMessage;

  WorkflowRun();

  WorkflowRun.create({
    required this.workflowId,
  })  : startTime = DateTime.now(),
        status = 'running';

  void complete() {
    status = 'success';
    endTime = DateTime.now();
  }

  void fail(String error) {
    status = 'error';
    errorMessage = error;
    endTime = DateTime.now();
  }

  void cancel() {
    status = 'cancelled';
    endTime = DateTime.now();
  }

  int get durationMs {
    if (endTime == null) return 0;
    return endTime!.difference(startTime).inMilliseconds;
  }
}
