import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'models/model_entry.dart';
import 'models/workflow.dart';
import 'models/workflow_node.dart';
import 'models/workflow_edge.dart';
import 'models/workflow_run.dart';
import 'models/node_result.dart';
import 'models/cache_entry.dart';
import 'models/agent_memory.dart';
import 'models/file_entry.dart';

/// Service for managing Isar database operations (Desktop/Mobile only)
class IsarService {
  static final IsarService _instance = IsarService._internal();
  factory IsarService() => _instance;
  IsarService._internal();

  Isar? _isar;

  /// Initialize the Isar database
  Future<void> initialize() async {
    if (_isar != null) return;

    final dir = await getApplicationDocumentsDirectory();

    _isar = await Isar.open(
      [
        ModelEntrySchema,
        WorkflowSchema,
        WorkflowNodeSchema,
        WorkflowEdgeSchema,
        WorkflowRunSchema,
        NodeResultSchema,
        CacheEntrySchema,
        AgentMemorySchema,
        FileEntrySchema,
      ],
      directory: dir.path,
      name: 'ai_flow_architect_db',
    );
  }

  Isar get db {
    if (_isar == null) {
      throw Exception('IsarService not initialized. Call initialize() first.');
    }
    return _isar!;
  }

  /// Close the database
  Future<void> close() async {
    await _isar?.close();
    _isar = null;
  }

  // CRUD Operations for ModelEntry
  Future<int> createModel(ModelEntry model) async {
    return await db.writeTxn(() async {
      return await db.modelEntrys.put(model);
    });
  }

  Future<ModelEntry?> getModel(int id) async {
    return await db.modelEntrys.get(id);
  }

  Future<List<ModelEntry>> getAllModels() async {
    return await db.modelEntrys.where().findAll();
  }

  Future<List<ModelEntry>> getModelsByType(String type) async {
    return await db.modelEntrys.filter().modelTypeEqualTo(type).findAll();
  }

  Future<void> deleteModel(int id) async {
    await db.writeTxn(() async {
      await db.modelEntrys.delete(id);
    });
  }

  // CRUD Operations for Workflow
  Future<int> createWorkflow(Workflow workflow) async {
    return await db.writeTxn(() async {
      return await db.workflows.put(workflow);
    });
  }

  Future<Workflow?> getWorkflow(int id) async {
    return await db.workflows.get(id);
  }

  Future<List<Workflow>> getAllWorkflows() async {
    return await db.workflows.where().sortByUpdatedAtDesc().findAll();
  }

  Future<void> updateWorkflow(Workflow workflow) async {
    await db.writeTxn(() async {
      await db.workflows.put(workflow);
    });
  }

  Future<void> deleteWorkflow(int id) async {
    await db.writeTxn(() async {
      // Delete associated nodes and edges
      await db.workflowNodes.filter().workflowIdEqualTo(id).deleteAll();
      await db.workflowEdges.filter().workflowIdEqualTo(id).deleteAll();
      await db.workflows.delete(id);
    });
  }

  // CRUD Operations for WorkflowNode
  Future<int> createNode(WorkflowNode node) async {
    return await db.writeTxn(() async {
      return await db.workflowNodes.put(node);
    });
  }

  Future<List<WorkflowNode>> getNodesByWorkflow(int workflowId) async {
    return await db.workflowNodes.filter().workflowIdEqualTo(workflowId).findAll();
  }

  Future<void> deleteNode(int id) async {
    await db.writeTxn(() async {
      // Delete associated edges
      await db.workflowEdges.filter().fromNodeIdEqualTo(id).deleteAll();
      await db.workflowEdges.filter().toNodeIdEqualTo(id).deleteAll();
      await db.workflowNodes.delete(id);
    });
  }

  // CRUD Operations for WorkflowEdge
  Future<int> createEdge(WorkflowEdge edge) async {
    return await db.writeTxn(() async {
      return await db.workflowEdges.put(edge);
    });
  }

  Future<List<WorkflowEdge>> getEdgesByWorkflow(int workflowId) async {
    return await db.workflowEdges.filter().workflowIdEqualTo(workflowId).findAll();
  }

  Future<void> deleteEdge(int id) async {
    await db.writeTxn(() async {
      await db.workflowEdges.delete(id);
    });
  }

  Future<void> deleteNodesByWorkflow(int workflowId) async {
    await db.writeTxn(() async {
      await db.workflowNodes.filter().workflowIdEqualTo(workflowId).deleteAll();
    });
  }

  Future<void> deleteEdgesByWorkflow(int workflowId) async {
    await db.writeTxn(() async {
      await db.workflowEdges.filter().workflowIdEqualTo(workflowId).deleteAll();
    });
  }

  // CRUD Operations for WorkflowRun
  Future<int> createRun(WorkflowRun run) async {
    return await db.writeTxn(() async {
      return await db.workflowRuns.put(run);
    });
  }

  Future<WorkflowRun?> getRun(int id) async {
    return await db.workflowRuns.get(id);
  }

  Future<List<WorkflowRun>> getRunsByWorkflow(int workflowId) async {
    return await db.workflowRuns
        .filter()
        .workflowIdEqualTo(workflowId)
        .sortByStartTimeDesc()
        .findAll();
  }

  Future<void> updateRun(WorkflowRun run) async {
    await db.writeTxn(() async {
      await db.workflowRuns.put(run);
    });
  }

  // CRUD Operations for NodeResult
  Future<int> createNodeResult(NodeResult result) async {
    return await db.writeTxn(() async {
      return await db.nodeResults.put(result);
    });
  }

  Future<List<NodeResult>> getResultsByRun(int runId) async {
    return await db.nodeResults.filter().runIdEqualTo(runId).findAll();
  }

  // CRUD Operations for CacheEntry
  Future<int> createCacheEntry(CacheEntry entry) async {
    return await db.writeTxn(() async {
      return await db.cacheEntrys.put(entry);
    });
  }

  Future<CacheEntry?> getCacheByHash(String hash) async {
    return await db.cacheEntrys.filter().hashEqualTo(hash).findFirst();
  }

  Future<void> cleanExpiredCache() async {
    final now = DateTime.now();
    await db.writeTxn(() async {
      final expired = await db.cacheEntrys.filter().expiryLessThan(now).findAll();
      for (final entry in expired) {
        await db.cacheEntrys.delete(entry.id);
      }
    });
  }

  // CRUD Operations for AgentMemory
  Future<int> createMemory(AgentMemory memory) async {
    return await db.writeTxn(() async {
      return await db.agentMemorys.put(memory);
    });
  }

  Future<List<AgentMemory>> getMemoriesByTag(String tag, {int limit = 100}) async {
    return await db.agentMemorys
        .filter()
        .tagEqualTo(tag)
        .sortByCreatedAtDesc()
        .limit(limit)
        .findAll();
  }

  Future<List<AgentMemory>> getAllMemoriesWithEmbeddings() async {
    return await db.agentMemorys
        .filter()
        .embeddingIsNotNull()
        .findAll();
  }

  // CRUD Operations for FileEntry
  Future<int> createFileEntry(FileEntry file) async {
    return await db.writeTxn(() async {
      return await db.fileEntrys.put(file);
    });
  }

  Future<List<FileEntry>> getFilesByRun(int runId) async {
    return await db.fileEntrys.filter().linkedRunIdEqualTo(runId).findAll();
  }
}

