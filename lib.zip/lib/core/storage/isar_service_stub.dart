// Stub implementation for web
import 'models/model_entry.dart';
import 'models/workflow.dart';
import 'models/workflow_node.dart';
import 'models/workflow_edge.dart';
import 'models/workflow_run.dart';
import 'models/node_result.dart';
import 'models/cache_entry.dart';
import 'models/agent_memory.dart';
import 'models/file_entry.dart';

/// Stub IsarService for web platform
/// Note: Isar is not supported on web due to 64-bit integer limitations
class IsarService {
  static final IsarService _instance = IsarService._internal();
  factory IsarService() => _instance;
  IsarService._internal();

  Future<void> initialize() async {
    // No-op on web
  }

  Never get db {
    throw UnsupportedError('Isar is not supported on web. Please use desktop or mobile platforms.');
  }

  Future<void> close() async {
    // No-op on web
  }

  // All CRUD operations throw UnsupportedError on web
  Future<int> createModel(ModelEntry model) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<ModelEntry?> getModel(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<ModelEntry>> getAllModels() async {
    return [];
  }

  Future<List<ModelEntry>> getModelsByType(String type) async {
    return [];
  }

  Future<void> deleteModel(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<int> createWorkflow(Workflow workflow) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<Workflow?> getWorkflow(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<Workflow>> getAllWorkflows() async {
    return [];
  }

  Future<void> updateWorkflow(Workflow workflow) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<void> deleteWorkflow(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<int> createNode(WorkflowNode node) async {
    throw UnsupportedError('Isar is not supported on web.');
  }


  Future<List<WorkflowNode>> getNodesByWorkflow(int workflowId) async {
    return [];
  }

  Future<void> deleteNode(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<int> createEdge(WorkflowEdge edge) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<WorkflowEdge>> getEdgesByWorkflow(int workflowId) async {
    return [];
  }

  Future<void> deleteEdge(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<void> deleteNodesByWorkflow(int workflowId) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<void> deleteEdgesByWorkflow(int workflowId) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<int> createRun(WorkflowRun run) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<WorkflowRun?> getRun(int id) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<WorkflowRun>> getRunsByWorkflow(int workflowId) async {
    return [];
  }

  Future<void> updateRun(WorkflowRun run) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<int> createNodeResult(NodeResult result) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<NodeResult>> getResultsByRun(int runId) async {
    return [];
  }

  Future<int> createCacheEntry(CacheEntry entry) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<CacheEntry?> getCacheByHash(String hash) async {
    return null;
  }

  Future<void> cleanExpiredCache() async {
    // No-op on web
  }

  Future<int> createMemory(AgentMemory memory) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<AgentMemory>> getMemoriesByTag(String tag, {int limit = 100}) async {
    return [];
  }

  Future<List<AgentMemory>> getAllMemoriesWithEmbeddings() async {
    return [];
  }

  Future<int> createFileEntry(FileEntry file) async {
    throw UnsupportedError('Isar is not supported on web.');
  }

  Future<List<FileEntry>> getFilesByRun(int runId) async {
    return [];
  }
}

