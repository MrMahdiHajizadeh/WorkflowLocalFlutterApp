// Conditional import: use stub on web, implementation on desktop/mobile
export 'isar_service_stub.dart' if (dart.library.io) 'isar_service_impl.dart';
