import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// File manager for handling generated files
class FileManager {
  /// Get app documents directory
  static Future<Directory> getAppDirectory() async {
    return await getApplicationDocumentsDirectory();
  }

  /// Get cache directory
  static Future<Directory> getCacheDirectory() async {
    return await getTemporaryDirectory();
  }

  /// Save file to app directory
  static Future<File> saveFile({
    required String filename,
    required List<int> bytes,
    String? subdirectory,
  }) async {
    final appDir = await getAppDirectory();
    final dirPath = subdirectory != null ? '${appDir.path}/$subdirectory' : appDir.path;

    final dir = Directory(dirPath);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }

    final file = File('$dirPath/$filename');
    return await file.writeAsBytes(bytes);
  }

  /// Read file from app directory
  static Future<List<int>?> readFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        return await file.readAsBytes();
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Delete file
  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  /// Get file size in bytes
  static Future<int?> getFileSize(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        return await file.length();
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Clean up old cache files
  static Future<void> cleanCache({Duration maxAge = const Duration(days: 7)}) async {
    final cacheDir = await getCacheDirectory();
    final now = DateTime.now();

    await for (final entity in cacheDir.list()) {
      if (entity is File) {
        final stat = await entity.stat();
        final age = now.difference(stat.modified);

        if (age > maxAge) {
          await entity.delete();
        }
      }
    }
  }
}
