/// Logger utility for structured logging
class Logger {
  static const bool _enableDebugLogs = true;

  /// Log debug message
  static void debug(String message, [String? tag]) {
    if (_enableDebugLogs) {
      final timestamp = DateTime.now().toIso8601String();
      final tagStr = tag != null ? '[$tag]' : '';
      print('DEBUG $timestamp $tagStr: $message');
    }
  }

  /// Log info message
  static void info(String message, [String? tag]) {
    final timestamp = DateTime.now().toIso8601String();
    final tagStr = tag != null ? '[$tag]' : '';
    print('INFO  $timestamp $tagStr: $message');
  }

  /// Log warning message
  static void warning(String message, [String? tag]) {
    final timestamp = DateTime.now().toIso8601String();
    final tagStr = tag != null ? '[$tag]' : '';
    print('WARN  $timestamp $tagStr: $message');
  }

  /// Log error message
  static void error(String message, [Object? error, StackTrace? stackTrace, String? tag]) {
    final timestamp = DateTime.now().toIso8601String();
    final tagStr = tag != null ? '[$tag]' : '';
    print('ERROR $timestamp $tagStr: $message');
    if (error != null) {
      print('  Error: $error');
    }
    if (stackTrace != null) {
      print('  StackTrace: $stackTrace');
    }
  }

  /// Log API call
  static void api(String method, String url, {int? statusCode, String? tag}) {
    final timestamp = DateTime.now().toIso8601String();
    final tagStr = tag != null ? '[$tag]' : '';
    final statusStr = statusCode != null ? ' [$statusCode]' : '';
    print('API   $timestamp $tagStr: $method $url$statusStr');
  }
}
