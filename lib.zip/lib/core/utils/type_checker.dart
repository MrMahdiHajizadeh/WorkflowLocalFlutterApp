/// Runtime type checker for dynamic data validation
class TypeChecker {
  /// Check if value is of expected type
  static bool isType<T>(dynamic value) {
    return value is T;
  }

  /// Check if value is a valid number
  static bool isNumber(dynamic value) {
    return value is num;
  }

  /// Check if value is a valid string
  static bool isString(dynamic value) {
    return value is String;
  }

  /// Check if value is a valid boolean
  static bool isBool(dynamic value) {
    return value is bool;
  }

  /// Check if value is a valid list
  static bool isList(dynamic value) {
    return value is List;
  }

  /// Check if value is a valid map
  static bool isMap(dynamic value) {
    return value is Map;
  }

  /// Try to cast value to type, return null if fails
  static T? tryCast<T>(dynamic value) {
    try {
      return value as T;
    } catch (e) {
      return null;
    }
  }

  /// Convert dynamic value to string safely
  static String toSafeString(dynamic value) {
    if (value == null) return '';
    return value.toString();
  }

  /// Convert dynamic value to int safely
  static int? toInt(dynamic value) {
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  /// Convert dynamic value to double safely
  static double? toDouble(dynamic value) {
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  /// Convert dynamic value to bool safely
  static bool? toBool(dynamic value) {
    if (value is bool) return value;
    if (value is String) {
      final lower = value.toLowerCase();
      if (lower == 'true' || lower == '1') return true;
      if (lower == 'false' || lower == '0') return false;
    }
    if (value is int) {
      return value != 0;
    }
    return null;
  }
}

