import 'dart:convert';

/// Validation utilities
class Validators {
  /// Validate URL format
  static bool isValidUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.scheme.isNotEmpty && uri.host.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  /// Validate email format
  static bool isValidEmail(String email) {
    final regex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return regex.hasMatch(email);
  }

  /// Validate non-empty string
  static bool isNotEmpty(String? value) {
    return value != null && value.trim().isNotEmpty;
  }

  /// Validate API key format (basic check)
  static bool isValidApiKey(String key) {
    return key.length >= 20; // Most API keys are at least 20 characters
  }

  /// Validate JSON string
  static bool isValidJson(String jsonString) {
    try {
      // ignore: unused_local_variable
      final decoded = jsonDecode(jsonString);
      return true;
    } catch (e) {
      return false;
    }
  }
}
