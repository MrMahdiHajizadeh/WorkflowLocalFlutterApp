/// Throttler for rate limiting API calls
class Throttler {
  final Duration _minInterval;
  DateTime? _lastCallTime;

  Throttler({required Duration minInterval}) : _minInterval = minInterval;

  /// Check if enough time has passed since last call
  bool canCall() {
    if (_lastCallTime == null) {
      return true;
    }

    final now = DateTime.now();
    final elapsed = now.difference(_lastCallTime!);
    return elapsed >= _minInterval;
  }

  /// Wait until next call is allowed
  Future<void> waitIfNeeded() async {
    if (_lastCallTime == null) {
      _lastCallTime = DateTime.now();
      return;
    }

    final now = DateTime.now();
    final elapsed = now.difference(_lastCallTime!);

    if (elapsed < _minInterval) {
      final remaining = _minInterval - elapsed;
      await Future.delayed(remaining);
    }

    _lastCallTime = DateTime.now();
  }

  /// Reset throttler
  void reset() {
    _lastCallTime = null;
  }
}
