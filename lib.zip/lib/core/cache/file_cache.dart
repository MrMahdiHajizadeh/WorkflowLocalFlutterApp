import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../utils/logger.dart';

/// File-based cache for large binary data
class FileCache {
  static final FileCache _instance = FileCache._internal();
  factory FileCache() => _instance;
  FileCache._internal();

  late Directory _cacheDir;
  bool _initialized = false;

  /// Initialize cache directory
  Future<void> initialize() async {
    if (_initialized) return;

    final tempDir = await getTemporaryDirectory();
    _cacheDir = Directory('${tempDir.path}/ai_flow_cache');

    if (!await _cacheDir.exists()) {
      await _cacheDir.create(recursive: true);
    }

    _initialized = true;
  }

  /// Save file to cache
  Future<String?> put(String key, List<int> bytes) async {
    try {
      await initialize();

      final sanitizedKey = _sanitizeKey(key);
      final file = File('${_cacheDir.path}/$sanitizedKey');
      await file.writeAsBytes(bytes);

      Logger.debug('File cached: $sanitizedKey (${bytes.length} bytes)', 'FileCache');
      return file.path;
    } catch (e) {
      Logger.error('Failed to cache file', e, null, 'FileCache');
      return null;
    }
  }

  /// Get file from cache
  Future<List<int>?> get(String key) async {
    try {
      await initialize();

      final sanitizedKey = _sanitizeKey(key);
      final file = File('${_cacheDir.path}/$sanitizedKey');

      if (!await file.exists()) {
        return null;
      }

      return await file.readAsBytes();
    } catch (e) {
      Logger.error('Failed to read cached file', e, null, 'FileCache');
      return null;
    }
  }

  /// Remove file from cache
  Future<bool> remove(String key) async {
    try {
      await initialize();

      final sanitizedKey = _sanitizeKey(key);
      final file = File('${_cacheDir.path}/$sanitizedKey');

      if (await file.exists()) {
        await file.delete();
        Logger.debug('File removed from cache: $sanitizedKey', 'FileCache');
        return true;
      }

      return false;
    } catch (e) {
      Logger.error('Failed to remove cached file', e, null, 'FileCache');
      return false;
    }
  }

  /// Clear all cache
  Future<void> clear() async {
    try {
      await initialize();

      final files = await _cacheDir.list().toList();
      for (final file in files) {
        if (file is File) {
          await file.delete();
        }
      }

      Logger.info('File cache cleared', 'FileCache');
    } catch (e) {
      Logger.error('Failed to clear cache', e, null, 'FileCache');
    }
  }

  /// Clean old files (older than maxAge)
  Future<void> cleanOld({Duration maxAge = const Duration(days: 7)}) async {
    try {
      await initialize();

      final now = DateTime.now();
      final files = await _cacheDir.list().toList();

      for (final file in files) {
        if (file is File) {
          final stat = await file.stat();
          final age = now.difference(stat.modified);

          if (age > maxAge) {
            await file.delete();
            Logger.debug('Deleted old cached file: ${file.path}', 'FileCache');
          }
        }
      }
    } catch (e) {
      Logger.error('Failed to clean old cache', e, null, 'FileCache');
    }
  }

  /// Get cache directory size in bytes
  Future<int> getCacheSize() async {
    try {
      await initialize();

      var totalSize = 0;
      final files = await _cacheDir.list().toList();

      for (final file in files) {
        if (file is File) {
          final stat = await file.stat();
          totalSize += stat.size;
        }
      }

      return totalSize;
    } catch (e) {
      Logger.error('Failed to get cache size', e, null, 'FileCache');
      return 0;
    }
  }

  /// Sanitize key to valid filename
  String _sanitizeKey(String key) {
    return key.replaceAll(RegExp(r'[^a-zA-Z0-9_\-\.]'), '_');
  }
}
