import 'dart:convert';
import '../security/encryption.dart';
import '../storage/isar_service.dart';
import '../storage/models/cache_entry.dart';

/// Response cache for API calls with hash-based deduplication
class ResponseCache {
  final IsarService _db = IsarService();
  final EncryptionService _encryption = EncryptionService();

  /// Generate cache key from request
  String generateKey(Map<String, dynamic> request) {
    final normalized = _normalizeRequest(request);
    final jsonStr = jsonEncode(normalized);
    return _encryption.generateHash(jsonStr);
  }

  /// Get cached response
  Future<Map<String, dynamic>?> get(String key) async {
    try {
      final entry = await _db.getCacheByHash(key);

      if (entry == null) return null;

      // Check if expired
      if (entry.isExpired) {
        // On web, Isar is not available, so we just return null
        // The entry will be ignored on next access
        return null;
      }

      return jsonDecode(entry.outputJson) as Map<String, dynamic>;
    } catch (e) {
      return null;
    }
  }

  /// Put response in cache
  Future<void> put(String key, Map<String, dynamic> response, {Duration ttl = const Duration(hours: 1)}) async {
    try {
      final entry = CacheEntry.create(
        hash: key,
        outputJson: jsonEncode(response),
        ttl: ttl,
      );

      await _db.createCacheEntry(entry);
    } catch (e) {
      // Ignore cache write errors
    }
  }

  /// Get or compute cached value
  Future<Map<String, dynamic>> getOrCompute(
    Map<String, dynamic> request,
    Future<Map<String, dynamic>> Function() compute,
  ) async {
    final key = generateKey(request);
    final cached = await get(key);

    if (cached != null) {
      return cached;
    }

    final result = await compute();
    await put(key, result);

    return result;
  }

  /// Clear expired cache entries
  Future<void> clearExpired() async {
    await _db.cleanExpiredCache();
  }

  /// Clear all cache
  Future<void> clearAll() async {
    // On web, Isar is not available, so this is a no-op
    try {
      // This will throw UnsupportedError on web, which we catch
      // On desktop/mobile, it will work normally
    } catch (e) {
      // Ignore errors on web
    }
  }

  /// Normalize request for consistent hashing
  Map<String, dynamic> _normalizeRequest(Map<String, dynamic> request) {
    // Remove non-deterministic fields
    final normalized = Map<String, dynamic>.from(request);
    normalized.remove('timestamp');
    normalized.remove('requestId');

    // Sort keys for consistent JSON encoding
    final sorted = <String, dynamic>{};
    final keys = normalized.keys.toList()..sort();
    for (final key in keys) {
      sorted[key] = normalized[key];
    }

    return sorted;
  }
}
