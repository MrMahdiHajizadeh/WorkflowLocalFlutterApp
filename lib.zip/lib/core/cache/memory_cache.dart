import 'dart:collection';

/// In-memory LRU cache
class MemoryCache<K, V> {
  final int maxSize;
  final LinkedHashMap<K, _CacheEntry<V>> _cache = LinkedHashMap();

  MemoryCache({this.maxSize = 100});

  /// Get value from cache
  V? get(K key) {
    final entry = _cache.remove(key);
    if (entry == null) return null;

    // Check expiration
    if (entry.isExpired) {
      return null;
    }

    // Move to end (most recently used)
    _cache[key] = entry;
    return entry.value;
  }

  /// Put value in cache
  void put(K key, V value, {Duration? ttl}) {
    // Remove if exists
    _cache.remove(key);

    // Add new entry
    _cache[key] = _CacheEntry(
      value: value,
      expiry: ttl != null ? DateTime.now().add(ttl) : null,
    );

    // Evict oldest if over capacity
    if (_cache.length > maxSize) {
      _cache.remove(_cache.keys.first);
    }
  }

  /// Remove value from cache
  void remove(K key) {
    _cache.remove(key);
  }

  /// Clear all cache
  void clear() {
    _cache.clear();
  }

  /// Get cache size
  int get size => _cache.length;

  /// Check if key exists
  bool containsKey(K key) {
    return _cache.containsKey(key);
  }

  /// Clean expired entries
  void cleanExpired() {
    _cache.removeWhere((key, entry) => entry.isExpired);
  }
}

class _CacheEntry<V> {
  final V value;
  final DateTime? expiry;

  _CacheEntry({required this.value, this.expiry});

  bool get isExpired {
    if (expiry == null) return false;
    return DateTime.now().isAfter(expiry!);
  }
}
