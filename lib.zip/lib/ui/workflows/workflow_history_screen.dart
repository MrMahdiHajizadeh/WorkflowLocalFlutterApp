import 'package:flutter/material.dart';
import '../flowchart/flowchart_editor_v2.dart';
import '../../core/storage/isar_service.dart';
import '../../core/storage/models/workflow.dart';

/// Screen for viewing and managing workflow history
class WorkflowHistoryScreen extends StatefulWidget {
  const WorkflowHistoryScreen({super.key});

  @override
  State<WorkflowHistoryScreen> createState() => _WorkflowHistoryScreenState();
}

class _WorkflowHistoryScreenState extends State<WorkflowHistoryScreen> {
  final IsarService _db = IsarService();
  List<Workflow> _workflows = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadWorkflows();
  }

  Future<void> _loadWorkflows() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final workflows = await _db.getAllWorkflows();
      setState(() {
        _workflows = workflows;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading workflows: $e')),
        );
      }
    }
  }

  Future<void> _createNewWorkflow() async {
    // Show dialog to get workflow name
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create New Workflow'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Workflow Name *',
                border: OutlineInputBorder(),
                hintText: 'e.g., My AI Workflow',
              ),
              autofocus: true,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
                border: OutlineInputBorder(),
                hintText: 'Describe your workflow',
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.trim().isNotEmpty) {
                Navigator.pop(context, true);
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );

    if (result == true && nameController.text.trim().isNotEmpty) {
      try {
        // Create new workflow
        final workflow = Workflow.create(
          name: nameController.text.trim(),
          description: descriptionController.text.trim(),
        );
        final workflowId = await _db.createWorkflow(workflow);

        // Navigate to editor
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => FlowchartEditorScreenV2(
                workflowId: workflowId,
                workflowName: workflow.name,
              ),
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error creating workflow: $e')),
          );
        }
      }
    }
  }

  Future<void> _deleteWorkflow(Workflow workflow) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Workflow'),
        content: Text('Are you sure you want to delete "${workflow.name}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await _db.deleteWorkflow(workflow.id);
        _loadWorkflows();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Workflow deleted'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error deleting workflow: $e')),
          );
        }
      }
    }
  }

  Future<void> _renameWorkflow(Workflow workflow) async {
    final nameController = TextEditingController(text: workflow.name);
    final descriptionController = TextEditingController(text: workflow.description);

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename Workflow'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Workflow Name *',
                border: OutlineInputBorder(),
              ),
              autofocus: true,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.trim().isNotEmpty) {
                Navigator.pop(context, true);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result == true && nameController.text.trim().isNotEmpty) {
      try {
        workflow.name = nameController.text.trim();
        workflow.description = descriptionController.text.trim();
        workflow.touch();
        await _db.updateWorkflow(workflow);
        _loadWorkflows();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error renaming workflow: $e')),
          );
        }
      }
    }
  }

  void _openWorkflow(Workflow workflow) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FlowchartEditorScreenV2(
          workflowId: workflow.id,
          workflowName: workflow.name,
        ),
      ),
    ).then((_) {
      // Reload workflows when returning from editor
      _loadWorkflows();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workflow History'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadWorkflows,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _workflows.isEmpty
              ? _buildEmptyState()
              : _buildWorkflowList(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createNewWorkflow,
        icon: const Icon(Icons.add),
        label: const Text('New Workflow'),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.account_tree_outlined,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'No workflows yet',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Create your first workflow to get started',
            style: TextStyle(color: Colors.grey.shade500),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Create Workflow'),
            onPressed: _createNewWorkflow,
          ),
        ],
      ),
    );
  }

  Widget _buildWorkflowList() {
    return RefreshIndicator(
      onRefresh: _loadWorkflows,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _workflows.length,
        itemBuilder: (context, index) {
          final workflow = _workflows[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue.shade100,
                child: Icon(
                  Icons.account_tree,
                  color: Colors.blue.shade700,
                ),
              ),
              title: Text(
                workflow.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (workflow.description.isNotEmpty)
                    Text(
                      workflow.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  const SizedBox(height: 4),
                  Text(
                    'Updated: ${_formatDate(workflow.updatedAt)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
                     trailing: PopupMenuButton<String>(
                       onSelected: (value) {
                         switch (value) {
                           case 'open':
                             _openWorkflow(workflow);
                             break;
                           case 'rename':
                             _renameWorkflow(workflow);
                             break;
                           case 'delete':
                             _deleteWorkflow(workflow);
                             break;
                         }
                       },
                       itemBuilder: (context) => [
                         const PopupMenuItem(
                           value: 'open',
                           child: Row(
                             children: [
                               Icon(Icons.edit, size: 20),
                               SizedBox(width: 8),
                               Text('Open'),
                             ],
                           ),
                         ),
                         const PopupMenuItem(
                           value: 'rename',
                           child: Row(
                             children: [
                               Icon(Icons.drive_file_rename_outline, size: 20),
                               SizedBox(width: 8),
                               Text('Rename'),
                             ],
                           ),
                         ),
                         const PopupMenuDivider(),
                         const PopupMenuItem(
                           value: 'delete',
                           child: Row(
                             children: [
                               Icon(Icons.delete, size: 20, color: Colors.red),
                               SizedBox(width: 8),
                               Text('Delete', style: TextStyle(color: Colors.red)),
                             ],
                           ),
                         ),
                       ],
                     ),
              onTap: () => _openWorkflow(workflow),
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        if (difference.inMinutes == 0) {
          return 'Just now';
        }
        return '${difference.inMinutes} minutes ago';
      }
      return '${difference.inHours} hours ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}

