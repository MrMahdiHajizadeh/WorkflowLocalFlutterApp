import 'package:flutter/material.dart';
import 'dart:convert';
import '../../core/storage/isar_service.dart';
import '../../core/storage/models/model_entry.dart';
import '../../core/security/encryption.dart';

/// Screen for managing AI models configuration
class ModelsManagementScreen extends StatefulWidget {
  const ModelsManagementScreen({super.key});

  @override
  State<ModelsManagementScreen> createState() => _ModelsManagementScreenState();
}

class _ModelsManagementScreenState extends State<ModelsManagementScreen> {
  final IsarService _db = IsarService();
  List<ModelEntry> _models = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadModels();
    _initializeDefaultModels();
  }

  /// Initialize default models if they don't exist
  Future<void> _initializeDefaultModels() async {
    try {
      final existingModels = await _db.getAllModels();
      
      // Check if default models already exist
      final existingNames = existingModels.map((m) => m.name).toSet();
      final modelsToCreate = <ModelEntry>[];
      final encryption = EncryptionService();
      
      // Create default GPT models with MetisAI base URL
      // Note: name must be the actual API model name, not display name
      final defaultModels = [
        'gpt-4o-mini',
        'gpt-4',
        'gpt-3.5-turbo',
        'gpt-4-turbo',
      ];
      
      for (final modelName in defaultModels) {
        if (!existingNames.contains(modelName)) {
          // Create model with empty API key (user needs to add it)
          final emptyKey = encryption.encryptText(''); // Encrypt empty string as placeholder
          final model = ModelEntry.create(
            name: modelName, // Use API model name directly
            provider: 'custom',
            modelType: 'llm',
            baseUrl: 'https://api.metisai.ir/openai/v1',
            apiKeyEncrypted: emptyKey,
            defaultParamsJson: '{"temperature": 0.7, "max_tokens": 2000}',
          );
          modelsToCreate.add(model);
        }
      }
      
      // Create default models
      for (final model in modelsToCreate) {
        await _db.createModel(model);
      }
      
      // Reload models if any were created
      if (modelsToCreate.isNotEmpty && mounted) {
        _loadModels();
      }
    } catch (e) {
      // Silently fail - default models are optional
      debugPrint('Error initializing default models: $e');
    }
  }

  Future<void> _loadModels() async {
    setState(() => _isLoading = true);
    try {
      final models = await _db.getAllModels();
      setState(() {
        _models = models;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading models: $e')),
        );
      }
    }
  }

  Future<void> _deleteModel(ModelEntry model) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Model'),
        content: Text('Are you sure you want to delete "${model.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _db.deleteModel(model.id.toInt());
        _loadModels();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Model deleted successfully')),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error deleting model: $e')),
          );
        }
      }
    }
  }

  void _showAddEditModelDialog({ModelEntry? model}) {
    showDialog(
      context: context,
      builder: (context) => _ModelEditDialog(
        model: model,
        onSaved: () {
          _loadModels();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Models Management'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddEditModelDialog(),
            tooltip: 'Add New Model',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _models.isEmpty
              ? _buildEmptyState()
              : _buildModelsList(),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.api, size: 64, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          const Text(
            'No models configured',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Add your first AI model to get started',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add Model'),
            onPressed: () => _showAddEditModelDialog(),
          ),
        ],
      ),
    );
  }

  Widget _buildModelsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: _models.length,
      itemBuilder: (context, index) {
        final model = _models[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: _getModelTypeIcon(model.modelType),
            title: Text(
              model.name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text('Provider: ${model.provider}'),
                Text('Type: ${model.modelType}'),
                Text('Base URL: ${model.baseUrl}'),
              ],
            ),
            trailing: PopupMenuButton(
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(Icons.edit, size: 20),
                      SizedBox(width: 8),
                      Text('Edit'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, size: 20, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Delete', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ],
              onSelected: (value) {
                if (value == 'edit') {
                  _showAddEditModelDialog(model: model);
                } else if (value == 'delete') {
                  _deleteModel(model);
                }
              },
            ),
            isThreeLine: true,
          ),
        );
      },
    );
  }

  Widget _getModelTypeIcon(String type) {
    IconData icon;
    Color color;
    switch (type.toLowerCase()) {
      case 'llm':
        icon = Icons.chat_bubble_outline;
        color = Colors.blue;
        break;
      case 'image':
        icon = Icons.image;
        color = Colors.purple;
        break;
      case 'audio':
        icon = Icons.audiotrack;
        color = Colors.orange;
        break;
      case 'embedding':
        icon = Icons.layers;
        color = Colors.green;
        break;
      default:
        icon = Icons.api;
        color = Colors.grey;
    }
    return Icon(icon, color: color, size: 32);
  }
}

/// Dialog for adding/editing a model
class _ModelEditDialog extends StatefulWidget {
  final ModelEntry? model;
  final VoidCallback onSaved;

  const _ModelEditDialog({
    required this.model,
    required this.onSaved,
  });

  @override
  State<_ModelEditDialog> createState() => _ModelEditDialogState();
}

class _ModelEditDialogState extends State<_ModelEditDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _baseUrlController = TextEditingController();
  final _apiKeyController = TextEditingController();
  final _defaultParamsController = TextEditingController();

  String _selectedProvider = 'openai';
  String _selectedModelType = 'llm';
  final IsarService _db = IsarService();
  final EncryptionService _encryption = EncryptionService();
  bool _isSaving = false;

  final List<String> _providers = [
    'openai',
    'groq',
    'stability',
    'replicate',
    'custom',
  ];

  final List<String> _modelTypes = [
    'llm',
    'image',
    'audio',
    'embedding',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.model != null) {
      _nameController.text = widget.model!.name;
      _baseUrlController.text = widget.model!.baseUrl;
      _selectedProvider = widget.model!.provider;
      _selectedModelType = widget.model!.modelType;
      _defaultParamsController.text = widget.model!.defaultParamsJson;
      // Don't populate API key for security
    } else {
      // Set default base URLs based on provider
      _updateBaseUrlForProvider();
    }
  }

  void _updateBaseUrlForProvider() {
    switch (_selectedProvider) {
      case 'openai':
        _baseUrlController.text = 'https://api.openai.com/v1';
        break;
      case 'groq':
        _baseUrlController.text = 'https://api.groq.com/openai/v1';
        break;
      case 'stability':
        _baseUrlController.text = 'https://api.stability.ai/v1';
        break;
      case 'replicate':
        _baseUrlController.text = 'https://api.replicate.com/v1';
        break;
      case 'custom':
        _baseUrlController.text = 'https://api.metisai.ir/openai/v1';
        break;
      default:
        _baseUrlController.text = '';
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _baseUrlController.dispose();
    _apiKeyController.dispose();
    _defaultParamsController.dispose();
    super.dispose();
  }

  Future<void> _saveModel() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    try {
      final apiKey = _apiKeyController.text.trim();
      String encryptedApiKey;

      if (widget.model != null) {
        // Editing existing model
        if (apiKey.isEmpty) {
          // Keep existing encrypted key
          encryptedApiKey = widget.model!.apiKeyEncrypted;
        } else {
          // Encrypt new key
          encryptedApiKey = _encryption.encryptText(apiKey);
        }
      } else {
        // New model - API key is required
        if (apiKey.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('API Key is required')),
          );
          setState(() => _isSaving = false);
          return;
        }
        encryptedApiKey = _encryption.encryptText(apiKey);
      }

      final defaultParams = _defaultParamsController.text.trim();
      final defaultParamsJson = defaultParams.isEmpty
          ? '{}'
          : defaultParams;

      if (widget.model != null) {
        // Update existing model
        final updatedModel = ModelEntry()
          ..id = widget.model!.id
          ..name = _nameController.text.trim()
          ..provider = _selectedProvider
          ..modelType = _selectedModelType
          ..baseUrl = _baseUrlController.text.trim()
          ..apiKeyEncrypted = encryptedApiKey
          ..defaultParamsJson = defaultParamsJson
          ..createdAt = widget.model!.createdAt;
        await _db.createModel(updatedModel);
      } else {
        // Create new model
        final newModel = ModelEntry.create(
          name: _nameController.text.trim(),
          provider: _selectedProvider,
          modelType: _selectedModelType,
          baseUrl: _baseUrlController.text.trim(),
          apiKeyEncrypted: encryptedApiKey,
          defaultParamsJson: defaultParamsJson,
        );
        await _db.createModel(newModel);
      }

      if (mounted) {
        Navigator.pop(context);
        widget.onSaved();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.model != null
                  ? 'Model updated successfully'
                  : 'Model added successfully',
            ),
          ),
        );
      }
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving model: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        constraints: const BoxConstraints(maxWidth: 600),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.model != null
                            ? 'Edit Model'
                            : 'Add New Model',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Model Name (API Name) *',
                          hintText: 'e.g., gpt-4o-mini, gpt-4, claude-3-opus (use exact API model name)',
                          border: OutlineInputBorder(),
                          helperText: 'This is the exact model name used by the API',
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Model name is required';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedProvider,
                        decoration: const InputDecoration(
                          labelText: 'Provider *',
                          border: OutlineInputBorder(),
                        ),
                        items: _providers.map((provider) {
                          return DropdownMenuItem(
                            value: provider,
                            child: Text(provider.toUpperCase()),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedProvider = value!;
                            _updateBaseUrlForProvider();
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedModelType,
                        decoration: const InputDecoration(
                          labelText: 'Model Type *',
                          border: OutlineInputBorder(),
                        ),
                        items: _modelTypes.map((type) {
                          return DropdownMenuItem(
                            value: type,
                            child: Text(type.toUpperCase()),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedModelType = value!;
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _baseUrlController,
                        decoration: const InputDecoration(
                          labelText: 'Base URL *',
                          hintText: 'https://api.example.com/v1',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Base URL is required';
                          }
                          final uri = Uri.tryParse(value.trim());
                          if (uri == null || !uri.hasScheme) {
                            return 'Please enter a valid URL';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _apiKeyController,
                        decoration: InputDecoration(
                          labelText: widget.model != null
                              ? 'API Key (leave empty to keep existing)'
                              : 'API Key *',
                          hintText: 'Enter your API key',
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: const Icon(Icons.visibility),
                            onPressed: () {
                              // Toggle visibility
                            },
                          ),
                        ),
                        obscureText: true,
                        validator: widget.model == null
                            ? (value) {
                                if (value == null || value.trim().isEmpty) {
                                  return 'API Key is required';
                                }
                                return null;
                              }
                            : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _defaultParamsController,
                        decoration: const InputDecoration(
                          labelText: 'Default Parameters (JSON)',
                          hintText: '{"temperature": 0.7, "max_tokens": 1000}',
                          border: OutlineInputBorder(),
                          helperText: 'Optional: JSON format for default parameters',
                        ),
                        maxLines: 3,
                        validator: (value) {
                          if (value != null && value.trim().isNotEmpty) {
                            try {
                              jsonDecode(value);
                            } catch (e) {
                              return 'Invalid JSON format';
                            }
                          }
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: _isSaving
                          ? null
                          : () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: _isSaving ? null : _saveModel,
                      child: _isSaving
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Text(widget.model != null ? 'Update' : 'Save'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

