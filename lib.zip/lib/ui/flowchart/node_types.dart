import 'package:flutter/material.dart';

/// Available node types in the workflow editor
class NodeType {
  final String id;
  final String name;
  final String description;
  final String icon;
  final Color color;
  final List<String> inputPorts;
  final List<String> outputPorts;
  final String category;

  const NodeType({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.color,
    required this.inputPorts,
    required this.outputPorts,
    required this.category,
  });

  static const List<NodeType> allTypes = [
    // AI/LLM Nodes
    NodeType(
      id: 'llm',
      name: 'LLM',
      description: 'Large Language Model (GPT, Claude, etc.)',
      icon: 'smart_toy',
      color: Colors.purple,
      inputPorts: ['input'],
      outputPorts: ['output'],
      category: 'AI',
    ),
    NodeType(
      id: 'image_generation',
      name: 'Image Generation',
      description: 'Generate images (DALL-E, Stable Diffusion, etc.)',
      icon: 'image',
      color: Colors.pink,
      inputPorts: ['prompt'],
      outputPorts: ['image_url', 'image_data'],
      category: 'AI',
    ),
    NodeType(
      id: 'embedding',
      name: 'Embedding',
      description: 'Generate text embeddings',
      icon: 'layers',
      color: Colors.indigo,
      inputPorts: ['text'],
      outputPorts: ['embedding'],
      category: 'AI',
    ),
    
    // Logic Nodes
    NodeType(
      id: 'if',
      name: 'If Condition',
      description: 'Conditional logic',
      icon: 'call_split',
      color: Colors.orange,
      inputPorts: ['condition'],
      outputPorts: ['true', 'false'],
      category: 'Logic',
    ),
    NodeType(
      id: 'switch',
      name: 'Switch',
      description: 'Multi-branch conditional',
      icon: 'alt_route',
      color: Colors.deepOrange,
      inputPorts: ['value'],
      outputPorts: ['default', 'case1', 'case2'],
      category: 'Logic',
    ),
    NodeType(
      id: 'compare',
      name: 'Compare',
      description: 'Compare two values',
      icon: 'compare_arrows',
      color: Colors.amber,
      inputPorts: ['a', 'b'],
      outputPorts: ['result'],
      category: 'Logic',
    ),
    
    // Data Nodes
    NodeType(
      id: 'http',
      name: 'HTTP Request',
      description: 'Make HTTP requests',
      icon: 'http',
      color: Colors.blue,
      inputPorts: ['url', 'method', 'body'],
      outputPorts: ['response'],
      category: 'Data',
    ),
    NodeType(
      id: 'json_parse',
      name: 'Parse JSON',
      description: 'Parse JSON string',
      icon: 'code',
      color: Colors.teal,
      inputPorts: ['json_string'],
      outputPorts: ['parsed_data'],
      category: 'Data',
    ),
    NodeType(
      id: 'json_build',
      name: 'Build JSON',
      description: 'Build JSON from data',
      icon: 'data_object',
      color: Colors.cyan,
      inputPorts: ['data'],
      outputPorts: ['json_string'],
      category: 'Data',
    ),
    
    // Utility Nodes
    NodeType(
      id: 'variable',
      name: 'Set Variable',
      description: 'Set a variable',
      icon: 'label',
      color: Colors.green,
      inputPorts: ['value'],
      outputPorts: ['variable'],
      category: 'Utility',
    ),
    NodeType(
      id: 'delay',
      name: 'Delay',
      description: 'Wait for specified time',
      icon: 'schedule',
      color: Colors.grey,
      inputPorts: ['trigger'],
      outputPorts: ['output'],
      category: 'Utility',
    ),
    NodeType(
      id: 'merge',
      name: 'Merge',
      description: 'Merge multiple inputs',
      icon: 'merge_type',
      color: Colors.brown,
      inputPorts: ['input1', 'input2'],
      outputPorts: ['merged'],
      category: 'Utility',
    ),
    
    // I/O Nodes
    NodeType(
      id: 'user_input',
      name: 'User Input',
      description: 'Get input from user',
      icon: 'input',
      color: Colors.blueGrey,
      inputPorts: [],
      outputPorts: ['input'],
      category: 'I/O',
    ),
    NodeType(
      id: 'output',
      name: 'Output',
      description: 'Output result',
      icon: 'output',
      color: Colors.deepPurple,
      inputPorts: ['data', 'output'], // Accept both 'data' and 'output' ports
      outputPorts: [],
      category: 'I/O',
    ),
  ];

  static NodeType? getById(String id) {
    try {
      return allTypes.firstWhere((type) => type.id == id);
    } catch (e) {
      return null;
    }
  }

  static List<NodeType> getByCategory(String category) {
    return allTypes.where((type) => type.category == category).toList();
  }
}

