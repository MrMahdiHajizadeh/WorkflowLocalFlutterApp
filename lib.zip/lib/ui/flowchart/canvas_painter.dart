import 'package:flutter/material.dart';
import 'dart:ui' as ui;

/// Custom painter for flowchart canvas
class FlowchartCanvasPainter extends CustomPainter {
  final List<FlowchartNodeData> nodes;
  final List<FlowchartEdgeData> edges;
  final double zoom;
  final Offset pan;

  FlowchartCanvasPainter({
    required this.nodes,
    required this.edges,
    required this.zoom,
    required this.pan,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Apply transformations
    canvas.save();
    canvas.translate(pan.dx, pan.dy);
    canvas.scale(zoom);

    // Draw grid
    _drawGrid(canvas, size);

    // Draw edges
    for (final edge in edges) {
      _drawEdge(canvas, edge);
    }

    // Restore canvas
    canvas.restore();
  }

  void _drawGrid(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = Colors.grey.withOpacity(0.2)
      ..strokeWidth = 1.0;

    const gridSize = 16.0; // Snap-to-grid size

    // Draw vertical lines
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(
        Offset(x - pan.dx, -pan.dy),
        Offset(x - pan.dx, size.height - pan.dy),
        gridPaint,
      );
    }

    // Draw horizontal lines
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(
        Offset(-pan.dx, y - pan.dy),
        Offset(size.width - pan.dx, y - pan.dy),
        gridPaint,
      );
    }
  }

  void _drawEdge(Canvas canvas, FlowchartEdgeData edge) {
    final paint = Paint()
      ..color = edge.color
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    // Draw bezier curve
    final path = Path();
    path.moveTo(edge.start.dx, edge.start.dy);

    final controlPoint1 = Offset(
      edge.start.dx + (edge.end.dx - edge.start.dx) / 2,
      edge.start.dy,
    );
    final controlPoint2 = Offset(
      edge.start.dx + (edge.end.dx - edge.start.dx) / 2,
      edge.end.dy,
    );

    path.cubicTo(
      controlPoint1.dx,
      controlPoint1.dy,
      controlPoint2.dx,
      controlPoint2.dy,
      edge.end.dx,
      edge.end.dy,
    );

    canvas.drawPath(path, paint);

    // Draw arrow head
    _drawArrowHead(canvas, controlPoint2, edge.end, paint);
  }

  void _drawArrowHead(Canvas canvas, Offset from, Offset to, Paint paint) {
    const arrowSize = 8.0;
    final angle = (to - from).direction;

    final arrowPath = Path();
    arrowPath.moveTo(to.dx, to.dy);
    arrowPath.lineTo(
      to.dx - arrowSize * ui.lerpDouble(1, 0, 0.5)! * (1 + (angle / 3.14)),
      to.dy - arrowSize,
    );
    arrowPath.lineTo(
      to.dx - arrowSize * ui.lerpDouble(1, 0, 0.5)! * (1 - (angle / 3.14)),
      to.dy + arrowSize,
    );
    arrowPath.close();

    canvas.drawPath(arrowPath, paint..style = PaintingStyle.fill);
  }

  @override
  bool shouldRepaint(FlowchartCanvasPainter oldDelegate) {
    return nodes != oldDelegate.nodes ||
        edges != oldDelegate.edges ||
        zoom != oldDelegate.zoom ||
        pan != oldDelegate.pan;
  }
}

/// Data class for flowchart node
class FlowchartNodeData {
  final int id;
  final String type;
  final String name;
  final Offset position;
  final Map<String, dynamic> config;
  final List<String> inputPorts;
  final List<String> outputPorts;

  FlowchartNodeData({
    required this.id,
    required this.type,
    required this.name,
    required this.position,
    this.config = const {},
    this.inputPorts = const [],
    this.outputPorts = const [],
  });

  FlowchartNodeData copyWith({
    int? id,
    String? type,
    String? name,
    Offset? position,
    Map<String, dynamic>? config,
    List<String>? inputPorts,
    List<String>? outputPorts,
  }) {
    return FlowchartNodeData(
      id: id ?? this.id,
      type: type ?? this.type,
      name: name ?? this.name,
      position: position ?? this.position,
      config: config ?? this.config,
      inputPorts: inputPorts ?? this.inputPorts,
      outputPorts: outputPorts ?? this.outputPorts,
    );
  }
}

/// Data class for flowchart edge
class FlowchartEdgeData {
  final int id;
  final int fromNodeId;
  final int toNodeId;
  final String? fromPort;
  final String? toPort;
  final Offset start;
  final Offset end;
  final Color color;

  FlowchartEdgeData({
    required this.id,
    required this.fromNodeId,
    required this.toNodeId,
    this.fromPort,
    this.toPort,
    required this.start,
    required this.end,
    this.color = Colors.blue,
  });

  FlowchartEdgeData copyWith({
    int? id,
    int? fromNodeId,
    int? toNodeId,
    String? fromPort,
    String? toPort,
    Offset? start,
    Offset? end,
    Color? color,
  }) {
    return FlowchartEdgeData(
      id: id ?? this.id,
      fromNodeId: fromNodeId ?? this.fromNodeId,
      toNodeId: toNodeId ?? this.toNodeId,
      fromPort: fromPort ?? this.fromPort,
      toPort: toPort ?? this.toPort,
      start: start ?? this.start,
      end: end ?? this.end,
      color: color ?? this.color,
    );
  }
}
