import 'package:flutter/material.dart';
import 'dart:convert';
import 'node_types.dart';
import 'canvas_painter.dart';
import '../../core/storage/isar_service.dart';
import '../../core/storage/models/model_entry.dart';
import '../settings/models_management_screen.dart';

/// Dialog for configuring a node
class NodeConfigDialog extends StatefulWidget {
  final FlowchartNodeData node;
  final NodeType nodeType;

  const NodeConfigDialog({
    super.key,
    required this.node,
    required this.nodeType,
  });

  @override
  State<NodeConfigDialog> createState() => _NodeConfigDialogState();
}

class _NodeConfigDialogState extends State<NodeConfigDialog> {
  late TextEditingController _nameController;
  late Map<String, dynamic> _config;
  final IsarService _db = IsarService();
  List<ModelEntry> _availableModels = [];
  List<ModelEntry> _availableImageModels = [];
  ModelEntry? _selectedModel;
  ModelEntry? _selectedImageModel;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.node.name);
    _config = Map<String, dynamic>.from(widget.node.config);
    _loadModels();
  }

  Future<void> _loadModels() async {
    try {
      final allModels = await _db.getAllModels();
      
      // Load LLM models
      final llmModels = allModels.where((m) => m.modelType.toLowerCase() == 'llm').toList();
      
      // Load Image models
      final imageModels = allModels.where((m) => m.modelType.toLowerCase() == 'image').toList();
      
      setState(() {
        _availableModels = llmModels;
        _availableImageModels = imageModels;
        
        // Set selected LLM model
        if (_config.containsKey('modelId') && llmModels.isNotEmpty) {
          try {
            _selectedModel = llmModels.firstWhere(
              (m) => m.id == _config['modelId'],
            );
          } catch (e) {
            _selectedModel = llmModels.isNotEmpty ? llmModels.first : null;
          }
        } else if (llmModels.isNotEmpty) {
          _selectedModel = llmModels.first;
        }
        
        // Set selected Image model
        if (_config.containsKey('modelId') && imageModels.isNotEmpty) {
          try {
            _selectedImageModel = imageModels.firstWhere(
              (m) => m.id == _config['modelId'],
            );
          } catch (e) {
            _selectedImageModel = imageModels.isNotEmpty ? imageModels.first : null;
          }
        } else if (imageModels.isNotEmpty) {
          _selectedImageModel = imageModels.first;
        }
      });
    } catch (e) {
      setState(() {
        _availableModels = [];
        _availableImageModels = [];
        _selectedModel = null;
        _selectedImageModel = null;
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 600,
        height: 700,
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  _getIconData(widget.nodeType.icon),
                  color: widget.nodeType.color,
                  size: 32,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    widget.nodeType.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              widget.nodeType.description,
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 14,
              ),
            ),
            const Divider(height: 32),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Node Name
                    TextField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: 'Node Name',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 24),
                    
                    // Node-specific configuration
                    ..._buildNodeSpecificConfig(),
                  ],
                ),
              ),
            ),
            const Divider(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _save,
                  child: const Text('Save'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildNodeSpecificConfig() {
    switch (widget.nodeType.id) {
      case 'llm':
        return _buildLLMConfig();
      case 'image_generation':
        return _buildImageGenConfig();
      case 'http':
        return _buildHTTPConfig();
      case 'if':
        return _buildIfConfig();
      case 'switch':
        return _buildSwitchConfig();
      case 'compare':
        return _buildCompareConfig();
      case 'user_input':
        return _buildUserInputConfig();
      case 'output':
        return _buildOutputConfig();
      default:
        return [
          Text(
            'Configuration for ${widget.nodeType.name}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ];
    }
  }

  List<Widget> _buildLLMConfig() {
    // Set default values if not present
    if (!_config.containsKey('inputMapping')) {
      _config['inputMapping'] = '{{input}}';
    }
    if (!_config.containsKey('prompt')) {
      _config['prompt'] = '';
    }
    if (!_config.containsKey('systemPrompt')) {
      _config['systemPrompt'] = '';
    }
    if (!_config.containsKey('temperature')) {
      _config['temperature'] = 0.7;
    }
    if (!_config.containsKey('topP')) {
      _config['topP'] = 1.0;
    }
    if (!_config.containsKey('frequencyPenalty')) {
      _config['frequencyPenalty'] = 0.0;
    }
    if (!_config.containsKey('presencePenalty')) {
      _config['presencePenalty'] = 0.0;
    }
    if (!_config.containsKey('maxTokens')) {
      _config['maxTokens'] = 1000;
    }
    
    final maxTokensController = TextEditingController(
      text: (_config['maxTokens'] ?? 1000).toString(),
    );

    return [
      // Model Selection Section
      const Text(
        'Model Selection',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Choose an LLM model to use for this node',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 16),
      Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<ModelEntry>(
              value: _selectedModel,
              decoration: const InputDecoration(
                labelText: 'LLM Model *',
                border: OutlineInputBorder(),
                hintText: 'Select a model',
              ),
              items: _availableModels.map((model) {
                return DropdownMenuItem(
                  value: model,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        model.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${model.provider.toUpperCase()} • ${model.baseUrl}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (model) {
                setState(() {
                  _selectedModel = model;
                  _config['modelId'] = model?.id;
                });
              },
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ModelsManagementScreen(),
                ),
              );
              if (result == true || result == null) {
                // Reload models after adding new one
                await _loadModels();
              }
            },
            tooltip: 'Add New LLM Model',
            color: Theme.of(context).primaryColor,
          ),
        ],
      ),
      if (_availableModels.isEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(
            'No LLM models found. Click + to add one.',
            style: TextStyle(color: Colors.orange.shade700, fontSize: 12),
          ),
        ),
      const SizedBox(height: 24),

      // Max Tokens Configuration
      const Text(
        'Max Tokens',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Maximum number of tokens in the response',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: maxTokensController,
        decoration: const InputDecoration(
          labelText: 'Max Tokens *',
          border: OutlineInputBorder(),
          helperText: 'Maximum response length (default: 1000)',
        ),
        keyboardType: TextInputType.number,
        onChanged: (value) {
          final tokens = int.tryParse(value);
          if (tokens != null && tokens > 0) {
            _config['maxTokens'] = tokens;
          }
        },
      ),
      const SizedBox(height: 16),
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.blue.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.blue.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'This node receives input, processes it with the prompt through the selected LLM, and outputs the result.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.blue.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> _buildImageGenConfig() {
    final promptMappingController = TextEditingController(
      text: _config['promptMapping'] ?? '{{input}}',
    );
    
    return [
      // Model Selection Section
      const Text(
        'Model Selection',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Choose an Image Generation model to use for this node',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 16),
      Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<ModelEntry>(
              value: _selectedImageModel,
              decoration: const InputDecoration(
                labelText: 'Image Model *',
                border: OutlineInputBorder(),
                hintText: 'Select a model',
              ),
              items: _availableImageModels.map((model) {
                return DropdownMenuItem(
                  value: model,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        model.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${model.provider.toUpperCase()} • ${model.baseUrl}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (model) {
                setState(() {
                  _selectedImageModel = model;
                  _config['modelId'] = model?.id;
                });
              },
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ModelsManagementScreen(),
                ),
              );
              if (result == true || result == null) {
                // Reload models after adding new one
                await _loadModels();
              }
            },
            tooltip: 'Add New Image Model',
            color: Theme.of(context).primaryColor,
          ),
        ],
      ),
      if (_availableImageModels.isEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(
            'No Image Generation models found. Click + to add one.',
            style: TextStyle(color: Colors.orange.shade700, fontSize: 12),
          ),
        ),
      const SizedBox(height: 24),

      // Input Configuration
      const Text(
        'Input Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Configure how prompt flows into this node',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: promptMappingController,
        decoration: const InputDecoration(
          labelText: 'Prompt Mapping',
          hintText: '{{input}} or {{node_1.output}}',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax to reference inputs. The prompt will be taken from input.',
        ),
        onChanged: (value) {
          _config['promptMapping'] = value;
        },
      ),
      const SizedBox(height: 24),

      // Image Settings
      const Text(
        'Image Settings',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        value: _config['size'] ?? '1024x1024',
        decoration: const InputDecoration(
          labelText: 'Image Size',
          border: OutlineInputBorder(),
        ),
        items: ['256x256', '512x512', '1024x1024', '1024x1792', '1792x1024']
            .map((size) => DropdownMenuItem(value: size, child: Text(size)))
            .toList(),
        onChanged: (value) {
          setState(() {
            _config['size'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        value: _config['quality'] ?? 'standard',
        decoration: const InputDecoration(
          labelText: 'Quality',
          border: OutlineInputBorder(),
        ),
        items: ['standard', 'hd']
            .map((quality) => DropdownMenuItem(value: quality, child: Text(quality.toUpperCase())))
            .toList(),
        onChanged: (value) {
          setState(() {
            _config['quality'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        value: _config['style'] ?? 'vivid',
        decoration: const InputDecoration(
          labelText: 'Style',
          border: OutlineInputBorder(),
          helperText: 'Image generation style',
        ),
        items: ['vivid', 'natural']
            .map((style) => DropdownMenuItem(value: style, child: Text(style.toUpperCase())))
            .toList(),
        onChanged: (value) {
          setState(() {
            _config['style'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.pink.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.pink.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.pink.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'This node receives prompt from input, generates an image using the selected model, and outputs the image URL and data.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.pink.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> _buildHTTPConfig() {
    return [
      const Text(
        'HTTP Request Settings',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        value: _config['method'] ?? 'GET',
        decoration: const InputDecoration(
          labelText: 'Method',
          border: OutlineInputBorder(),
        ),
        items: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
            .map((method) => DropdownMenuItem(value: method, child: Text(method)))
            .toList(),
        onChanged: (value) {
          setState(() {
            _config['method'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      TextField(
        decoration: const InputDecoration(
          labelText: 'URL',
          border: OutlineInputBorder(),
          hintText: 'https://api.example.com/endpoint',
        ),
        onChanged: (value) {
          _config['url'] = value;
        },
        controller: TextEditingController(text: _config['url'] ?? ''),
      ),
    ];
  }

  List<Widget> _buildIfConfig() {
    final leftValueController = TextEditingController(
      text: _config['leftValue'] ?? '{{input}}',
    );
    final rightValueController = TextEditingController(
      text: _config['rightValue'] ?? '',
    );
    final operator = _config['operator'] ?? '==';
    
    return [
      const Text(
        'If Condition Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Compare two values and route to true/false output',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 24),
      
      // Left Operand
      const Text(
        'Left Operand',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: leftValueController,
        decoration: const InputDecoration(
          labelText: 'Left Value *',
          hintText: '{{input}} or {{node_1.output}} or static value',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax or enter a static value',
        ),
        onChanged: (value) {
          _config['leftValue'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Operator
      const Text(
        'Comparison Operator',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: operator,
        decoration: const InputDecoration(
          labelText: 'Operator *',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: '==', child: Text('Equal (==)')),
          DropdownMenuItem(value: '!=', child: Text('Not Equal (!=)')),
          DropdownMenuItem(value: '>', child: Text('Greater Than (>)')),
          DropdownMenuItem(value: '<', child: Text('Less Than (<)')),
          DropdownMenuItem(value: '>=', child: Text('Greater or Equal (>=)')),
          DropdownMenuItem(value: '<=', child: Text('Less or Equal (<=)')),
          DropdownMenuItem(value: 'contains', child: Text('Contains')),
          DropdownMenuItem(value: 'startsWith', child: Text('Starts With')),
          DropdownMenuItem(value: 'endsWith', child: Text('Ends With')),
        ],
        onChanged: (value) {
          setState(() {
            _config['operator'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // Right Operand
      const Text(
        'Right Operand',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: rightValueController,
        decoration: const InputDecoration(
          labelText: 'Right Value *',
          hintText: '{{input}} or {{node_1.output}} or static value',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax or enter a static value',
        ),
        onChanged: (value) {
          _config['rightValue'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.orange.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.orange.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.orange.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'This node compares left and right values. If condition is true, outputs to "true" port. Otherwise, outputs to "false" port.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.orange.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> _buildSwitchConfig() {
    final valueController = TextEditingController(
      text: _config['value'] ?? '{{input}}',
    );
    final casesController = TextEditingController(
      text: _config['casesJson'] ?? '{"case1": "value1", "case2": "value2"}',
    );
    final defaultController = TextEditingController(
      text: _config['default'] ?? '',
    );
    
    return [
      const Text(
        'Switch Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Route to different outputs based on input value',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 24),
      
      // Input Value
      const Text(
        'Input Value',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: valueController,
        decoration: const InputDecoration(
          labelText: 'Value to Match *',
          hintText: '{{input}} or {{node_1.output}}',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax to reference input',
        ),
        onChanged: (value) {
          _config['value'] = value;
        },
      ),
      const SizedBox(height: 24),
      
      // Cases
      const Text(
        'Cases',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: casesController,
        decoration: const InputDecoration(
          labelText: 'Cases (JSON) *',
          hintText: '{"case1": "output1", "case2": "output2"}',
          border: OutlineInputBorder(),
          helperText: 'JSON object mapping case values to outputs',
        ),
        maxLines: 5,
        onChanged: (value) {
          _config['casesJson'] = value;
          try {
            _config['cases'] = jsonDecode(value);
          } catch (e) {
            // Invalid JSON, will be validated on save
          }
        },
      ),
      const SizedBox(height: 16),
      
      // Default Case
      TextField(
        controller: defaultController,
        decoration: const InputDecoration(
          labelText: 'Default Output (optional)',
          hintText: 'Output when no case matches',
          border: OutlineInputBorder(),
        ),
        onChanged: (value) {
          _config['default'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.deepOrange.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.deepOrange.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.deepOrange.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'This node matches the input value against cases. If a match is found, outputs to the corresponding port. Otherwise, outputs to "default" port.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.deepOrange.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> _buildCompareConfig() {
    final valueAController = TextEditingController(
      text: _config['valueA'] ?? '{{input}}',
    );
    final valueBController = TextEditingController(
      text: _config['valueB'] ?? '',
    );
    final operator = _config['operator'] ?? '==';
    
    return [
      const Text(
        'Compare Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Compare two values and output the result',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 24),
      
      // Value A
      const Text(
        'Value A',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: valueAController,
        decoration: const InputDecoration(
          labelText: 'Value A *',
          hintText: '{{input}} or {{node_1.output}} or static value',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax or enter a static value',
        ),
        onChanged: (value) {
          _config['valueA'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Operator
      const Text(
        'Comparison Operator',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: operator,
        decoration: const InputDecoration(
          labelText: 'Operator *',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: '==', child: Text('Equal (==)')),
          DropdownMenuItem(value: '!=', child: Text('Not Equal (!=)')),
          DropdownMenuItem(value: '>', child: Text('Greater Than (>)')),
          DropdownMenuItem(value: '<', child: Text('Less Than (<)')),
          DropdownMenuItem(value: '>=', child: Text('Greater or Equal (>=)')),
          DropdownMenuItem(value: '<=', child: Text('Less or Equal (<=)')),
          DropdownMenuItem(value: 'contains', child: Text('Contains')),
          DropdownMenuItem(value: 'startsWith', child: Text('Starts With')),
          DropdownMenuItem(value: 'endsWith', child: Text('Ends With')),
          DropdownMenuItem(value: 'in', child: Text('In (list contains)')),
        ],
        onChanged: (value) {
          setState(() {
            _config['operator'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // Value B
      const Text(
        'Value B',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      TextField(
        controller: valueBController,
        decoration: const InputDecoration(
          labelText: 'Value B *',
          hintText: '{{input}} or {{node_1.output}} or static value',
          border: OutlineInputBorder(),
          helperText: 'Use {{variable}} syntax or enter a static value',
        ),
        onChanged: (value) {
          _config['valueB'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.amber.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.amber.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.amber.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'This node compares Value A and Value B using the selected operator and outputs the boolean result.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.amber.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'smart_toy':
        return Icons.smart_toy;
      case 'image':
        return Icons.image;
      case 'layers':
        return Icons.layers;
      case 'call_split':
        return Icons.call_split;
      case 'alt_route':
        return Icons.alt_route;
      case 'compare_arrows':
        return Icons.compare_arrows;
      case 'http':
        return Icons.http;
      case 'code':
        return Icons.code;
      case 'data_object':
        return Icons.data_object;
      case 'label':
        return Icons.label;
      case 'schedule':
        return Icons.schedule;
      case 'merge_type':
        return Icons.merge_type;
      case 'input':
        return Icons.input;
      case 'output':
        return Icons.output;
      default:
        return Icons.circle;
    }
  }

  List<Widget> _buildUserInputConfig() {
    final promptController = TextEditingController(
      text: _config['prompt'] ?? 'Enter input:',
    );
    final defaultValueController = TextEditingController(
      text: _config['defaultValue']?.toString() ?? '',
    );
    final inputType = _config['inputType'] ?? 'text';
    final required = _config['required'] ?? false;
    
    return [
      const Text(
        'User Input Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Configure how users will provide input during workflow execution',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 24),
      
      // Prompt
      TextField(
        controller: promptController,
        decoration: const InputDecoration(
          labelText: 'Prompt *',
          hintText: 'Enter input:',
          border: OutlineInputBorder(),
          helperText: 'Message shown to user when requesting input',
        ),
        maxLines: 2,
        onChanged: (value) {
          _config['prompt'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Input Type
      DropdownButtonFormField<String>(
        value: inputType,
        decoration: const InputDecoration(
          labelText: 'Input Type',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 'text', child: Text('Text')),
          DropdownMenuItem(value: 'number', child: Text('Number')),
          DropdownMenuItem(value: 'boolean', child: Text('Boolean')),
          DropdownMenuItem(value: 'textarea', child: Text('Textarea')),
          DropdownMenuItem(value: 'select', child: Text('Select')),
        ],
        onChanged: (value) {
          setState(() {
            _config['inputType'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // Default Value
      TextField(
        controller: defaultValueController,
        decoration: const InputDecoration(
          labelText: 'Default Value (optional)',
          hintText: 'Default value if user skips',
          border: OutlineInputBorder(),
        ),
        onChanged: (value) {
          _config['defaultValue'] = value;
        },
      ),
      const SizedBox(height: 16),
      
      // Required
      SwitchListTile(
        title: const Text('Required'),
        subtitle: const Text('User must provide input'),
        value: required,
        onChanged: (value) {
          setState(() {
            _config['required'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.blueGrey.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.blueGrey.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.blueGrey.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'During workflow execution, a dialog will appear asking the user for input based on these settings.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.blueGrey.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> _buildOutputConfig() {
    final displayType = _config['displayType'] ?? 'text';
    
    return [
      const Text(
        'Output Configuration',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      Text(
        'Configure how the output will be displayed',
        style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      ),
      const SizedBox(height: 24),
      
      // Display Type
      DropdownButtonFormField<String>(
        value: displayType,
        decoration: const InputDecoration(
          labelText: 'Display Type',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 'text', child: Text('Text')),
          DropdownMenuItem(value: 'json', child: Text('JSON')),
          DropdownMenuItem(value: 'image', child: Text('Image')),
          DropdownMenuItem(value: 'table', child: Text('Table')),
        ],
        onChanged: (value) {
          setState(() {
            _config['displayType'] = value;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // Info box
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.deepPurple.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.deepPurple.shade200),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.deepPurple.shade700, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'During workflow execution, a dialog will appear showing the output data from connected nodes.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.deepPurple.shade900,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  void _save() {
    Navigator.pop(context, {
      'name': _nameController.text,
      'config': _config,
    });
  }
}

