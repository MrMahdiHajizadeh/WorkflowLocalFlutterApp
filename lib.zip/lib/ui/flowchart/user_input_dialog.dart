import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Dialog for getting user input during workflow execution
class UserInputDialog extends StatefulWidget {
  final String prompt;
  final String inputType;
  final bool required;
  final dynamic defaultValue;

  const UserInputDialog({
    super.key,
    required this.prompt,
    this.inputType = 'text',
    this.required = false,
    this.defaultValue,
  });

  @override
  State<UserInputDialog> createState() => _UserInputDialogState();

  /// Show dialog and return user input
  static Future<dynamic> show(
    BuildContext context, {
    required String prompt,
    String inputType = 'text',
    bool required = false,
    dynamic defaultValue,
  }) async {
    return await showDialog<dynamic>(
      context: context,
      barrierDismissible: !required,
      builder: (context) => UserInputDialog(
        prompt: prompt,
        inputType: inputType,
        required: required,
        defaultValue: defaultValue,
      ),
    );
  }
}

class _UserInputDialogState extends State<UserInputDialog> {
  late TextEditingController _textController;
  late TextEditingController _numberController;
  bool _boolValue = false;
  String? _selectedOption;
  List<String>? _options;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController(text: widget.defaultValue?.toString() ?? '');
    _numberController = TextEditingController(text: widget.defaultValue?.toString() ?? '');
    _boolValue = widget.defaultValue as bool? ?? false;
    _selectedOption = widget.defaultValue?.toString();
    
    // Parse options from prompt if it's a select type
    if (widget.inputType == 'select' && widget.prompt.contains('[')) {
      final match = RegExp(r'\[(.*?)\]').firstMatch(widget.prompt);
      if (match != null) {
        _options = match.group(1)?.split(',').map((e) => e.trim()).toList();
      }
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    _numberController.dispose();
    super.dispose();
  }

  void _submit() {
    dynamic value;
    
    switch (widget.inputType) {
      case 'number':
        value = num.tryParse(_numberController.text);
        if (value == null && widget.required) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Please enter a valid number')),
          );
          return;
        }
        break;
      case 'boolean':
      case 'bool':
        value = _boolValue;
        break;
      case 'select':
        if (_selectedOption == null && widget.required) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Please select an option')),
          );
          return;
        }
        value = _selectedOption;
        break;
      default:
        value = _textController.text;
        if (value.toString().isEmpty && widget.required) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('This field is required')),
          );
          return;
        }
    }

    Navigator.pop(context, value);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Icon(Icons.input, color: Colors.blue),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'User Input Required',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
        ],
      ),
      content: SizedBox(
        width: 400,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.prompt,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            _buildInputField(),
          ],
        ),
      ),
      actions: [
        if (!widget.required)
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: const Text('Skip'),
          ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Submit'),
        ),
      ],
    );
  }

  Widget _buildInputField() {
    switch (widget.inputType) {
      case 'number':
        return TextField(
          controller: _numberController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Enter a number',
            border: OutlineInputBorder(),
          ),
        );

      case 'boolean':
      case 'bool':
        return SwitchListTile(
          title: const Text('Value'),
          value: _boolValue,
          onChanged: (value) {
            setState(() {
              _boolValue = value;
            });
          },
        );

      case 'select':
        if (_options == null || _options!.isEmpty) {
          return const Text('No options available');
        }
        return DropdownButtonFormField<String>(
          value: _selectedOption,
          decoration: const InputDecoration(
            labelText: 'Select an option',
            border: OutlineInputBorder(),
          ),
          items: _options!.map((option) {
            return DropdownMenuItem(
              value: option,
              child: Text(option),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedOption = value;
            });
          },
        );

      case 'textarea':
      case 'multiline':
        return TextField(
          controller: _textController,
          maxLines: 5,
          decoration: const InputDecoration(
            labelText: 'Enter text',
            border: OutlineInputBorder(),
          ),
        );

      default:
        return TextField(
          controller: _textController,
          decoration: const InputDecoration(
            labelText: 'Enter text',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (_) => _submit(),
        );
    }
  }
}

