import 'package:flutter/material.dart';
import 'canvas_painter.dart';

/// Custom painter for drawing connections between nodes
class ConnectionPainter extends CustomPainter {
  final List<FlowchartEdgeData> edges;
  final List<FlowchartNodeData> nodes;
  final double zoom;
  final Offset pan;
  final Offset? tempConnectionStart;
  final Offset? tempConnectionEnd;

  ConnectionPainter({
    required this.edges,
    required this.nodes,
    required this.zoom,
    required this.pan,
    this.tempConnectionStart,
    this.tempConnectionEnd,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.translate(pan.dx, pan.dy);
    canvas.scale(zoom);

    // Draw all edges
    for (final edge in edges) {
      _drawConnection(canvas, edge);
    }

    // Draw temporary connection being drawn
    if (tempConnectionStart != null && tempConnectionEnd != null) {
      _drawTempConnection(canvas, tempConnectionStart!, tempConnectionEnd!);
    }

    canvas.restore();
  }

  void _drawConnection(Canvas canvas, FlowchartEdgeData edge) {
    final paint = Paint()
      ..color = edge.color
      ..strokeWidth = 2.0 / zoom // Single line - thinner stroke width
      ..style = PaintingStyle.stroke;

    // Calculate actual start and end points from node positions
    final fromNode = nodes.firstWhere((n) => n.id == edge.fromNodeId);
    final toNode = nodes.firstWhere((n) => n.id == edge.toNodeId);

    final startPoint = _getOutputPortPosition(fromNode, edge.fromPort);
    final endPoint = _getInputPortPosition(toNode, edge.toPort);

    // Draw bezier curve
    final path = _createBezierPath(startPoint, endPoint);
    canvas.drawPath(path, paint);

    // Draw arrow head
    _drawArrowHead(canvas, endPoint, paint);
  }

  void _drawTempConnection(Canvas canvas, Offset start, Offset end) {
    final paint = Paint()
      ..color = Colors.blue.withOpacity(0.7)
      ..strokeWidth = 2.0 / zoom // Single line - thinner stroke width
      ..style = PaintingStyle.stroke;

    // Start and end are already in canvas coordinates, so we don't need to transform them
    final path = _createBezierPath(start, end);
    canvas.drawPath(path, paint);
    
    // Draw arrow head
    _drawArrowHead(canvas, end, paint);
  }

  Path _createBezierPath(Offset start, Offset end) {
    final path = Path();
    path.moveTo(start.dx, start.dy);

    final controlPoint1 = Offset(
      start.dx + (end.dx - start.dx) * 0.5,
      start.dy,
    );
    final controlPoint2 = Offset(
      start.dx + (end.dx - start.dx) * 0.5,
      end.dy,
    );

    path.cubicTo(
      controlPoint1.dx,
      controlPoint1.dy,
      controlPoint2.dx,
      controlPoint2.dy,
      end.dx,
      end.dy,
    );

    return path;
  }

  void _drawArrowHead(Canvas canvas, Offset point, Paint paint) {
    final arrowSize = 8.0 / zoom; // Scale arrow size with zoom

    final arrowPath = Path();
    arrowPath.moveTo(point.dx, point.dy);
    arrowPath.lineTo(
      point.dx - arrowSize * 1.5,
      point.dy - arrowSize,
    );
    arrowPath.lineTo(
      point.dx - arrowSize * 1.5,
      point.dy + arrowSize,
    );
    arrowPath.close();

    canvas.drawPath(arrowPath, paint..style = PaintingStyle.fill);
  }

  Offset _getOutputPortPosition(FlowchartNodeData node, String? portName) {
    const nodeWidth = 180.0;
    const headerHeight = 50.0;
    const portHeight = 30.0;
    final portNameToFind = portName ?? node.outputPorts.first;
    final portIndex = node.outputPorts.indexOf(portNameToFind);
    if (portIndex == -1) {
      // Fallback to first port
      return Offset(
        node.position.dx + nodeWidth,
        node.position.dy + headerHeight + 15,
      );
    }
    
    return Offset(
      node.position.dx + nodeWidth,
      node.position.dy + headerHeight + (portIndex * portHeight) + 15, // Center of port
    );
  }

  Offset _getInputPortPosition(FlowchartNodeData node, String? portName) {
    const headerHeight = 50.0;
    const portHeight = 30.0;
    final portNameToFind = portName ?? node.inputPorts.first;
    final portIndex = node.inputPorts.indexOf(portNameToFind);
    if (portIndex == -1) {
      // Fallback to first port
      return Offset(
        node.position.dx,
        node.position.dy + headerHeight + 15,
      );
    }
    
    return Offset(
      node.position.dx,
      node.position.dy + headerHeight + (portIndex * portHeight) + 15, // Center of port
    );
  }

  @override
  bool shouldRepaint(ConnectionPainter oldDelegate) {
    return edges != oldDelegate.edges ||
        nodes != oldDelegate.nodes ||
        zoom != oldDelegate.zoom ||
        pan != oldDelegate.pan ||
        tempConnectionStart != oldDelegate.tempConnectionStart ||
        tempConnectionEnd != oldDelegate.tempConnectionEnd;
  }
}

