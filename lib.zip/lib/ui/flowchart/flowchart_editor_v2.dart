import 'package:flutter/material.dart';
import 'dart:convert';
import 'canvas_painter.dart';
import 'connection_painter.dart';
import 'node_types.dart';
import 'node_config_dialog.dart';
import 'output_viewer.dart';
import 'user_input_dialog.dart';
import '../../core/storage/isar_service.dart';
import '../../core/storage/models/workflow.dart';
import '../../core/storage/models/workflow_node.dart';
import '../../core/storage/models/workflow_edge.dart';
import '../../core/workflow_engine/interactive_executor.dart';
import '../../core/workflow_engine/data_validator.dart';
import '../../core/workflow_engine/dag_parser.dart';

/// Enhanced flowchart editor with n8n-like features
class FlowchartEditorScreenV2 extends StatefulWidget {
  final int workflowId;
  final String? workflowName;

  const FlowchartEditorScreenV2({
    super.key, 
    required this.workflowId,
    this.workflowName,
  });

  @override
  State<FlowchartEditorScreenV2> createState() => _FlowchartEditorScreenV2State();
}

class _FlowchartEditorScreenV2State extends State<FlowchartEditorScreenV2> {
  final IsarService _db = IsarService();
  
  // Zoom and pan settings
  static const double _defaultNodeScale = 1.0; // Fixed scale for nodes
  static const double _minZoom = 0.3; // Allow zoom out to see more nodes
  static const double _maxZoom = 3.0;
  
  double _zoom = 1.0;
  Offset _pan = Offset.zero;

  List<FlowchartNodeData> _nodes = [];
  List<FlowchartEdgeData> _edges = [];
  
  // Connection state - click-based connection
  int? _connectingFromNodeId;
  String? _connectingFromPort;
  Offset? _connectionStartPoint;
  Offset? _connectionEndPoint;
  bool _isConnectionMode = false; // Track if we're in connection mode
  
  // Selected node for configuration
  FlowchartNodeData? _selectedNode;
  
  // Dragging state
  FlowchartNodeData? _draggingNode;
  Offset? _dragStartPosition;
  
  // Pan state
  bool _isPanning = false;
  Offset? _panStartPosition;
  Offset? _panStartOffset;

  @override
  void initState() {
    super.initState();
    _loadWorkflow();
  }

  Future<void> _loadWorkflow() async {
    final nodes = await _db.getNodesByWorkflow(widget.workflowId);
    final edges = await _db.getEdgesByWorkflow(widget.workflowId);
    
    setState(() {
      _nodes = nodes.map((n) {
        final nodeType = NodeType.getById(n.type);
        return FlowchartNodeData(
          id: n.id.toInt(),
          type: n.type,
          name: n.name,
          position: Offset(n.positionX, n.positionY),
          config: n.configJson.isNotEmpty 
              ? Map<String, dynamic>.from(
                  const JsonDecoder().convert(n.configJson)
                )
              : {},
          inputPorts: nodeType?.inputPorts ?? [],
          outputPorts: nodeType?.outputPorts ?? [],
        );
      }).toList();
      
      _edges = edges.map((e) {
        final fromNode = _nodes.firstWhere((n) => n.id == e.fromNodeId);
        final toNode = _nodes.firstWhere((n) => n.id == e.toNodeId);
        return FlowchartEdgeData(
          id: e.id.toInt(),
          fromNodeId: e.fromNodeId,
          toNodeId: e.toNodeId,
          fromPort: e.fromPort ?? e.label, // Load fromPort from database
          toPort: e.toPort, // Load toPort from database
          start: Offset(fromNode.position.dx + 180, fromNode.position.dy + 30),
          end: Offset(toNode.position.dx, toNode.position.dy + 30),
        );
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workflow Editor'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle),
            onPressed: _showNodeSelector,
            tooltip: 'Add Node',
          ),
          IconButton(
            icon: const Icon(Icons.play_arrow),
            onPressed: _runWorkflow,
            tooltip: 'Run Workflow',
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveWorkflow,
            tooltip: 'Save Workflow',
          ),
        ],
      ),
      body: Stack(
        children: [
          // Canvas background
          GestureDetector(
            behavior: HitTestBehavior.opaque, // Capture gestures on canvas
            onScaleStart: (details) {
              // Store initial pan position and focal point for panning
              if (!_isConnectionMode && _selectedNode == null) {
                setState(() {
                  _isPanning = true;
                  _panStartPosition = details.focalPoint;
                  _panStartOffset = _pan;
                });
              }
            },
            onScaleUpdate: (details) {
              setState(() {
                // Check if it's a pan gesture (scale close to 1.0) or zoom gesture
                const panThreshold = 0.05; // If scale change is less than 5%, treat as pan
                final isPanning = (details.scale - 1.0).abs() < panThreshold;
                
                if (isPanning && _isPanning && _panStartPosition != null && _panStartOffset != null) {
                  // Pan the canvas
                  final delta = details.focalPoint - _panStartPosition!;
                  _pan = _panStartOffset! + delta;
                } else {
                  // Zoom the canvas
                  final newZoom = (_zoom * details.scale).clamp(_minZoom, _maxZoom);
                  
                  // Calculate focal point in canvas coordinates (before zoom change)
                  final focalPointCanvas = Offset(
                    (details.focalPoint.dx - _pan.dx) / _zoom,
                    (details.focalPoint.dy - _pan.dy) / _zoom,
                  );
                  
                  // Update pan to keep focal point fixed during zoom
                  _pan = Offset(
                    details.focalPoint.dx - focalPointCanvas.dx * newZoom,
                    details.focalPoint.dy - focalPointCanvas.dy * newZoom,
                  );
                  
                  _zoom = newZoom;
                  
                  // Reset panning state during zoom
                  _isPanning = false;
                  _panStartPosition = null;
                  _panStartOffset = null;
                }
              });
            },
            onScaleEnd: (details) {
              setState(() {
                _isPanning = false;
                _panStartPosition = null;
                _panStartOffset = null;
              });
            },
            onTap: () {
              setState(() {
                _selectedNode = null;
                // Cancel connection mode if clicking on canvas
                if (_isConnectionMode) {
                  _isConnectionMode = false;
                  _connectingFromNodeId = null;
                  _connectingFromPort = null;
                  _connectionStartPoint = null;
                  _connectionEndPoint = null;
                }
              });
            },
            child: Stack(
              children: [
                // Grid background
                CustomPaint(
                  painter: FlowchartCanvasPainter(
                    nodes: _nodes,
                    edges: _edges,
                    zoom: _zoom,
                    pan: _pan,
                  ),
                  size: Size.infinite,
                ),
                // Connections
                CustomPaint(
                  painter: ConnectionPainter(
                    edges: _edges,
                    nodes: _nodes,
                    zoom: _zoom,
                    pan: _pan,
                    tempConnectionStart: _connectionStartPoint,
                    tempConnectionEnd: _connectionEndPoint,
                  ),
                  size: Size.infinite,
                ),
              ],
            ),
          ),

          // Nodes with ports
          ..._nodes.map((node) => _buildNodeWidget(node)),

          // Toolbar
          Positioned(
            top: 16,
            left: 16,
            child: _buildToolbar(),
          ),
        ],
      ),
    );
  }

  Widget _buildNodeWidget(FlowchartNodeData node) {
    final nodeType = NodeType.getById(node.type);
    if (nodeType == null) return const SizedBox.shrink();

    final isSelected = _selectedNode?.id == node.id;
    
    // Calculate transformed position
    // Node position in canvas coordinates, apply zoom and pan
    // Node size stays fixed (scale = 1.0), only position scales with zoom
    final transformedPosition = Offset(
      node.position.dx * _zoom + _pan.dx,
      node.position.dy * _zoom + _pan.dy,
    );
    
    return Positioned(
      left: transformedPosition.dx,
      top: transformedPosition.dy,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque, // Ensure gestures work properly
        onTap: () {
          // Cancel connection mode if clicking on empty space (node body)
          if (_isConnectionMode) {
            setState(() {
              _isConnectionMode = false;
              _connectingFromNodeId = null;
              _connectingFromPort = null;
              _connectionStartPoint = null;
              _connectionEndPoint = null;
            });
          } else {
            setState(() {
              _selectedNode = node;
            });
          }
        },
        onLongPress: () => _showNodeMenu(node),
        onPanStart: (details) {
          // Only start dragging node if not panning canvas
          if (!_isPanning) {
            setState(() {
              _draggingNode = node;
              _dragStartPosition = details.localPosition;
            });
          }
        },
        onPanUpdate: (details) {
          // Only drag node if not connecting ports, not in connection mode, and not panning canvas
          if (_draggingNode != null && _dragStartPosition != null && !_isConnectionMode && !_isPanning) {
            setState(() {
              final index = _nodes.indexWhere((n) => n.id == node.id);
              if (index != -1) {
                // Calculate delta in screen coordinates
                final screenDelta = details.localPosition - _dragStartPosition!;
                // Convert screen delta to canvas delta (divide by zoom to get canvas space)
                final canvasDelta = Offset(
                  screenDelta.dx / _zoom,
                  screenDelta.dy / _zoom,
                );
                _nodes[index] = node.copyWith(
                  position: node.position + canvasDelta,
                );
                _dragStartPosition = details.localPosition;
              }
            });
          }
        },
        onPanEnd: (details) {
          setState(() {
            _draggingNode = null;
            _dragStartPosition = null;
          });
        },
        child: Transform.scale(
          scale: _defaultNodeScale, // Fixed scale for nodes - always same size (1.0)
          child: _buildNodeCard(node, nodeType, isSelected),
        ),
      ),
    );
  }

  Widget _buildNodeCard(FlowchartNodeData node, NodeType nodeType, bool isSelected) {
    // Node size is fixed, not affected by zoom
    return Container(
      width: 180,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isSelected ? nodeType.color : Colors.grey.shade300,
          width: isSelected ? 3 : 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: nodeType.color.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  _getIconData(nodeType.icon),
                  color: nodeType.color,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    node.name,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          
          // Input Ports
          if (node.inputPorts.isNotEmpty)
            ...node.inputPorts.map((port) => _buildInputPort(node, port)),
          
          // Output Ports
          if (node.outputPorts.isNotEmpty)
            ...node.outputPorts.map((port) => _buildOutputPort(node, port)),
        ],
      ),
    );
  }

  Widget _buildInputPort(FlowchartNodeData node, String portName) {
    final isConnected = _edges.any((e) => e.toNodeId == node.id && e.toPort == portName);
    final isTargetPort = _isConnectionMode && _connectingFromNodeId != null && _connectingFromNodeId != node.id;
    
    return GestureDetector(
      onTap: () {
        if (_isConnectionMode && _connectingFromNodeId != null && _connectingFromNodeId != node.id) {
          // Complete connection: click on input port
          _completeConnection(node.id, portName, true);
        } else if (!_isConnectionMode) {
          // Start connection mode by clicking on input port (if no output port selected)
          // Actually, we should start from output port, so this does nothing
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isTargetPort 
              ? Colors.green.shade100 
              : (isConnected ? Colors.green.shade50 : Colors.transparent),
          border: isTargetPort 
              ? Border.all(color: Colors.green, width: 2)
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: isTargetPort 
                    ? Colors.green.shade700 
                    : (isConnected ? Colors.green : Colors.green.shade300),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                portName,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isConnected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOutputPort(FlowchartNodeData node, String portName) {
    final isConnected = _edges.any((e) => e.fromNodeId == node.id && e.fromPort == portName);
    final isConnecting = _isConnectionMode && _connectingFromNodeId == node.id && _connectingFromPort == portName;
    
    return GestureDetector(
      onTap: () {
        if (!_isConnectionMode) {
          // Start connection mode: click on output port
          setState(() {
            _isConnectionMode = true;
            _connectingFromNodeId = node.id;
            _connectingFromPort = portName;
            // Get port position in canvas coordinates
            final portCanvasPos = _getOutputPortCanvasPosition(node, portName);
            _connectionStartPoint = portCanvasPos;
            _connectionEndPoint = portCanvasPos; // Start with same point
          });
          
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Click on an input port to complete connection'),
              duration: Duration(seconds: 2),
            ),
          );
        } else if (_connectingFromNodeId == node.id && _connectingFromPort == portName) {
          // Cancel connection if clicking same port again
          setState(() {
            _isConnectionMode = false;
            _connectingFromNodeId = null;
            _connectingFromPort = null;
            _connectionStartPoint = null;
            _connectionEndPoint = null;
          });
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isConnecting 
              ? Colors.green.shade100 
              : (isConnected 
                  ? Colors.green.shade50 
                  : (_isConnectionMode && !isConnecting 
                      ? Colors.blue.shade50 
                      : Colors.transparent)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
              child: Text(
                portName,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isConnected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: isConnecting 
                    ? Colors.green.shade700 
                    : (isConnected 
                        ? Colors.green 
                        : (_isConnectionMode && !isConnecting 
                            ? Colors.blue.shade400 
                            : Colors.green.shade300)),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  /// Get output port position in canvas coordinates (not global)
  Offset _getOutputPortCanvasPosition(FlowchartNodeData node, String portName) {
    const nodeWidth = 180.0;
    const headerHeight = 50.0;
    const portHeight = 30.0;
    final portIndex = node.outputPorts.indexOf(portName);
    if (portIndex == -1) {
      // Fallback to first port
      return Offset(
        node.position.dx + nodeWidth,
        node.position.dy + headerHeight + 15,
      );
    }
    
    // Return position in canvas coordinates (not accounting for zoom/pan)
    return Offset(
      node.position.dx + nodeWidth,
      node.position.dy + headerHeight + (portIndex * portHeight) + 15, // Center of port
    );
  }
  
  /// Get input port position in canvas coordinates (not global)
  Offset _getInputPortCanvasPosition(FlowchartNodeData node, String portName) {
    const headerHeight = 50.0;
    const portHeight = 30.0;
    final portIndex = node.inputPorts.indexOf(portName);
    if (portIndex == -1) {
      // Fallback to first port
      return Offset(
        node.position.dx,
        node.position.dy + headerHeight + 15,
      );
    }
    
    // Return position in canvas coordinates (not accounting for zoom/pan)
    return Offset(
      node.position.dx,
      node.position.dy + headerHeight + (portIndex * portHeight) + 15, // Center of port
    );
  }
  


  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Zoom: ${(_zoom * 100).toInt()}%'),
          Slider(
            value: _zoom,
            min: _minZoom,
            max: _maxZoom,
            onChanged: (value) {
              setState(() {
                _zoom = value;
              });
            },
          ),
        ],
      ),
    );
  }

  void _showNodeSelector() {
    showModalBottomSheet(
      context: context,
      builder: (context) => _NodeSelector(
        onNodeSelected: (nodeType) {
          _addNode(nodeType);
          Navigator.pop(context);
        },
      ),
    );
  }

  void _addNode(NodeType nodeType) {
    setState(() {
      _nodes.add(FlowchartNodeData(
        id: _nodes.isEmpty ? 1 : _nodes.map((n) => n.id).reduce((a, b) => a > b ? a : b) + 1,
        type: nodeType.id,
        name: nodeType.name,
        position: Offset(200 + _nodes.length * 20.0, 200 + _nodes.length * 20.0),
        inputPorts: nodeType.inputPorts,
        outputPorts: nodeType.outputPorts,
      ));
    });
  }

  void _showNodeMenu(FlowchartNodeData node) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Configure'),
              onTap: () {
                Navigator.pop(context);
                _showNodeConfig(node);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Delete', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _deleteNode(node);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showNodeConfig(FlowchartNodeData node) {
    final nodeType = NodeType.getById(node.type);
    if (nodeType == null) return;

    showDialog(
      context: context,
      builder: (context) => NodeConfigDialog(
        node: node,
        nodeType: nodeType,
      ),
    ).then((result) {
      if (result != null) {
        setState(() {
          final index = _nodes.indexWhere((n) => n.id == node.id);
          if (index != -1) {
            _nodes[index] = node.copyWith(
              name: result['name'],
              config: result['config'],
            );
          }
        });
      }
    });
  }

  void _deleteNode(FlowchartNodeData node) {
    setState(() {
      // Remove node
      _nodes.removeWhere((n) => n.id == node.id);
      // Remove all edges connected to this node
      _edges.removeWhere((e) => e.fromNodeId == node.id || e.toNodeId == node.id);
      // Clear selection if deleted node was selected
      if (_selectedNode?.id == node.id) {
        _selectedNode = null;
      }
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Node deleted')),
    );
  }

  void _completeConnection(int toNodeId, String toPort, bool isInput) {
    if (_connectingFromNodeId == null || !_isConnectionMode) return;
    
    // Don't allow self-connection
    if (_connectingFromNodeId == toNodeId) {
      setState(() {
        _isConnectionMode = false;
        _connectingFromNodeId = null;
        _connectingFromPort = null;
        _connectionStartPoint = null;
        _connectionEndPoint = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cannot connect node to itself'), duration: Duration(seconds: 1)),
      );
      return;
    }
    
    // Check if connection already exists
    final existingConnection = _edges.any((e) => 
      e.fromNodeId == _connectingFromNodeId && 
      e.toNodeId == toNodeId && 
      e.fromPort == _connectingFromPort &&
      e.toPort == toPort
    );
    
    if (existingConnection) {
      setState(() {
        _isConnectionMode = false;
        _connectingFromNodeId = null;
        _connectingFromPort = null;
        _connectionStartPoint = null;
        _connectionEndPoint = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Connection already exists'), duration: Duration(seconds: 1)),
      );
      return;
    }
    
    final fromNode = _nodes.firstWhere((n) => n.id == _connectingFromNodeId);
    final toNode = _nodes.firstWhere((n) => n.id == toNodeId);
    
    // Get actual port positions
    final startPos = _getOutputPortCanvasPosition(fromNode, _connectingFromPort ?? 'output');
    final endPos = _getInputPortCanvasPosition(toNode, toPort);
    
    setState(() {
      _edges.add(FlowchartEdgeData(
        id: _edges.isEmpty ? 1 : _edges.map((e) => e.id).reduce((a, b) => a > b ? a : b) + 1,
        fromNodeId: _connectingFromNodeId!,
        toNodeId: toNodeId,
        fromPort: _connectingFromPort,
        toPort: toPort,
        start: startPos,
        end: endPos,
      ));
      
      _isConnectionMode = false;
      _connectingFromNodeId = null;
      _connectingFromPort = null;
      _connectionStartPoint = null;
      _connectionEndPoint = null;
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connection created'), duration: Duration(seconds: 1)),
    );
  }

  Future<void> _saveWorkflow() async {
    try {
      // Get or create workflow record
      Workflow? workflow = await _db.getWorkflow(widget.workflowId);
      
      if (workflow == null) {
        // Create new workflow
        workflow = Workflow.create(
          name: widget.workflowName ?? 'Untitled Workflow',
          description: 'Workflow with ${_nodes.length} nodes',
        );
        workflow.id = widget.workflowId;
        await _db.createWorkflow(workflow);
      } else {
        // Update existing workflow
        workflow.touch(); // Update updatedAt timestamp
        workflow.description = 'Workflow with ${_nodes.length} nodes';
        await _db.updateWorkflow(workflow);
      }

      // Clear existing nodes and edges for this workflow before saving new ones
      await _db.deleteNodesByWorkflow(widget.workflowId);
      await _db.deleteEdgesByWorkflow(widget.workflowId);

      // Create a map to track old node IDs to new node IDs
      final nodeIdMapping = <int, int>{};
      
      // Save nodes and track ID mapping
      for (final node in _nodes) {
        final oldNodeId = node.id;
        final workflowNode = WorkflowNode.create(
          workflowId: widget.workflowId,
          type: node.type,
          name: node.name,
          positionX: node.position.dx,
          positionY: node.position.dy,
          configJson: const JsonEncoder().convert(node.config),
        );
        final newNodeId = await _db.createNode(workflowNode);
        nodeIdMapping[oldNodeId] = newNodeId;
      }
      
      // Save edges with port information, mapping old node IDs to new ones
      for (final edge in _edges) {
        final newFromNodeId = nodeIdMapping[edge.fromNodeId] ?? edge.fromNodeId;
        final newToNodeId = nodeIdMapping[edge.toNodeId] ?? edge.toNodeId;
        
        final workflowEdge = WorkflowEdge.create(
          workflowId: widget.workflowId,
          fromNodeId: newFromNodeId,
          toNodeId: newToNodeId,
          label: edge.fromPort ?? 'output', // Fallback to 'output'
          fromPort: edge.fromPort, // Save fromPort explicitly
          toPort: edge.toPort, // Save toPort explicitly
        );
        await _db.createEdge(workflowEdge);
      }
      
      // Calculate execution order using new node IDs
      final executionOrder = _calculateLinearExecutionOrderWithMapping(nodeIdMapping);
      workflow.setExecutionOrder(executionOrder);
      await _db.updateWorkflow(workflow);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Workflow saved successfully!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving workflow: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Calculate linear execution order with node ID mapping (old IDs -> new IDs)
  List<int> _calculateLinearExecutionOrderWithMapping(Map<int, int> nodeIdMapping) {
    if (_edges.isEmpty) {
      // If no edges, return nodes in their current order with new IDs
      return _nodes.map((n) => nodeIdMapping[n.id] ?? n.id).toList();
    }

    // Build a map: old nodeId -> new next node ID (following edges)
    final nextNodeMap = <int, int>{};
    final nodeIds = _nodes.map((n) => n.id).toSet();
    
    for (final edge in _edges) {
      if (nodeIds.contains(edge.fromNodeId) && nodeIds.contains(edge.toNodeId)) {
        // Only add if both nodes exist
        nextNodeMap[edge.fromNodeId] = edge.toNodeId;
      }
    }

    // Find the starting node (node with no incoming edges)
    final hasIncoming = nextNodeMap.values.toSet();
    final startNodes = nodeIds.where((id) => !hasIncoming.contains(id)).toList();

    if (startNodes.isEmpty) {
      // If no clear start node, return nodes in their current order with new IDs
      return _nodes.map((n) => nodeIdMapping[n.id] ?? n.id).toList();
    }

    // Start from the first node with no incoming edges
    final order = <int>[];
    final visited = <int>{};
    
    void followChain(int oldNodeId) {
      if (visited.contains(oldNodeId)) return;
      if (!nodeIds.contains(oldNodeId)) return;
      
      visited.add(oldNodeId);
      // Map to new node ID
      final newNodeId = nodeIdMapping[oldNodeId] ?? oldNodeId;
      order.add(newNodeId);
      
      // Follow the chain to next node
      if (nextNodeMap.containsKey(oldNodeId)) {
        followChain(nextNodeMap[oldNodeId]!);
      }
    }

    // Start from the first start node
    followChain(startNodes.first);

    // Add any remaining nodes that weren't in the chain (with new IDs)
    for (final oldNodeId in nodeIds) {
      if (!visited.contains(oldNodeId)) {
        final newNodeId = nodeIdMapping[oldNodeId] ?? oldNodeId;
        order.add(newNodeId);
      }
    }

    return order;
  }

  Future<void> _runWorkflow() async {
    // First, save the workflow
    await _saveWorkflow();
    
    // Validate workflow before running
    if (!await _validateWorkflow()) {
      return; // Validation failed, error already shown
    }
    
    try {
      // Show loading indicator
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => const Center(
            child: Card(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Running workflow...'),
                  ],
                ),
              ),
            ),
          ),
        );
      }
      
      // Use interactive executor for user input and output
      final interactiveExecutor = InteractiveWorkflowExecutor();
      
      final result = await interactiveExecutor.run(
        widget.workflowId,
        userInputCallback: (prompt, inputType, required, defaultValue) async {
          // Close loading dialog first
          if (mounted) {
            Navigator.of(context).pop();
          }
          // Show user input dialog
          final userInput = await UserInputDialog.show(
            context,
            prompt: prompt,
            inputType: inputType,
            required: required,
            defaultValue: defaultValue,
          );
          // Show loading again after input
          if (mounted) {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => const Center(
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('Running workflow...'),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }
          return userInput;
        },
        outputCallback: (output) async {
          // Close loading dialog
          if (mounted) {
            Navigator.of(context).pop();
          }
          // Show output dialog
          if (mounted) {
            await showDialog(
              context: context,
              builder: (context) => OutputViewer(
                output: output,
                success: true,
              ),
            );
          }
        },
      );
      
      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }
      
      // Show final result if there's no output node
      if (mounted && result.success) {
        // Check if there was an output node that already showed the result
        final hasOutputNode = _nodes.any((n) => n.type == 'output');
        if (!hasOutputNode) {
          showDialog(
            context: context,
            builder: (context) => OutputViewer(
              output: result.finalOutput,
              success: result.success,
              error: result.error,
            ),
          );
        } else {
          // Show success message
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Workflow executed successfully!'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } else if (mounted && !result.success) {
        showDialog(
          context: context,
          builder: (context) => OutputViewer(
            output: result.finalOutput,
            success: false,
            error: result.error,
          ),
        );
      }
    } catch (e) {
      // Close loading dialog if still open
      if (mounted) {
        Navigator.of(context).pop();
      }
      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Execution Error'),
            content: Text('Error executing workflow: $e'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  /// Validate workflow before running
  Future<bool> _validateWorkflow() async {
    if (_nodes.isEmpty) {
      _showValidationError('Workflow is empty. Please add at least one node.');
      return false;
    }

    // Convert FlowchartNodeData to WorkflowNode for validation
    final workflowNodes = _nodes.map((node) {
      return WorkflowNode.create(
        workflowId: widget.workflowId,
        type: node.type,
        name: node.name,
        positionX: node.position.dx,
        positionY: node.position.dy,
        configJson: const JsonEncoder().convert(node.config),
      )..id = node.id;
    }).toList();

    // Convert FlowchartEdgeData to WorkflowEdge for validation
    final workflowEdges = _edges.map((edge) {
      return WorkflowEdge.create(
        workflowId: widget.workflowId,
        fromNodeId: edge.fromNodeId,
        toNodeId: edge.toNodeId,
        fromPort: edge.fromPort,
        toPort: edge.toPort,
      )..id = edge.id;
    }).toList();

    // Get node types
    final nodeTypes = <int, NodeType>{};
    for (final node in _nodes) {
      final nodeType = NodeType.getById(node.type);
      if (nodeType != null) {
        nodeTypes[node.id] = nodeType;
      }
    }

    // Validate workflow completeness (input to output path)
    final completenessValidation = DataValidator.validateWorkflowCompleteness(
      workflowNodes,
      workflowEdges,
      nodeTypes,
    );

    if (!completenessValidation.isValid) {
      _showValidationError(
        'Workflow validation failed:\n\n${completenessValidation.errors.join('\n')}',
      );
      return false;
    }

    // Validate data flow
    final dataFlowValidation = DataValidator.validateWorkflowDataFlow(
      workflowNodes,
      workflowEdges,
      nodeTypes,
    );

    if (!dataFlowValidation.isValid) {
      _showValidationError(
        'Data flow validation failed:\n\n${dataFlowValidation.errors.join('\n')}',
      );
      return false;
    }

    // Check for cycles using DAGParser
    try {
      final dag = DAGParser.parse(workflowNodes, workflowEdges);
      if (DAGParser.hasCycle(dag)) {
        _showValidationError('Workflow contains cycles. Please fix the connections.');
        return false;
      }
    } catch (e) {
      _showValidationError('Error parsing workflow: $e');
      return false;
    }

    // Show warnings if any
    if (completenessValidation.warnings.isNotEmpty || dataFlowValidation.warnings.isNotEmpty) {
      final allWarnings = [
        ...completenessValidation.warnings,
        ...dataFlowValidation.warnings,
      ];
      
      final shouldContinue = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Workflow Warnings'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('The workflow has some warnings:'),
                const SizedBox(height: 8),
                ...allWarnings.map((warning) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('• $warning', style: const TextStyle(fontSize: 12)),
                )),
                const SizedBox(height: 16),
                const Text('Do you want to continue anyway?'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Continue'),
            ),
          ],
        ),
      );

      if (shouldContinue != true) {
        return false;
      }
    }

    return true;
  }

  void _showValidationError(String message) {
    if (mounted) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Cannot Run Workflow'),
          content: SingleChildScrollView(
            child: Text(message),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'smart_toy':
        return Icons.smart_toy;
      case 'image':
        return Icons.image;
      case 'layers':
        return Icons.layers;
      case 'call_split':
        return Icons.call_split;
      case 'alt_route':
        return Icons.alt_route;
      case 'compare_arrows':
        return Icons.compare_arrows;
      case 'http':
        return Icons.http;
      case 'code':
        return Icons.code;
      case 'data_object':
        return Icons.data_object;
      case 'label':
        return Icons.label;
      case 'schedule':
        return Icons.schedule;
      case 'merge_type':
        return Icons.merge_type;
      case 'input':
        return Icons.input;
      case 'output':
        return Icons.output;
      default:
        return Icons.circle;
    }
  }
}

/// Node selector bottom sheet
class _NodeSelector extends StatelessWidget {
  final Function(NodeType) onNodeSelected;

  const _NodeSelector({required this.onNodeSelected});

  @override
  Widget build(BuildContext context) {
    final categories = ['AI', 'Logic', 'Data', 'Utility', 'I/O'];
    
    return Container(
      height: 500,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Select Node Type',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: categories.map((category) {
                final nodes = NodeType.getByCategory(category);
                return ExpansionTile(
                  title: Text(category),
                  children: nodes.map((nodeType) {
                    return ListTile(
                      leading: Icon(
                        _getIconData(nodeType.icon),
                        color: nodeType.color,
                      ),
                      title: Text(nodeType.name),
                      subtitle: Text(nodeType.description),
                      onTap: () => onNodeSelected(nodeType),
                    );
                  }).toList(),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'smart_toy':
        return Icons.smart_toy;
      case 'image':
        return Icons.image;
      case 'layers':
        return Icons.layers;
      case 'call_split':
        return Icons.call_split;
      case 'alt_route':
        return Icons.alt_route;
      case 'compare_arrows':
        return Icons.compare_arrows;
      case 'http':
        return Icons.http;
      case 'code':
        return Icons.code;
      case 'data_object':
        return Icons.data_object;
      case 'label':
        return Icons.label;
      case 'schedule':
        return Icons.schedule;
      case 'merge_type':
        return Icons.merge_type;
      case 'input':
        return Icons.input;
      case 'output':
        return Icons.output;
      default:
        return Icons.circle;
    }
  }
}

