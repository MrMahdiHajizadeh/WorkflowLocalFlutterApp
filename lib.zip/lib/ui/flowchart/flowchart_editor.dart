import 'package:flutter/material.dart';
import 'canvas_painter.dart';

/// Main flowchart editor screen
class FlowchartEditorScreen extends StatefulWidget {
  final int workflowId;

  const FlowchartEditorScreen({super.key, required this.workflowId});

  @override
  State<FlowchartEditorScreen> createState() => _FlowchartEditorScreenState();
}

class _FlowchartEditorScreenState extends State<FlowchartEditorScreen> {
  double _zoom = 1.0;
  Offset _pan = Offset.zero;
  Offset _lastPanPosition = Offset.zero;

  final List<FlowchartNodeData> _nodes = [];
  final List<FlowchartEdgeData> _edges = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flowchart Editor'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _addNode,
            tooltip: 'Add Node',
          ),
          IconButton(
            icon: const Icon(Icons.play_arrow),
            onPressed: _runWorkflow,
            tooltip: 'Run Workflow',
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveWorkflow,
            tooltip: 'Save Workflow',
          ),
        ],
      ),
      body: Stack(
        children: [
          // Canvas
          GestureDetector(
            onScaleStart: (details) {
              _lastPanPosition = details.focalPoint;
            },
            onScaleUpdate: (details) {
              setState(() {
                // Handle zoom
                _zoom = (_zoom * details.scale).clamp(0.5, 3.0);

                // Handle pan
                final delta = details.focalPoint - _lastPanPosition;
                _pan += delta;
                _lastPanPosition = details.focalPoint;
              });
            },
            child: CustomPaint(
              painter: FlowchartCanvasPainter(
                nodes: _nodes,
                edges: _edges,
                zoom: _zoom,
                pan: _pan,
              ),
              size: Size.infinite,
            ),
          ),

          // Nodes (draggable widgets)
          ..._nodes.map((node) => _buildNodeWidget(node)),

          // Minimap
          Positioned(
            bottom: 16,
            right: 16,
            child: _buildMinimap(),
          ),

          // Toolbar
          Positioned(
            top: 16,
            left: 16,
            child: _buildToolbar(),
          ),
        ],
      ),
    );
  }

  Widget _buildNodeWidget(FlowchartNodeData node) {
    return Positioned(
      left: node.position.dx * _zoom + _pan.dx,
      top: node.position.dy * _zoom + _pan.dy,
      child: Draggable(
        feedback: _buildNodeCard(node, dragging: true),
        childWhenDragging: Container(),
        onDragEnd: (details) {
          setState(() {
            // Update node position (snap to grid)
            final newX = ((details.offset.dx - _pan.dx) / _zoom / 16).round() * 16.0;
            final newY = ((details.offset.dy - _pan.dy) / _zoom / 16).round() * 16.0;

            final index = _nodes.indexOf(node);
            _nodes[index] = FlowchartNodeData(
              id: node.id,
              type: node.type,
              name: node.name,
              position: Offset(newX, newY),
            );
          });
        },
        child: _buildNodeCard(node),
      ),
    );
  }

  Widget _buildNodeCard(FlowchartNodeData node, {bool dragging = false}) {
    return Container(
      width: 180,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: dragging ? Colors.blue.withOpacity(0.8) : Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            node.type.toUpperCase(),
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            node.name,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMinimap() {
    return Container(
      width: 150,
      height: 100,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Center(
        child: Text('Minimap', style: TextStyle(fontSize: 12)),
      ),
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Zoom: ${(_zoom * 100).toInt()}%'),
          Slider(
            value: _zoom,
            min: 0.5,
            max: 3.0,
            onChanged: (value) {
              setState(() {
                _zoom = value;
              });
            },
          ),
        ],
      ),
    );
  }

  void _addNode() {
    setState(() {
      _nodes.add(FlowchartNodeData(
        id: _nodes.length + 1,
        type: 'llm',
        name: 'New Node',
        position: Offset(100 + _nodes.length * 20.0, 100 + _nodes.length * 20.0),
      ));
    });
  }

  void _runWorkflow() {
    // TODO: Execute workflow
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Running workflow...')),
    );
  }

  void _saveWorkflow() {
    // TODO: Save workflow to database
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Workflow saved!')),
    );
  }
}
