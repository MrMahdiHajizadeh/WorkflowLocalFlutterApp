import 'package:flutter/material.dart';
import '../../core/storage/isar_service.dart';
import '../../core/storage/models/model_entry.dart';
import '../../core/ai_router/router.dart';
import '../../core/ai_router/models.dart';
import '../../core/security/encryption.dart';

/// Chat interface with streaming support
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _messages = [];
  final ScrollController _scrollController = ScrollController();
  final IsarService _db = IsarService();
  final AIRouter _router = AIRouter();
  final EncryptionService _encryption = EncryptionService();
  
  List<ModelEntry> _availableModels = [];
  ModelEntry? _selectedModel;
  bool _isLoading = false;
  bool _isLoadingModels = true;

  @override
  void initState() {
    super.initState();
    _loadModels();
  }

  Future<void> _loadModels() async {
    try {
      final allModels = await _db.getAllModels();
      // Filter only LLM models
      final llmModels = allModels.where((m) => m.modelType == 'llm').toList();
      
      setState(() {
        _availableModels = llmModels;
        _isLoadingModels = false;
        // Select first model if available
        if (_availableModels.isNotEmpty && _selectedModel == null) {
          _selectedModel = _availableModels.first;
        }
      });
    } catch (e) {
      setState(() {
        _isLoadingModels = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading models: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Assistant'),
        actions: [
          // Model selector
          if (!_isLoadingModels)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: _buildModelSelector(),
            ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: _clearChat,
            tooltip: 'Clear Chat',
          ),
        ],
      ),
      body: Column(
        children: [
          // Messages list
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return _buildMessage(_messages[index]);
              },
            ),
          ),

          // Input field
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Model selector in input area (more visible)
                if (_isLoadingModels)
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: LinearProgressIndicator(),
                  )
                else if (_availableModels.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.orange.shade200),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.warning, color: Colors.orange.shade700, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'No LLM models configured. Please add a model in Settings.',
                            style: TextStyle(
                              color: Colors.orange.shade900,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  // Show model selector in input area for better visibility
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.smart_toy,
                          color: Colors.blue.shade700,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Model:',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: DropdownButton<ModelEntry>(
                            value: _selectedModel,
                            isDense: true,
                            isExpanded: true,
                            underline: const SizedBox.shrink(),
                            icon: Icon(Icons.arrow_drop_down, color: Colors.blue.shade700, size: 20),
                            style: TextStyle(
                              color: Colors.blue.shade900,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                            dropdownColor: Colors.white,
                            items: _availableModels.map((model) {
                              return DropdownMenuItem<ModelEntry>(
                                value: model,
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.smart_toy,
                                      color: Colors.blue.shade700,
                                      size: 18,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        model.name,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (ModelEntry? newModel) {
                              if (newModel != null) {
                                setState(() {
                                  _selectedModel = newModel;
                                });
                                // Show confirmation
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Switched to ${newModel.name}'),
                                    duration: const Duration(seconds: 1),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        enabled: _selectedModel != null && !_isLoading,
                        decoration: InputDecoration(
                          hintText: _selectedModel == null
                              ? 'No model selected...'
                              : 'Ask me anything or describe a workflow...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                        maxLines: null,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (_isLoading)
                      const Padding(
                        padding: EdgeInsets.all(12),
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      IconButton(
                        icon: const Icon(Icons.send),
                        onPressed: (_selectedModel != null && !_isLoading) ? _sendMessage : null,
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessage(ChatMessage message) {
    final isUser = message.role == 'user';

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) _buildAvatar(false),
          const SizedBox(width: 8),
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser ? Colors.blue : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                message.content,
                style: TextStyle(
                  color: isUser ? Colors.white : Colors.black87,
                  fontSize: 15,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (isUser) _buildAvatar(true),
        ],
      ),
    );
  }

  Widget _buildAvatar(bool isUser) {
    return CircleAvatar(
      radius: 16,
      backgroundColor: isUser ? Colors.blue : Colors.purple,
      child: Icon(
        isUser ? Icons.person : Icons.smart_toy,
        size: 16,
        color: Colors.white,
      ),
    );
  }

  Widget _buildModelSelector() {
    if (_availableModels.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      constraints: const BoxConstraints(maxWidth: 220),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.white.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.smart_toy,
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: DropdownButton<ModelEntry>(
              value: _selectedModel,
              isDense: true,
              underline: const SizedBox.shrink(),
              icon: const Icon(Icons.arrow_drop_down, color: Colors.white, size: 20),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
              dropdownColor: Colors.grey.shade800,
              items: _availableModels.map((model) {
                return DropdownMenuItem<ModelEntry>(
                  value: model,
                  child: Row(
                    children: [
                      Icon(
                        Icons.smart_toy,
                        color: Colors.white.withOpacity(0.7),
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          model.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (ModelEntry? newModel) {
                if (newModel != null) {
                  setState(() {
                    _selectedModel = newModel;
                  });
                  // Show confirmation
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Switched to ${newModel.name}'),
                      duration: const Duration(seconds: 1),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _selectedModel == null || _isLoading) return;

    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text));
      _controller.clear();
      _isLoading = true;
    });

    // Scroll to bottom
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });

    try {
      // Decrypt API key
      String decryptedApiKey;
      try {
        decryptedApiKey = _encryption.decryptText(_selectedModel!.apiKeyEncrypted);
      } catch (e) {
        throw Exception('Failed to decrypt API key: $e');
      }

      // Validate model configuration
      if (_selectedModel!.baseUrl.isEmpty) {
        throw Exception('Model base URL is not configured');
      }

      // Build conversation history
      final messages = <Map<String, String>>[];
      for (final msg in _messages) {
        messages.add({
          'role': msg.role == 'user' ? 'user' : 'assistant',
          'content': msg.content,
        });
      }

      // Create AI request
      final request = AIRequest(
        modelId: _selectedModel!.name,
        provider: _selectedModel!.provider,
        baseUrl: _selectedModel!.baseUrl,
        apiKey: decryptedApiKey,
        modelType: 'llm',
        inputs: {
          'messages': messages,
        },
        parameters: {
          'temperature': 0.7,
          'max_tokens': 1000,
        },
        streaming: false,
      );

      // Send request
      final response = await _router.send(request);

      // Add AI response to messages
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            role: 'assistant',
            content: response.text ?? 'No response received',
          ));
          _isLoading = false;
        });

        // Scroll to bottom
        Future.delayed(const Duration(milliseconds: 100), () {
          if (_scrollController.hasClients) {
            _scrollController.animateTo(
              _scrollController.position.maxScrollExtent,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            role: 'assistant',
            content: 'Error: $e',
          ));
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _clearChat() {
    setState(() {
      _messages.clear();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}

/// Chat message model
class ChatMessage {
  final String role; // 'user' | 'assistant'
  final String content;

  ChatMessage({required this.role, required this.content});
}
