import 'package:flutter/material.dart';
import 'core/storage/isar_service.dart';
import 'core/security/encryption.dart';
import 'app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Isar database (stub on web, real on desktop/mobile)
  final isarService = IsarService();
  await isarService.initialize();

  // Initialize encryption
  final encryption = EncryptionService();
  encryption.initialize('device_unique_id'); // In production, use actual device ID

  runApp(const AIFlowArchitectApp());
}
